suppressPackageStartupMessages({ library(data.table); library(brglm2); library(sandwich) })
RES <- "results"
pe <- as.data.frame(readRDS("data/processed/panel_frd_extended.rds"))
p1 <- quantile(pe$inflation_lag1, .01, na.rm = TRUE); p99 <- quantile(pe$inflation_lag1, .99, na.rm = TRUE)
pe$inflation_lag1 <- pmin(pmax(pe$inflation_lag1, p1), p99)
mena <- c("DZA", "ARE", "BHR", "EGY", "IRN", "IRQ", "JOR", "KWT", "LBN", "LBY", "MAR", "OMN", "QAT", "SAU", "TUN")
pe$mena2 <- as.integer(pe$iso3 %in% mena)
R <- c("dette_lag1", "pib_lag1", "inflation_lag1", "balance_cour", "solde_prim", "sanction", "war_any")
d <- pe[!is.na(pe$fiscal_council_monitoring), c("iso3", "annee", "fr_any", R, "fiscal_council_monitoring", "mena2")]
d <- d[complete.cases(d), ]
tab <- table(conseil = d$fiscal_council_monitoring, regle = d$fr_any); print(tab)
f <- as.formula(paste("fr_any ~", paste(c(R, "fiscal_council_monitoring"), collapse = " + "), "+ mena2"))
pr <- suppressWarnings(glm(f, data = d, family = binomial("probit")))
pext <- mean(fitted(pr) < 1e-6 | fitted(pr) > 1 - 1e-6)
fi <- glm(f, data = d, family = binomial("logit"), method = "brglmFit", type = "AS_mean")
xb <- predict(fi, type = "link"); bf <- coef(fi)["fiscal_council_monitoring"]
published <- mean(exp(xb) / (1 + exp(xb))^2) * bf
d1 <- d; d1$fiscal_council_monitoring <- 1; d0 <- d; d0$fiscal_council_monitoring <- 0
ame <- mean(predict(fi, d1, type = "response") - predict(fi, d0, type = "response"))
set.seed(1); ids <- unique(d$iso3); bs <- rep(NA_real_, 499)
for (b in seq_along(bs)) { s <- sample(ids, replace = TRUE); db <- do.call(rbind, lapply(s, function(i) d[d$iso3 == i, ]))
  fb <- tryCatch(glm(f, data = db, family = binomial("logit"), method = "brglmFit", type = "AS_mean"), error = function(e) NULL)
  if (is.null(fb)) next
  a1 <- db; a1$fiscal_council_monitoring <- 1; a0 <- db; a0$fiscal_council_monitoring <- 0
  bs[b] <- mean(predict(fb, a1, type = "response") - predict(fb, a0, type = "response")) }
lpm <- lm(f, data = d); V <- vcovCL(lpm, cluster = ~iso3)
out <- data.table(N = nrow(d), countries = length(unique(d$iso3)), council_years = sum(d$fiscal_council_monitoring == 1),
                  council_years_with_rule = sum(d$fiscal_council_monitoring == 1 & d$fr_any == 1), probit_extreme_share = pext,
                  published_value_reproduced = published, ame_discrete = ame, ame_boot_se = sd(bs, na.rm = TRUE),
                  lpm = coef(lpm)["fiscal_council_monitoring"], lpm_se = sqrt(V["fiscal_council_monitoring", "fiscal_council_monitoring"]))
print(out); fwrite(out, file.path(RES, "fiscal_council_col2.csv"))
