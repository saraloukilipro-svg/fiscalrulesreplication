source("code/00_utils.R"); source("code/01_data.R")
d <- prep_panel("data/processed/panel_analytique_FINAL_v3.rds")

ref <- rbind(
  data.table(obj = "dette plein h5 coef", val = -0.130), data.table(obj = "dette plein h5 se", val = 0.075),
  data.table(obj = "dette plein h8 coef", val = -0.193), data.table(obj = "dette plein h8 se", val = 0.080),
  data.table(obj = "pi Sfin h4 p cluster", val = 0.033), data.table(obj = "pi Sfin h4 p DK", val = 0.035),
  data.table(obj = "pi Sfin h5 p DK", val = 0.024), data.table(obj = "pi Sfin h6 p DK", val = 0.021),
  data.table(obj = "pi Sfin h7 p DK", val = 0.017), data.table(obj = "pi Sfin h8 p DK", val = 0.040),
  data.table(obj = "pi S h5 p DK", val = 0.002), data.table(obj = "pi S h6 p DK", val = 0.008),
  data.table(obj = "pi Sfin h4 p WCB", val = 0.050), data.table(obj = "pi Sfin h6 p WCB", val = 0.033))

m5 <- lp(d, yname("debt", 5), "e", 5); m8 <- lp(d, yname("debt", 8), "e", 8)
out <- list(term_stats(m5, "e")$coef, term_stats(m5, "e")$se, term_stats(m8, "e")$coef, term_stats(m8, "e")$se)
pf <- lapply(4:8, function(h) pooled(d, yname("debt", h), h, "Sfin_l1"))
ps <- lapply(5:6, function(h) pooled(d, yname("debt", h), h, "S_l1"))
res <- data.table(obj = ref$obj, ref = ref$val, replication = c(
  unlist(out), term_stats(pf[[1]], "xS")$p,
  sapply(pf, function(m) term_stats(m, "xS", vc = "DK")$p),
  sapply(ps, function(m) term_stats(m, "xS", vc = "DK")$p),
  wcb_p(pf[[1]], "xS"), wcb_p(pf[[3]], "xS")))
res[, ecart := round(replication - ref, 3)]
print(res[, .(obj, ref, replication = round(replication, 3), ecart)])
cat("\nDK, sensibilité au retard du noyau (p de pi Sfin h4 à h8) :\n")
for (L in 0:3) cat(" lag", L, ":", round(sapply(pf, function(m) { V <- vcov_dk(m, "xS", lag = L)
  2 * pt(-abs(m$b["xS"] / sqrt(V)), m$Tn - 1) }), 3), "\n")
