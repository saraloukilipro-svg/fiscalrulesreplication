library(tidyverse)
library(WDI)
library(countrycode)
library(zoo)

setwd(Sys.getenv("FRR_ROOT", "."))

cat("=== Chargement panel_analytique_FINAL_v2 ===\n")

panel_v2 <- readRDS("data/processed/panel_analytique_FINAL_v2.rds")

cat("Dimensions :", nrow(panel_v2), "×", ncol(panel_v2), "\n")
iso60 <- unique(panel_v2$iso3)
cat("Pays       :", length(iso60), "\n")
cat("Années     :", min(panel_v2$annee), "–", max(panel_v2$annee), "\n\n")

cat("=== Téléchargement WDI ===\n")

wdi_indicators <- c(
  pop_total     = "SP.POP.TOTL",
  dependency    = "SP.POP.DPND",
  pop_urban_pct = "SP.URB.TOTL.IN.ZS",
  pop_growth    = "SP.POP.GROW",
  life_exp      = "SP.DYN.LE00.IN"
)

iso2_list <- countrycode(iso60, origin = "iso3c",
                         destination = "iso2c", warn = FALSE)
iso2_list <- iso2_list[!is.na(iso2_list)]

wdi_raw <- WDI(
  country   = iso2_list,
  indicator = wdi_indicators,
  start     = 1990,
  end       = 2022,
  extra     = FALSE
) %>%
  as_tibble() %>%
  mutate(
    iso3  = countrycode(iso2c, origin = "iso2c",
                        destination = "iso3c", warn = FALSE),
    annee = as.integer(year)
  ) %>%
  filter(!is.na(iso3), iso3 %in% iso60) %>%
  select(iso3, annee,
         pop_total, dependency, pop_urban_pct,
         pop_growth, life_exp)

cat("WDI téléchargé :", nrow(wdi_raw), "obs ×", ncol(wdi_raw), "variables\n")
cat("Pays couverts  :", n_distinct(wdi_raw$iso3), "/ 60\n\n")

cat("=== Traitement ===\n")

wdi_demo <- wdi_raw %>%
  arrange(iso3, annee) %>%
  group_by(iso3) %>%
  mutate(

    across(c(pop_total, dependency, pop_urban_pct,
             pop_growth, life_exp),
           ~zoo::na.approx(.x, na.rm = FALSE, rule = 1)),

    log_pop = log(pop_total)
  ) %>%
  ungroup()

cat("Variables construites :\n")
cat("  log_pop       : log(population totale)\n")
cat("  dependency    : taux de dépendance démographique\n")
cat("  pop_urban_pct : % population urbaine\n")
cat("  pop_growth    : croissance démographique (%)\n")
cat("  life_exp      : espérance de vie\n\n")

cat("=== Couverture ===\n")

demo_vars <- c("log_pop","dependency","pop_urban_pct","pop_growth","life_exp")

wdi_demo %>%
  summarise(across(all_of(demo_vars),
                   ~round(100 * mean(!is.na(.)), 1))) %>%
  pivot_longer(everything(),
               names_to  = "variable",
               values_to = "pct_complete") %>%
  print()

cat("\n")

cat("=== Fusion sur panel_v2 (1 980 obs) ===\n")

panel_v3 <- panel_v2 %>%
  left_join(
    wdi_demo %>% select(iso3, annee, all_of(demo_vars)),
    by = c("iso3", "annee")
  )

stopifnot("Panel ≠ 1 980 obs" = nrow(panel_v3) == 1980)
cat("Intégrité : 1 980 observations confirmées\n")
cat("Variables  :", ncol(panel_v3), "\n\n")

cat("Valeurs manquantes : variables démographiques :\n")
panel_v3 %>%
  select(all_of(demo_vars)) %>%
  summarise(across(everything(), ~sum(is.na(.)))) %>%
  pivot_longer(everything(),
               names_to  = "variable",
               values_to = "n_missing") %>%
  mutate(pct_missing = round(100 * n_missing / 1980, 1)) %>%
  arrange(desc(n_missing)) %>%
  print()

saveRDS(panel_v3, "data/processed/panel_analytique_FINAL_v3.rds")

cat("\nSauvegardé : data/processed/panel_analytique_FINAL_v3.rds\n")
cat("   Dimensions  :", nrow(panel_v3), "obs ×", ncol(panel_v3), "variables\n")
cat("\n   Structure finale du panel :\n")
cat("   • Macro-fiscal (WEO)     : dette_pib, solde_prim, rev_pub...\n")
cat("   • Choc GPR               : gpr_choc, gpr_pays...\n")
cat("   • Règles budgétaires     : fr_any, bbr, dr, er, rr...\n")
cat("   • Sanctions (GSDB)       : sanction, n_sanctions...\n")
cat("   • Guerre (COW/UCDP)      : war_any, war_intrastate...\n")
cat("   • Démographie (WDI)      : log_pop, dependency...\n")
cat("\n   Prochaine étape : 06_LP_estimation.R\n\n")
