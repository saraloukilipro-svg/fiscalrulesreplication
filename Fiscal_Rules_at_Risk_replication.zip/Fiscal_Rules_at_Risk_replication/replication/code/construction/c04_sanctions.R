setwd(Sys.getenv("FRR_ROOT", "."))
suppressPackageStartupMessages({ library(tidyverse); library(writexl) })
cat("=== SCRIPT 04 : SANCTIONS ECONOMIQUES ===\n\n")

pays_panel <- readRDS("data/processed/pays_panel.rds")

cat("Chargement GSDB_v3.csv...\n")

gsdb_raw <- read_csv("data/raw/GSDB_v3.csv", show_col_types=FALSE)

cat("GSDB :", nrow(gsdb_raw), "cas de sanctions\n")
cat("Période :", min(gsdb_raw$begin, na.rm=TRUE), "–",
    max(gsdb_raw$end, na.rm=TRUE), "\n\n")

pays_gsdb_map <- c(

  "Morocco"              = "MAR",
  "Tunisia"              = "TUN",
  "Algeria"              = "DZA",
  "Egypt"                = "EGY",
  "Jordan"               = "JOR",
  "Saudi Arabia"         = "SAU",
  "United Arab Emirates" = "ARE",
  "Kuwait"               = "KWT",
  "Qatar"                = "QAT",
  "Bahrain"              = "BHR",
  "Oman"                 = "OMN",
  "Iran"                 = "IRN",
  "Iraq"                 = "IRQ",
  "Lebanon"              = "LBN",
  "Libya"                = "LBY",

  "Ghana"                = "GHA",
  "Senegal"              = "SEN",
  "Kenya"                = "KEN",
  "Nigeria"              = "NGA",
  "South Africa"         = "ZAF",
  "Cote d'Ivoire"        = "CIV",
  "Ivory Coast"          = "CIV",
  "Cameroon"             = "CMR",
  "Rwanda"               = "RWA",
  "Tanzania"             = "TZA",
  "Uganda"               = "UGA",
  "Zambia"               = "ZMB",
  "Mozambique"           = "MOZ",
  "Ethiopia"             = "ETH",
  "Madagascar"           = "MDG",
  "Burkina Faso"         = "BFA",

  "Brazil"               = "BRA",
  "Mexico"               = "MEX",
  "Argentina"            = "ARG",
  "Colombia"             = "COL",
  "Chile"                = "CHL",
  "Peru"                 = "PER",
  "Ecuador"              = "ECU",
  "Bolivia"              = "BOL",
  "Paraguay"             = "PRY",
  "Uruguay"              = "URY",
  "Guatemala"            = "GTM",
  "Honduras"             = "HND",
  "Jamaica"              = "JAM",
  "Trinidad and Tobago"  = "TTO",
  "Panama"               = "PAN",

  "India"                = "IND",
  "Indonesia"            = "IDN",
  "Philippines"          = "PHL",
  "Thailand"             = "THA",
  "Bangladesh"           = "BGD",
  "Pakistan"             = "PAK",
  "Vietnam"              = "VNM",
  "Malaysia"             = "MYS",
  "Sri Lanka"            = "LKA",
  "Nepal"                = "NPL",

  "Turkey"               = "TUR",
  "Ukraine"              = "UKR",
  "Russia"               = "RUS",
  "Russian Federation"   = "RUS",
  "Kazakhstan"           = "KAZ",
  "Georgia"              = "GEO"
)

gsdb_panel <- gsdb_raw %>%
  mutate(
    iso3 = pays_gsdb_map[sanctioned_state],
    end  = if_else(is.na(end) | end > 2022, 2022L, as.integer(end)),
    begin = as.integer(begin)
  ) %>%
  filter(!is.na(iso3), begin <= 2022, begin >= 1990)

cat("Cas dans notre panel :", nrow(gsdb_panel), "\n")
cat("Pays concernés :", n_distinct(gsdb_panel$iso3), "\n\n")

cat("Expansion cas -> panel pays x années...\n")

gsdb_long <- gsdb_panel %>%
  rowwise() %>%
  mutate(annee = list(seq(begin, min(end, 2022)))) %>%
  unnest(annee) %>%
  ungroup() %>%
  filter(annee >= 1990, annee <= 2022)

cat("Observations pays×année-sanction :", nrow(gsdb_long), "\n\n")

sanctions_agg <- gsdb_long %>%
  group_by(iso3, annee) %>%
  summarise(
    sanction          = 1L,
    n_sanctions       = n(),
    sanction_fin      = as.integer(any(financial==1, na.rm=TRUE)),
    sanction_comm     = as.integer(any(trade==1,     na.rm=TRUE)),
    sanction_arms     = as.integer(any(arms==1,      na.rm=TRUE)),
    sanction_mil      = as.integer(any(military==1,  na.rm=TRUE)),
    sanction_travel   = as.integer(any(travel==1,    na.rm=TRUE)),
    .groups = "drop"
  )

cat("Agrégation :", nrow(sanctions_agg),
    "observations pays×année avec sanction active\n\n")

grille <- expand_grid(iso3 = pays_panel$iso3, annee = 1990:2022)

sanctions_panel <- grille %>%
  left_join(sanctions_agg, by = c("iso3","annee")) %>%
  replace_na(list(
    sanction       = 0L,
    n_sanctions    = 0L,
    sanction_fin   = 0L,
    sanction_comm  = 0L,
    sanction_arms  = 0L,
    sanction_mil   = 0L,
    sanction_travel= 0L
  )) %>%
  mutate(

    sanction_intensite = sanction_fin + sanction_comm +
                         sanction_arms + sanction_mil + sanction_travel,

    sanction_log       = log1p(n_sanctions)
  )

cat("Panel sanctions complet :", nrow(sanctions_panel), "obs\n\n")

cat("--- SANCTIONS PAR RÉGION ---\n")
sanctions_panel %>%
  left_join(pays_panel %>% select(iso3, region, mena), by="iso3") %>%
  group_by(region) %>%
  summarise(
    n_pays          = n_distinct(iso3),
    pct_sanction    = round(mean(sanction)*100,     1),
    n_sanc_moy      = round(mean(n_sanctions),      2),
    pct_fin         = round(mean(sanction_fin)*100, 1),
    pct_comm        = round(mean(sanction_comm)*100,1),
    .groups = "drop"
  ) %>% print()

cat("\n--- SANCTIONS MENA (nb années sanctionnées 1990–2022) ---\n")
sanctions_panel %>%
  left_join(pays_panel %>% select(iso3, mena), by="iso3") %>%
  filter(mena == 1) %>%
  group_by(iso3) %>%
  summarise(
    annees_sanct  = sum(sanction),
    n_cas_total   = sum(n_sanctions),
    pct_fin       = round(mean(sanction_fin)*100, 1),
    .groups = "drop"
  ) %>%
  arrange(desc(annees_sanct)) %>%
  print()

panel_step3 <- readRDS("data/processed/panel_step3_fr.rds")

panel_step4 <- panel_step3 %>%
  left_join(
    sanctions_panel %>% select(iso3, annee, sanction, n_sanctions,
                                sanction_fin, sanction_comm, sanction_arms,
                                sanction_mil, sanction_intensite, sanction_log),
    by = c("iso3","annee")
  )

cat("\nPanel step 4 :", nrow(panel_step4), "obs ×",
    ncol(panel_step4), "variables\n\n")

saveRDS(panel_step4, "data/processed/panel_step4_sanctions.rds")
write_csv(panel_step4, "data/processed/panel_step4_sanctions.csv")
writexl::write_xlsx(
  list(panel=panel_step4, sanctions_detail=sanctions_agg),
  "output/step4_sanctions.xlsx"
)

cat("SCRIPT 04 TERMINÉ\n")

