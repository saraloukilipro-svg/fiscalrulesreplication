root <- normalizePath(".")
rb <- file.path(root, "rebuild")
unlink(rb, recursive = TRUE)
dir.create(file.path(rb, "data", "processed"), recursive = TRUE)
dir.create(file.path(rb, "output"), recursive = TRUE)
file.copy(file.path(root, "data", "raw"), file.path(rb, "data"), recursive = TRUE)
loc <- Sys.getlocale("LC_CTYPE")
if (!grepl("UTF-?8", loc, ignore.case = TRUE)) loc <- "C.UTF-8"
steps <- c("c01_weo.R", "c02_gpr_submitted.R", "c03_fiscal_rules.R", "c04_sanctions.R", "c05_panel_assembly.R",
           "c06_wars.R", "c07_demographics.R", "c08_gpr_shock.R", "c09_frd_extension.R")
dir.create(file.path(root, "logs"), showWarnings = FALSE)
for (s in steps) {
  cat(format(Sys.time(), "%H:%M:%S"), "->", s, "\n")
  st <- system2("Rscript", file.path(root, "code", "construction", s),
                stdout = file.path(root, "logs", sub("\\.R$", ".log", s)), stderr = file.path(root, "logs", sub("\\.R$", ".log", s)),
                env = c(paste0("FRR_ROOT=", rb), paste0("LC_ALL=", loc), paste0("LANG=", loc)))
  if (st != 0) stop("Échec de ", s, " : voir logs/", sub("\\.R$", ".log", s))
}

compare <- function(f) {
  a <- as.data.frame(readRDS(file.path(rb, "data", "processed", f)))
  b <- as.data.frame(readRDS(file.path(root, "data", "processed", f)))
  a <- a[order(a$iso3, a$annee), ]; b <- b[order(b$iso3, b$annee), ]
  com <- intersect(names(a), names(b))
  diff <- com[!vapply(com, function(v) { x <- a[[v]]; y <- b[[v]]
    if (is.numeric(x) && is.numeric(y)) isTRUE(all((is.na(x) & is.na(y)) | (!is.na(x) & !is.na(y) & abs(x - y) <= 1e-8 * pmax(1, abs(y)))))
    else isTRUE(all((is.na(x) & is.na(y)) | (!is.na(x) & !is.na(y) & as.character(x) == as.character(y)))) }, logical(1))]
  sprintf("%s : %d x %d reconstruit, %d x %d distribué ; colonnes absentes : %s ; colonnes différentes : %s", f, nrow(a), ncol(a),
          nrow(b), ncol(b), paste(c(setdiff(names(b), names(a)), "aucune")[1], collapse = " "), if (length(diff)) paste(diff, collapse = " ") else "aucune")
}
out <- c(compare("panel_analytique_FINAL_v3.rds"), compare("panel_frd_extended.rds"))
writeLines(out, file.path(root, "results", "check_panel_rebuild.txt")); cat(out, sep = "\n")
