library(tidyverse)
library(readxl)

setwd(Sys.getenv("FRR_ROOT", "."))

cat("=== Chargement PANEL_ANALYTIQUE_FINAL ===\n")

panel <- read_excel("output/PANEL_ANALYTIQUE_FINAL.xlsx") %>%
  mutate(iso3  = as.character(iso3),
         annee = as.integer(annee))

cat("Dimensions :", nrow(panel), "×", ncol(panel), "\n")
cat("Pays       :", n_distinct(panel$iso3), "\n")
cat("Années     :", min(panel$annee), "–", max(panel$annee), "\n\n")

iso60 <- unique(panel$iso3)

cat("=== Chargement datawar.xlsx ===\n")

wars_raw <- read_excel("data/raw/datawar.xlsx", sheet = "Sheet1") %>%
  mutate(
    warname    = str_trim(warname),
    iso3       = as.character(iso),
    start_alt  = as.numeric(start_alt),
    end_alt    = as.numeric(end_alt),
    casualties = as.numeric(casualties)
  )

cat("Épisodes bruts :", nrow(wars_raw), "\n")
cat("Types :", paste(names(table(wars_raw$type)),
                     table(wars_raw$type), sep = "=", collapse = " | "), "\n\n")

cat("=== Filtrage ===\n")

wars_prep <- wars_raw %>%
  filter(iso3 %in% iso60) %>%
  mutate(
    end_alt_eff   = if_else(is.na(end_alt), 2022L,
                            as.integer(pmin(end_alt, 2022))),
    start_alt_eff = as.integer(pmax(start_alt, 1990))
  ) %>%
  filter(start_alt_eff <= 2022L, end_alt_eff >= 1990L)

cat("Épisodes retenus :", nrow(wars_prep), "  [attendu : 62]\n")
cat("Pays concernés   :", n_distinct(wars_prep$iso3), "  [attendu : 27]\n\n")

cat("=== Expansion pays-année ===\n")

wars_expanded <- wars_prep %>%
  rowwise() %>%
  mutate(annee = list(seq(start_alt_eff, end_alt_eff))) %>%
  unnest(annee) %>%
  ungroup()

cat("Lignes après expansion :", nrow(wars_expanded), "  [attendu : 296]\n\n")

cat("=== Agrégation ===\n")

wars_agg <- wars_expanded %>%
  mutate(
    war_interstate = as.integer(type == "inter"),
    war_intrastate = as.integer(type == "intra"),
    war_extrastate = as.integer(type == "extra")
  ) %>%
  group_by(iso3, annee) %>%
  summarise(
    war_any         = 1L,
    war_interstate  = max(war_interstate, na.rm = TRUE),
    war_intrastate  = max(war_intrastate, na.rm = TRUE),
    war_extrastate  = max(war_extrastate, na.rm = TRUE),
    war_n_conflicts = n(),
    war_casualties  = sum(casualties, na.rm = TRUE),
    shock_caspop = ifelse(all(is.na(shock_caspop_home)), NA_real_,
                          max(shock_caspop_home, na.rm = TRUE)),
    shock_dest   = ifelse(all(is.na(shock_dest_home)), NA_real_,
                          max(shock_dest_home,   na.rm = TRUE)),
    buildup      = ifelse(all(is.na(buildup)),    NA_real_,
                          max(buildup,    na.rm = TRUE)),
    drawdown     = ifelse(all(is.na(drawdown)),   NA_real_,
                          min(drawdown,   na.rm = TRUE)),
    destruction  = ifelse(all(is.na(destruction)), NA_real_,
                          max(destruction, na.rm = TRUE)),
    .groups = "drop"
  )

cat("Pays-années guerre active :", nrow(wars_agg), "  [attendu : 262]\n\n")

cat("=== Post-guerre ===\n")

post_war <- wars_prep %>%
  filter(end_alt_eff < 2022L) %>%
  group_by(iso3, warname) %>%
  summarise(annee_fin = max(end_alt_eff), .groups = "drop") %>%
  rowwise() %>%
  mutate(annee = list(seq(annee_fin + 1L, min(annee_fin + 3L, 2022L)))) %>%
  unnest(annee) %>%
  select(iso3, annee) %>%
  distinct() %>%
  mutate(post_war_3y = 1L)

cat("Pays-années post-guerre :", nrow(post_war), "  [attendu : 130]\n\n")

cat("=== Fusion sur le panel (1 980 obs) ===\n")

wars_layer <- panel %>%
  select(iso3, annee) %>%

  left_join(wars_agg, by = c("iso3", "annee")) %>%
  left_join(post_war, by = c("iso3", "annee")) %>%

  mutate(
    across(c(war_any, war_interstate, war_intrastate,
             war_extrastate, war_n_conflicts),
           ~replace_na(.x, 0L)),
    across(c(war_casualties, shock_caspop, shock_dest,
             buildup, drawdown, destruction),
           ~replace_na(.x, 0.0)),
    post_war_3y = replace_na(post_war_3y, 0L),

    log_casualties = log1p(war_casualties),
    war_or_postwar = as.integer(war_any == 1L | post_war_3y == 1L),
    war_severe     = as.integer(war_interstate == 1L | war_intrastate == 1L)
  ) %>%

  group_by(iso3) %>%
  mutate(ever_at_war = as.integer(any(war_any == 1L))) %>%
  ungroup() %>%

  select(-iso3, -annee)

panel_v2 <- bind_cols(panel, wars_layer) %>%

  mutate(
    war_fr          = war_any * fr_any,
    war_bbr         = war_any * bbr,
    war_sanction    = war_any * sanction,
    war_sanction_fr = war_any * sanction * fr_any
  )

cat("=== Contrôle qualité ===\n")

stopifnot("Panel ≠ 1 980 obs" = nrow(panel_v2) == 1980)
cat("Intégrité : 1 980 observations confirmées\n")
cat("Variables  :", ncol(panel_v2), "(panel initial 60 + war 20)\n\n")

cat("Distribution war_any :\n")
print(table(panel_v2$war_any))

cat("\nPays-années par type :\n")
cat("  Interstate  :", sum(panel_v2$war_interstate), "\n")
cat("  Intrastate  :", sum(panel_v2$war_intrastate), "\n")
cat("  Extrastate  :", sum(panel_v2$war_extrastate), "\n")
cat("  Post-guerre :", sum(panel_v2$post_war_3y),    "\n")
cat("  Ever-at-war :", sum(panel_v2$ever_at_war),    "(pays-années)\n")

cat("\nPays avec guerre (pays-années actifs) :\n")
panel_v2 %>%
  filter(war_any == 1L) %>%
  count(iso3, sort = TRUE) %>%
  print(n = 30)

cat("\nValeurs manquantes : nouvelles variables :\n")
new_vars <- c("war_any","war_interstate","war_intrastate","war_extrastate",
              "war_n_conflicts","war_casualties","log_casualties",
              "post_war_3y","war_or_postwar","war_severe","ever_at_war",
              "war_fr","war_bbr","war_sanction","war_sanction_fr")
panel_v2 %>%
  select(all_of(new_vars)) %>%
  summarise(across(everything(), ~sum(is.na(.)))) %>%
  pivot_longer(everything(), names_to = "variable", values_to = "n_missing") %>%
  filter(n_missing > 0) %>%
  { if (nrow(.) == 0) cat("  Aucune valeur manquante\n") else print(.) }

saveRDS(panel_v2, "data/processed/panel_analytique_FINAL_v2.rds")
cat("\nSauvegardé : data/processed/panel_analytique_FINAL_v2.rds\n")
cat("   Dimensions  :", nrow(panel_v2), "obs ×", ncol(panel_v2), "variables\n")
cat("   Prochaine étape : 06_LP_estimation.R\n\n")

