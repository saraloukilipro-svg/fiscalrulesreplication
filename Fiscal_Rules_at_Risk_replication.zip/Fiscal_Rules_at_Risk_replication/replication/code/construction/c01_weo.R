setwd(Sys.getenv("FRR_ROOT", "."))

suppressPackageStartupMessages({ library(tidyverse); library(janitor); library(writexl) })

dir.create("data/processed", showWarnings=FALSE, recursive=TRUE)
dir.create("output",         showWarnings=FALSE, recursive=TRUE)
cat("=== SCRIPT 01 : WEO FMI ===\n\n")

pays_panel <- tribble(
  ~iso3,  ~pays_weo,                                            ~region, ~mena,
  "MAR",  "Morocco",                                            "MENA",  1,
  "TUN",  "Tunisia",                                            "MENA",  1,
  "DZA",  "Algeria",                                            "MENA",  1,
  "EGY",  "Egypt, Arab Republic of",                           "MENA",  1,
  "JOR",  "Jordan",                                             "MENA",  1,
  "SAU",  "Saudi Arabia",                                       "MENA",  1,
  "ARE",  "United Arab Emirates",                               "MENA",  1,
  "KWT",  "Kuwait",                                             "MENA",  1,
  "QAT",  "Qatar",                                              "MENA",  1,
  "BHR",  "Bahrain, Kingdom of",                               "MENA",  1,
  "OMN",  "Oman",                                               "MENA",  1,
  "IRN",  "Iran, Islamic Republic of",                         "MENA",  1,
  "IRQ",  "Iraq",                                               "MENA",  1,
  "LBN",  "Lebanon",                                            "MENA",  1,
  "LBY",  "Libya",                                              "MENA",  1,
  "GHA",  "Ghana",                                              "SSA",   0,
  "SEN",  "Senegal",                                            "SSA",   0,
  "KEN",  "Kenya",                                              "SSA",   0,
  "NGA",  "Nigeria",                                            "SSA",   0,
  "ZAF",  "South Africa",                                       "SSA",   0,
  "CIV",  "Côte d'Ivoire",                                     "SSA",   0,
  "CMR",  "Cameroon",                                           "SSA",   0,
  "RWA",  "Rwanda",                                             "SSA",   0,
  "TZA",  "Tanzania, United Republic of",                      "SSA",   0,
  "UGA",  "Uganda",                                             "SSA",   0,
  "ZMB",  "Zambia",                                             "SSA",   0,
  "MOZ",  "Mozambique, Republic of",                           "SSA",   0,
  "ETH",  "Ethiopia, The Federal Democratic Republic of",      "SSA",   0,
  "MDG",  "Madagascar, Republic of",                           "SSA",   0,
  "BFA",  "Burkina Faso",                                       "SSA",   0,
  "BRA",  "Brazil",                                             "LAC",   0,
  "MEX",  "Mexico",                                             "LAC",   0,
  "ARG",  "Argentina",                                          "LAC",   0,
  "COL",  "Colombia",                                           "LAC",   0,
  "CHL",  "Chile",                                              "LAC",   0,
  "PER",  "Peru",                                               "LAC",   0,
  "ECU",  "Ecuador",                                            "LAC",   0,
  "BOL",  "Bolivia",                                            "LAC",   0,
  "PRY",  "Paraguay",                                           "LAC",   0,
  "URY",  "Uruguay",                                            "LAC",   0,
  "GTM",  "Guatemala",                                          "LAC",   0,
  "HND",  "Honduras",                                           "LAC",   0,
  "JAM",  "Jamaica",                                            "LAC",   0,
  "TTO",  "Trinidad and Tobago",                                "LAC",   0,
  "PAN",  "Panama",                                             "LAC",   0,
  "IND",  "India",                                              "ASIA",  0,
  "IDN",  "Indonesia",                                          "ASIA",  0,
  "PHL",  "Philippines",                                        "ASIA",  0,
  "THA",  "Thailand",                                           "ASIA",  0,
  "BGD",  "Bangladesh",                                         "ASIA",  0,
  "PAK",  "Pakistan",                                           "ASIA",  0,
  "VNM",  "Vietnam",                                            "ASIA",  0,
  "MYS",  "Malaysia",                                           "ASIA",  0,
  "LKA",  "Sri Lanka",                                          "ASIA",  0,
  "NPL",  "Nepal",                                              "ASIA",  0,
  "TUR",  "Türkiye, Republic of",                              "EEU",   0,
  "UKR",  "Ukraine",                                            "EEU",   0,
  "RUS",  "Russian Federation",                                 "EEU",   0,
  "KAZ",  "Kazakhstan, Republic of",                           "EEU",   0,
  "GEO",  "Georgia",                                            "EEU",   0
)

cat("Panel :", nrow(pays_panel), "pays | MENA :", sum(pays_panel$mena), "\n\n")
saveRDS(pays_panel, "data/processed/pays_panel.rds")
write_csv(pays_panel, "data/processed/pays_panel.csv")

cat("Chargement WEOOct2023all.csv...\n")

weo_raw <- read_csv("data/raw/WEOOct2023all.csv",
                    locale = locale(encoding = "UTF-8"),
                    show_col_types = FALSE)

cat("WEO brut :", nrow(weo_raw), "obs\n")

indicateurs_weo <- c(
  "Gross debt, General government, Percent of GDP"                                    = "dette_pib",
  "Primary net lending (+) / net borrowing (-), General government, Percent of GDP"  = "solde_prim",
  "Revenue, General government, Percent of GDP"                                       = "rev_pub",
  "Expenditure, General government, Percent of GDP"                                   = "dep_pub",
  "Gross domestic product (GDP), Constant prices, Percent change"                     = "pib_croissance",
  "All Items, Consumer price index (CPI), Period average, percent change"             = "inflation",
  "Current account balance (credit less debit), Percent of GDP"                       = "balance_cour"
)

year_cols <- as.character(1990:2022)

weo_clean <- weo_raw %>%
  filter(COUNTRY %in% pays_panel$pays_weo,
         INDICATOR %in% names(indicateurs_weo)) %>%
  select(COUNTRY, INDICATOR, all_of(year_cols)) %>%
  mutate(var_nom = indicateurs_weo[INDICATOR]) %>%
  select(-INDICATOR) %>%
  pivot_longer(cols = all_of(year_cols),
               names_to = "annee", values_to = "valeur") %>%
  mutate(annee  = as.integer(annee),
         valeur = suppressWarnings(as.numeric(valeur))) %>%
  pivot_wider(names_from = var_nom, values_from = valeur,
              values_fn = mean) %>%
  left_join(pays_panel %>% select(iso3, pays_weo),
            by = c("COUNTRY" = "pays_weo")) %>%
  select(iso3, annee, dette_pib, solde_prim, rev_pub,
         dep_pub, pib_croissance, inflation, balance_cour) %>%
  filter(!is.na(iso3)) %>%
  arrange(iso3, annee)

cat("WEO nettoyé :", nrow(weo_clean), "obs |",
    n_distinct(weo_clean$iso3), "pays\n\n")

fed_rate <- tibble(
  annee = 1990:2022,
  fed_rate = c(8.10,5.69,3.52,3.02,4.21,5.83,5.30,5.46,5.35,4.97,
               6.24,3.88,1.67,1.13,1.35,3.22,4.97,5.02,1.92,0.24,
               0.18,0.10,0.14,0.11,0.09,0.13,0.40,1.00,1.83,2.16,
               0.36,0.08,1.68)
)

panel_base <- expand_grid(iso3 = pays_panel$iso3, annee = 1990:2022) %>%
  left_join(pays_panel %>% select(iso3, region, mena), by = "iso3") %>%
  left_join(weo_clean,  by = c("iso3","annee")) %>%
  left_join(fed_rate,   by = "annee") %>%
  arrange(iso3, annee)

cat("Panel :", nrow(panel_base), "obs ×",
    ncol(panel_base), "variables\n\n")

cat("--- VALEURS MANQUANTES (%) ---\n")
panel_base %>%
  summarise(across(where(is.numeric),
                   ~round(mean(is.na(.))*100,1))) %>%
  pivot_longer(everything(), names_to="var", values_to="pct") %>%
  arrange(desc(pct)) %>% print(n=12)

cat("\n--- STATS PAR RÉGION ---\n")
panel_base %>%
  group_by(region) %>%
  summarise(n_pays    = n_distinct(iso3),
            dette_moy = round(mean(dette_pib,      na.rm=TRUE),1),
            solde_moy = round(mean(solde_prim,     na.rm=TRUE),1),
            pib_moy   = round(mean(pib_croissance, na.rm=TRUE),1),
            .groups   = "drop") %>% print()

saveRDS(panel_base, "data/processed/panel_step1_weo.rds")
write_csv(panel_base, "data/processed/panel_step1_weo.csv")
writexl::write_xlsx(list(panel=panel_base, pays=pays_panel),
                    "output/step1_weo.xlsx")

cat("\nSCRIPT 01 TERMINÉ\n")
