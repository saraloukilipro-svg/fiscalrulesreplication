setwd(Sys.getenv("FRR_ROOT", "."))
suppressPackageStartupMessages({ library(tidyverse); library(readxl); library(janitor); library(writexl) })
cat("=== SCRIPT 02 : GPR ===\n\n")

pays_panel <- readRDS("data/processed/pays_panel.rds")

cat("Chargement GPR_historical_data.xls...\n")

gpr_raw <- read_excel(
  "data/raw/GPR_historical_data.xls",
  sheet     = 1,
  col_types = c("date", rep("numeric", 114))
)

cat("GPR brut :", nrow(gpr_raw), "observations mensuelles\n")
cat("Période  :", format(min(gpr_raw$month, na.rm=TRUE), "%Y-%m"),
    "-", format(max(gpr_raw$month, na.rm=TRUE), "%Y-%m"), "\n\n")

gprc_cols  <- names(gpr_raw)[str_starts(names(gpr_raw), "GPRC_")]
pays_dispo <- str_remove(gprc_cols, "GPRC_")
cat("Pays GPR disponibles (", length(pays_dispo), ") :",
    paste(pays_dispo, collapse=", "), "\n\n")

cat("Agrégation annuelle (1990–2022)...\n")

gpr_annuel <- gpr_raw %>%
  mutate(annee = as.integer(format(as.Date(month), "%Y"))) %>%
  mutate(GPR = suppressWarnings(as.numeric(GPR))) %>%
  filter(annee >= 1990, annee <= 2022, !is.na(GPR), is.finite(GPR)) %>%
  mutate(across(starts_with("GPRC_"), as.numeric)) %>%

  mutate(
    gpr_EGY_m = GPRC_EGY * GPR,
    gpr_SAU_m = GPRC_SAU * GPR,
    gpr_TUN_m = GPRC_TUN * GPR,
    gpr_ARG_m = GPRC_ARG * GPR,
    gpr_BRA_m = GPRC_BRA * GPR,
    gpr_CHL_m = GPRC_CHL * GPR,
    gpr_COL_m = GPRC_COL * GPR,
    gpr_MEX_m = GPRC_MEX * GPR,
    gpr_PER_m = GPRC_PER * GPR,
    gpr_IND_m = GPRC_IND * GPR,
    gpr_IDN_m = GPRC_IDN * GPR,
    gpr_MYS_m = GPRC_MYS * GPR,
    gpr_PHL_m = GPRC_PHL * GPR,
    gpr_THA_m = GPRC_THA * GPR,
    gpr_VNM_m = GPRC_VNM * GPR,
    gpr_RUS_m = GPRC_RUS * GPR,
    gpr_TUR_m = GPRC_TUR * GPR,
    gpr_UKR_m = GPRC_UKR * GPR,
    gpr_ZAF_m = GPRC_ZAF * GPR
  ) %>%
  group_by(annee) %>%
  summarise(
    gpr_global    = mean(GPR,        na.rm = TRUE),
    gpr_threats   = mean(GPRT,       na.rm = TRUE),
    gpr_acts      = mean(GPRA,       na.rm = TRUE),
    gpr_sd        = sd(GPR,          na.rm = TRUE),

    gpr_EGY       = mean(gpr_EGY_m,  na.rm = TRUE),
    gpr_SAU       = mean(gpr_SAU_m,  na.rm = TRUE),
    gpr_TUN       = mean(gpr_TUN_m,  na.rm = TRUE),
    gpr_ARG       = mean(gpr_ARG_m,  na.rm = TRUE),
    gpr_BRA       = mean(gpr_BRA_m,  na.rm = TRUE),
    gpr_CHL       = mean(gpr_CHL_m,  na.rm = TRUE),
    gpr_COL       = mean(gpr_COL_m,  na.rm = TRUE),
    gpr_MEX       = mean(gpr_MEX_m,  na.rm = TRUE),
    gpr_PER       = mean(gpr_PER_m,  na.rm = TRUE),
    gpr_IND       = mean(gpr_IND_m,  na.rm = TRUE),
    gpr_IDN       = mean(gpr_IDN_m,  na.rm = TRUE),
    gpr_MYS       = mean(gpr_MYS_m,  na.rm = TRUE),
    gpr_PHL       = mean(gpr_PHL_m,  na.rm = TRUE),
    gpr_THA       = mean(gpr_THA_m,  na.rm = TRUE),
    gpr_VNM       = mean(gpr_VNM_m,  na.rm = TRUE),
    gpr_RUS       = mean(gpr_RUS_m,  na.rm = TRUE),
    gpr_TUR       = mean(gpr_TUR_m,  na.rm = TRUE),
    gpr_UKR       = mean(gpr_UKR_m,  na.rm = TRUE),
    gpr_ZAF       = mean(gpr_ZAF_m,  na.rm = TRUE),
    .groups = "drop"
  )

cat("GPR annuel :", nrow(gpr_annuel), "années\n\n")

cat("Construction choc GPR (résidu AR1)...\n")

gpr_ar1 <- gpr_annuel %>%
  arrange(annee) %>%
  mutate(gpr_lag1 = lag(gpr_global, 1))

ar1_data <- gpr_ar1 %>% filter(!is.na(gpr_lag1))
ar1_fit  <- lm(gpr_global ~ gpr_lag1, data = ar1_data)
cat("AR(1) GPR R2 :", round(summary(ar1_fit)$r.squared, 3), "\n")
cat("AR(1) GPR coef lag1 :", round(coef(ar1_fit)[2], 3), "\n")

res_full <- rep(NA_real_, nrow(gpr_ar1))
res_full[!is.na(gpr_ar1$gpr_lag1)] <- residuals(ar1_fit)

gpr_annuel <- gpr_ar1 %>%
  mutate(
    gpr_choc  = res_full,
    gpr_log   = log(gpr_global),
    gpr_norm  = as.numeric(scale(gpr_global))
  ) %>%
  select(-gpr_lag1)

cat("Construction panel GPR (pays × années)...\n")

gprc_map <- c(
  "EGY"="gpr_EGY", "SAU"="gpr_SAU", "TUN"="gpr_TUN",
  "ARG"="gpr_ARG", "BRA"="gpr_BRA", "CHL"="gpr_CHL",
  "COL"="gpr_COL", "MEX"="gpr_MEX", "PER"="gpr_PER",
  "IND"="gpr_IND", "IDN"="gpr_IDN", "MYS"="gpr_MYS",
  "PHL"="gpr_PHL", "THA"="gpr_THA", "VNM"="gpr_VNM",
  "RUS"="gpr_RUS", "TUR"="gpr_TUR", "UKR"="gpr_UKR",
  "ZAF"="gpr_ZAF"
)

panel_gpr <- expand_grid(iso3 = pays_panel$iso3,
                         annee = 1990:2022) %>%
  left_join(pays_panel %>% select(iso3, region, mena),
            by = "iso3") %>%
  left_join(gpr_annuel %>% select(annee, gpr_global, gpr_threats,
                                   gpr_acts, gpr_sd, gpr_choc,
                                   gpr_log, gpr_norm),
            by = "annee") %>%

  left_join(
    gpr_annuel %>%
      select(annee, all_of(unname(gprc_map))) %>%
      pivot_longer(-annee, names_to="gpr_col", values_to="gpr_pays_val") %>%
      mutate(iso3 = names(gprc_map)[match(gpr_col, gprc_map)]) %>%
      select(iso3, annee, gpr_pays_val),
    by = c("iso3","annee")
  ) %>%

  mutate(gpr_pays = coalesce(gpr_pays_val, gpr_global)) %>%
  select(-gpr_pays_val) %>%
  arrange(iso3, annee)

cat("Panel GPR :", nrow(panel_gpr), "obs\n")
cat("Pays avec GPR spécifique :", length(gprc_map), "/", nrow(pays_panel), "\n")
cat("Pays MENA avec GPR spécifique : EGY, SAU, TUN\n")
cat("Autres MENA : GPR global utilisé comme proxy\n\n")

cat("--- GPR PAR PAYS MENA ---\n")
panel_gpr %>%
  filter(mena == 1) %>%
  group_by(iso3) %>%
  summarise(
    gpr_moy       = round(mean(gpr_pays,    na.rm=TRUE), 1),
    gpr_max       = round(max(gpr_pays,     na.rm=TRUE), 1),
    annee_max_gpr = annee[which.max(gpr_pays)],
    .groups = "drop"
  ) %>%
  arrange(desc(gpr_moy)) %>%
  print()

panel_step1 <- readRDS("data/processed/panel_step1_weo.rds")

panel_step2 <- panel_step1 %>%
  left_join(
    panel_gpr %>% select(iso3, annee, gpr_global, gpr_threats,
                         gpr_acts, gpr_sd, gpr_choc, gpr_log,
                         gpr_norm, gpr_pays),
    by = c("iso3","annee")
  )

cat("Panel step 2 :", nrow(panel_step2), "obs ×",
    ncol(panel_step2), "variables\n\n")

saveRDS(panel_step2, "data/processed/panel_step2_gpr.rds")
write_csv(panel_step2, "data/processed/panel_step2_gpr.csv")
write_csv(gpr_annuel, "data/raw/gpr_annuel_construit.csv")
writexl::write_xlsx(list(panel=panel_step2, gpr_annuel=gpr_annuel),
                    "output/step2_gpr.xlsx")

cat("SCRIPT 02 TERMINÉ\n")

