library(tidyverse)
library(readxl)

select  <- dplyr::select
filter  <- dplyr::filter
mutate  <- dplyr::mutate
arrange <- dplyr::arrange

if ("package:plyr" %in% search()) {
  tryCatch(detach("package:plyr", unload = TRUE, force = TRUE),
           error = function(e) NULL)
}

setwd(Sys.getenv("FRR_ROOT", "."))
dir.create("output/latex",   showWarnings = FALSE, recursive = TRUE)
dir.create("output/figures", showWarnings = FALSE, recursive = TRUE)

cat("=== Script 21 v2 : Conseil Fiscal + Clause d'Echappement ===\n\n")

fmt_n <- function(x) formatC(x, format = "d", big.mark = ",")

cat("--- Sections 1-3 : Chargement et fusion (inchangees) ---\n")

frd_path <- "data/raw/FRD_dataset.xlsx"
if (!file.exists(frd_path))
  stop(paste0("Fichier non trouve : ", frd_path,
              "\nCopier FRD_dataset.xlsx dans data/raw/"))

frd_raw <- read_xlsx(frd_path, sheet = "Rules",
                     skip = 4, col_names = FALSE)

col_pos <- function(letter) {
  letter <- toupper(trimws(letter))
  result <- 0
  for (i in seq_len(nchar(letter)))
    result <- result * 26 +
      which(LETTERS == substr(letter, i, i))
  result
}

n_cols <- ncol(frd_raw)
cols_to_keep <- c(
  col_pos("A"), col_pos("B"), col_pos("C"),
  col_pos("BD"), col_pos("BE"), col_pos("BF"), col_pos("BG"),
  col_pos("BL"), col_pos("BM"), col_pos("BN"),
  col_pos("BS"), col_pos("BT"), col_pos("BW")
)
cols_to_keep <- cols_to_keep[cols_to_keep <= n_cols]

frd_sel <- frd_raw[, cols_to_keep]
names(frd_sel) <- c(
  "country_num","annee","pays_frd",
  "escape_er","escape_rr","escape_bbr","escape_dr",
  "escape_activation_type","escape_conditions","escape_horizon",
  "ind_body_assumptions","ind_body_monitoring","fc_report"
)[seq_len(ncol(frd_sel))]

clean_bin <- function(x) {
  x <- as.character(x)
  x[x == "-"] <- NA
  x[x == ""]  <- NA
  suppressWarnings(as.integer(x))
}

frd_sel <- frd_sel %>%
  mutate(
    annee                  = as.integer(annee),
    escape_er              = clean_bin(escape_er),
    escape_rr              = clean_bin(escape_rr),
    escape_bbr             = clean_bin(escape_bbr),
    escape_dr              = clean_bin(escape_dr),
    escape_activation_type = clean_bin(escape_activation_type),
    escape_conditions      = clean_bin(escape_conditions),
    ind_body_assumptions   = clean_bin(ind_body_assumptions),
    ind_body_monitoring    = clean_bin(ind_body_monitoring),
    fc_report              = clean_bin(fc_report)
  ) %>%
  mutate(
    escape_any   = as.integer(
      pmax(escape_er, escape_rr, escape_bbr, escape_dr,
           na.rm = TRUE) > 0),
    escape_bbr_bin = as.integer(
      !is.na(escape_bbr) & escape_bbr == 1),
    escape_formal  = as.integer(
      !is.na(escape_activation_type) &
        escape_activation_type == 1),
    fiscal_council_monitoring = as.integer(
      !is.na(ind_body_monitoring) & ind_body_monitoring == 1),
    fiscal_council_any   = as.integer(
      pmax(ind_body_assumptions, ind_body_monitoring, fc_report,
           na.rm = TRUE) > 0),
    fiscal_council_strict = as.integer(
      !is.na(ind_body_monitoring) & ind_body_monitoring == 1 &
        !is.na(fc_report)         & fc_report == 1)
  ) %>%
  filter(!is.na(annee), annee >= 1985)

iso3_to_frd <- c(
  IRN="Iran",   MAR="Morocco",
  BFA="Burkina Faso", CMR="Cameroon",
  KEN="Kenya",  RWA="Rwanda",  SEN="Senegal",
  TZA="Tanzania", UGA="Uganda", ZMB="Zambia",
  ARG="Argentina", BRA="Brazil", CHL="Chile",
  COL="Colombia", ECU="Ecuador", HND="Honduras",
  JAM="Jamaica", MEX="Mexico", PAN="Panama",
  PER="Peru", PRY="Paraguay", URY="Uruguay",
  IDN="Indonesia", IND="India", KAZ="Kazakhstan",
  LKA="Sri Lanka", MYS="Malaysia", PAK="Pakistan",
  THA="Thailand", VNM="Vietnam",
  GEO="Georgia", RUS="Russia"
)

frd_alt <- c(
  JOR="Jordan",  TUN="Tunisia",
  CIV="C\u00f4te d'Ivoire",
  NGA="Nigeria", ZAF="South Africa",
  TUR="T\u00fcrkiye", UKR="Ukraine"
)

frd_pays_uniques <- unique(frd_sel$pays_frd)

for (iso3 in names(frd_alt)) {
  pattern <- frd_alt[iso3]
  matches <- grep(pattern, frd_pays_uniques,
                  value = TRUE, ignore.case = TRUE)
  if (length(matches) == 1) iso3_to_frd[iso3] <- matches[1]
}

panel <- readRDS("data/processed/panel_analytique_FINAL_v3.rds") %>%
  arrange(iso3, annee)

frd_iso3 <- frd_sel %>%
  filter(!is.na(pays_frd)) %>%
  mutate(iso3 = NA_character_) %>%
  as.data.frame()

for (iso3_code in names(iso3_to_frd)) {
  nom <- iso3_to_frd[iso3_code]
  idx <- which(frd_iso3$pays_frd == nom |
               grepl(nom, frd_iso3$pays_frd, ignore.case = TRUE))
  if (length(idx) > 0) frd_iso3$iso3[idx] <- iso3_code
}

frd_panel <- frd_iso3 %>%
  filter(!is.na(iso3), iso3 %in% unique(panel$iso3),
         annee >= 1990, annee <= 2022) %>%
  dplyr::select(
    iso3, annee,
    escape_any, escape_bbr_bin, escape_formal,
    escape_er, escape_rr, escape_bbr, escape_dr,
    escape_activation_type, escape_conditions,
    ind_body_assumptions, ind_body_monitoring, fc_report,
    fiscal_council_monitoring, fiscal_council_any,
    fiscal_council_strict
  ) %>%
  arrange(iso3, annee) %>%
  as_tibble()

panel_ext <- panel %>%
  left_join(frd_panel, by = c("iso3", "annee"))

cat(sprintf("  panel_ext : %d x %d | %d pays avec FRD\n",
            nrow(panel_ext), ncol(panel_ext),
            n_distinct(frd_panel$iso3)))

pays_dans_frd <- unique(frd_panel$iso3)
pays_sans_frd <- setdiff(unique(panel$iso3), pays_dans_frd)
cat(sprintf("  Pays couverts : %d/60 | Absents : %d/60\n",
            length(pays_dans_frd), length(pays_sans_frd)))

saveRDS(panel_ext, "data/processed/panel_frd_extended.rds")
cat("  OK : panel_frd_extended.rds\n\n")
