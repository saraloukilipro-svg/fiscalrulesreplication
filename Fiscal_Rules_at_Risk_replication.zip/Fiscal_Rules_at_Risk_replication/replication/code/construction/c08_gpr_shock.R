suppressPackageStartupMessages(library(tidyverse))
setwd(Sys.getenv("FRR_ROOT", "."))
panel <- readRDS("data/processed/panel_analytique_FINAL_v3.rds") %>% arrange(iso3, annee) %>%
  group_by(iso3) %>% mutate(gpr_pays_lag1 = lag(gpr_pays, 1)) %>% ungroup()
panel$gpr_choc_pays <- NA_real_
for (pays in unique(panel$iso3)) {
  idx <- panel$iso3 == pays & !is.na(panel$gpr_pays) & !is.na(panel$gpr_pays_lag1)
  if (sum(idx) > 3) panel$gpr_choc_pays[idx] <- residuals(lm(gpr_pays ~ gpr_pays_lag1, data = panel[idx, ]))
}
saveRDS(panel, "data/processed/panel_analytique_FINAL_v3.rds")
cat("c08 : gpr_choc_pays ajouté ;", sum(!is.na(panel$gpr_choc_pays)), "observations\n")
