setwd(Sys.getenv("FRR_ROOT", "."))
suppressPackageStartupMessages({ library(tidyverse); library(readxl); library(writexl) })
cat("=== SCRIPT 03 : REGLES BUDGETAIRES (FRD IMF) ===\n\n")

pays_panel <- readRDS("data/processed/pays_panel.rds")

cat("Chargement FRD_dataset.xlsx (feuille Rules)...\n")

frd_raw <- read_excel(
  "data/raw/FRD_dataset.xlsx",
  sheet     = "Rules",
  col_names = FALSE,
  skip      = 0
)

frd_data <- frd_raw[5:nrow(frd_raw), ]
colnames(frd_data) <- paste0("V", seq_len(ncol(frd_data)))

frd_data <- frd_data %>%
  rename(
    pays_frd     = V3,
    annee        = V2,
    er           = V4,
    rr           = V5,
    bbr          = V6,
    dr           = V7,
    fr_nat_count = V22
  ) %>%
  filter(!is.na(pays_frd), !is.na(annee)) %>%
  mutate(
    annee        = suppressWarnings(as.integer(annee)),
    er           = as.integer(er  == 1),
    rr           = as.integer(rr  == 1),
    bbr          = as.integer(bbr == 1),
    dr           = as.integer(dr  == 1),
    fr_nat_count = suppressWarnings(as.integer(as.numeric(fr_nat_count)))
  ) %>%
  replace_na(list(fr_nat_count = 0L)) %>%
  filter(!is.na(annee), annee >= 1990, annee <= 2022)

cat("FRD nettoyé :", nrow(frd_data), "obs |",
    n_distinct(frd_data$pays_frd), "pays\n\n")

frd_to_iso3 <- c(
  "Morocco"         = "MAR",
  "Iran"            = "IRN",
  "Côte d'Ivoire"   = "CIV",
  "Senegal"         = "SEN",
  "Kenya"           = "KEN",
  "Burkina Faso"    = "BFA",
  "Cameroon"        = "CMR",
  "Rwanda"          = "RWA",
  "Tanzania"        = "TZA",
  "Uganda"          = "UGA",
  "Zambia"          = "ZMB",
  "Brazil"          = "BRA",
  "Mexico"          = "MEX",
  "Argentina"       = "ARG",
  "Colombia"        = "COL",
  "Chile"           = "CHL",
  "Peru"            = "PER",
  "Ecuador"         = "ECU",
  "Honduras"        = "HND",
  "Jamaica"         = "JAM",
  "Paraguay"        = "PRY",
  "Uruguay"         = "URY",
  "Panama"          = "PAN",
  "India"           = "IND",
  "Indonesia"       = "IDN",
  "Thailand"        = "THA",
  "Pakistan"        = "PAK",
  "Vietnam"         = "VNM",
  "Malaysia"        = "MYS",
  "Sri Lanka"       = "LKA",
  "Kazakhstan"      = "KAZ",
  "Georgia"         = "GEO",
  "Russia"          = "RUS"
)

iso3_fr_zero <- c(
  "TUN","DZA","EGY","JOR","SAU","ARE","KWT","QAT",
  "BHR","OMN","IRQ","LBN","LBY",
  "GHA","NGA","ZAF","MOZ","ETH","MDG",
  "BOL","GTM","TTO",
  "PHL","BGD","NPL",
  "TUR","UKR"
)

cat("Pays lus depuis FRD :", length(frd_to_iso3), "\n")
cat("Pays codés FR=0     :", length(iso3_fr_zero), "\n\n")

fr_frd <- frd_data %>%
  filter(pays_frd %in% names(frd_to_iso3)) %>%
  mutate(iso3 = frd_to_iso3[pays_frd]) %>%
  select(iso3, annee, bbr, dr, er, rr, fr_nat_count) %>%

  mutate(
    fr_nat_count = case_when(
      iso3 == "BRA" & bbr == 1 & fr_nat_count == 0 ~ 1L,
      TRUE ~ fr_nat_count
    )
  )

fr_zero <- expand_grid(iso3 = iso3_fr_zero, annee = 1990:2022) %>%
  mutate(bbr = 0L, dr = 0L, er = 0L, rr = 0L, fr_nat_count = 0L)

cat("Assemblage panel FR complet...\n")

fr_panel <- bind_rows(fr_frd, fr_zero) %>%
  mutate(
    fr_any         = as.integer(bbr + dr + er + rr > 0),
    fr_count       = bbr + dr + er + rr,
    fr_national    = as.integer(fr_nat_count > 0),
    fr_supra_only  = as.integer(fr_any == 1 & fr_nat_count == 0)
  ) %>%
  left_join(pays_panel %>% select(iso3, region, mena), by = "iso3") %>%
  group_by(iso3) %>%
  mutate(
    annee_adoption    = if (any(fr_any == 1))
                          min(annee[fr_any == 1]) else NA_integer_,
    annee_adopt_nat   = if (any(fr_national == 1))
                          min(annee[fr_national == 1]) else NA_integer_,
    time_since_fr     = if_else(!is.na(annee_adoption),
                                annee - annee_adoption, NA_integer_),
    time_since_fr_nat = if_else(!is.na(annee_adopt_nat),
                                annee - annee_adopt_nat, NA_integer_),
    post_fr           = as.integer(!is.na(annee_adoption) &
                                     annee >= annee_adoption),
    post_fr_nat       = as.integer(!is.na(annee_adopt_nat) &
                                     annee >= annee_adopt_nat),
    cohort_fr         = annee_adoption,
    cohort_fr_nat     = annee_adopt_nat
  ) %>%
  ungroup() %>%
  arrange(iso3, annee)

manquants <- setdiff(pays_panel$iso3, unique(fr_panel$iso3))
if (length(manquants) > 0) {
  cat("ATTENTION : Pays non couverts :", paste(manquants, collapse=", "), "\n")
} else {
  cat("Tous les", nrow(pays_panel), "pays du panel couverts\n\n")
}

cat("--- RÉCAPITULATIF PAR PAYS (adoptions) ---\n")

fr_recap <- fr_panel %>%
  group_by(iso3, region, mena) %>%
  summarise(
    adopt_fr_any = first(annee_adoption),
    adopt_fr_nat = first(annee_adopt_nat),
    bbr_debut    = if (any(bbr==1)) min(annee[bbr==1]) else NA_integer_,
    dr_debut     = if (any(dr==1))  min(annee[dr==1])  else NA_integer_,
    er_debut     = if (any(er==1))  min(annee[er==1])  else NA_integer_,
    rr_debut     = if (any(rr==1))  min(annee[rr==1])  else NA_integer_,
    supra_only   = any(fr_supra_only == 1),
    .groups = "drop"
  ) %>%
  filter(!is.na(adopt_fr_any)) %>%
  arrange(region, adopt_fr_any)

print(fr_recap, n = 40)

cat("\nNombre de pays avec FR :", nrow(fr_recap), "/", nrow(pays_panel), "\n")
cat("  dont FR nationale   :", sum(!is.na(fr_recap$adopt_fr_nat)), "\n")
cat("  dont FR supra only  :", sum(fr_recap$supra_only), "\n\n")

cat("--- TAUX D'ADOPTION PAR RÉGION ---\n")
fr_panel %>%
  group_by(region) %>%
  summarise(
    n_pays       = n_distinct(iso3),
    pct_fr_any   = round(mean(fr_any)      * 100, 1),
    pct_fr_nat   = round(mean(fr_national) * 100, 1),
    pct_bbr      = round(mean(bbr)         * 100, 1),
    pct_dr       = round(mean(dr)          * 100, 1),
    pct_er       = round(mean(er)          * 100, 1),
    .groups = "drop"
  ) %>% print()

cat("\n--- FOCUS MENA (vérification) ---\n")
fr_panel %>%
  filter(mena == 1) %>%
  group_by(iso3) %>%
  summarise(
    fr_actif    = sum(fr_any),
    bbr_actif   = sum(bbr),
    adopt_fr    = first(annee_adoption),
    .groups = "drop"
  ) %>%
  arrange(iso3) %>% print()

cat("\n--- FOCUS MAROC (traitement central MENA) ---\n")
fr_panel %>%
  filter(iso3 == "MAR", annee >= 2012) %>%
  select(iso3, annee, bbr, fr_any, fr_national, post_fr, time_since_fr) %>%
  print()

panel_step2 <- readRDS("data/processed/panel_step2_gpr.rds")

panel_step3 <- panel_step2 %>%
  left_join(
    fr_panel %>% select(iso3, annee, bbr, dr, er, rr,
                        fr_any, fr_count, fr_national, fr_supra_only,
                        annee_adoption, annee_adopt_nat,
                        time_since_fr, time_since_fr_nat,
                        post_fr, post_fr_nat,
                        cohort_fr, cohort_fr_nat),
    by = c("iso3", "annee")
  )

cat("\nPanel step 3 :", nrow(panel_step3), "obs ×",
    ncol(panel_step3), "variables\n\n")

saveRDS(panel_step3, "data/processed/panel_step3_fr.rds")
write_csv(panel_step3, "data/processed/panel_step3_fr.csv")

writexl::write_xlsx(
  list(
    panel      = panel_step3,
    fr_recap   = fr_recap,
    fr_detail  = fr_panel
  ),
  "output/step3_fiscal_rules.xlsx"
)

cat("SCRIPT 03 TERMINÉ\n")

