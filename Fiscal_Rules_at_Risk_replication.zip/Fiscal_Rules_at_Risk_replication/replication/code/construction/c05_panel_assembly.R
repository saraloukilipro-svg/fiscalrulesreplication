setwd(Sys.getenv("FRR_ROOT", "."))
suppressPackageStartupMessages({ library(tidyverse); library(writexl) })
cat("=== SCRIPT 05 : PANEL FINAL ===\n\n")

panel <- readRDS("data/processed/panel_step4_sanctions.rds")
pays_panel <- readRDS("data/processed/pays_panel.rds")

cat("Panel entrant :", nrow(panel), "obs ×", ncol(panel), "variables\n\n")

cat("Construction variables d'interaction...\n")

panel_final <- panel %>%

  mutate(

    gpr_x_fr        = gpr_global * fr_any,
    gpr_choc_x_fr   = gpr_choc   * fr_any,
    gpr_x_bbr       = gpr_global * bbr,

    sanc_x_fr       = sanction   * fr_any,

    gpr_x_sanc      = gpr_global * sanction,
    gpr_choc_x_sanc = gpr_choc   * sanction,

    gpr_x_sanc_x_fr = gpr_global * sanction * fr_any,

    mena_no_fr  = as.numeric(mena == 1 & fr_any == 0),
    mena_with_fr= as.numeric(mena == 1 & fr_any == 1),
    hydrocarb   = as.numeric(iso3 %in% c("SAU","ARE","KWT","QAT","BHR",
                                          "OMN","IRN","IRQ","LBY","DZA",
                                          "NGA","GHA"))
  ) %>%

  group_by(iso3) %>%
  arrange(annee, .by_group = TRUE) %>%
  mutate(
    dette_lag1     = lag(dette_pib,      1),
    solde_lag1     = lag(solde_prim,     1),
    pib_lag1       = lag(pib_croissance, 1),
    inflation_lag1 = lag(inflation,      1),
    gpr_lag1       = lag(gpr_global,     1),
    sanction_lag1  = lag(sanction,       1)
  ) %>%
  ungroup()

cat("Variables d'interaction construites\n\n")

cat("--- STRUCTURE DU PANEL FINAL ---\n")
cat("Observations :", nrow(panel_final), "\n")
cat("Variables    :", ncol(panel_final), "\n")
cat("Pays         :", n_distinct(panel_final$iso3), "\n")
cat("Période      : 1990 –", max(panel_final$annee), "\n\n")

cat("--- COMPLÉTION VARIABLES CLÉS ---\n")
vars_cles <- c("dette_pib","solde_prim","gpr_global","gpr_choc",
               "fr_any","sanction","pib_croissance","inflation",
               "fed_rate","balance_cour")

panel_final %>%
  summarise(across(all_of(vars_cles),
                   ~ paste0(round((1-mean(is.na(.)))*100,1),"%"))) %>%
  pivot_longer(everything(), names_to="variable", values_to="complétude") %>%
  print()

cat("\n--- TABLE 1 : STATISTIQUES DESCRIPTIVES ---\n")

table1 <- panel_final %>%
  select(dette_pib, solde_prim, gpr_global, gpr_pays,
         fr_any, sanction, sanction_fin, pib_croissance,
         inflation, balance_cour, fed_rate,

         ) %>%
  summarise(across(
    everything(),
    list(
      N   = ~ sum(!is.na(.)),
      Moy = ~ round(mean(.,  na.rm=TRUE), 2),
      SD  = ~ round(sd(.,    na.rm=TRUE), 2),
      Min = ~ round(min(.,   na.rm=TRUE), 2),
      Med = ~ round(median(.,na.rm=TRUE), 2),
      Max = ~ round(max(.,   na.rm=TRUE), 2)
    ),
    .names = "{.col}__{.fn}"
  )) %>%
  pivot_longer(everything(),
               names_to  = c("variable","stat"),
               names_sep = "__") %>%
  pivot_wider(names_from = stat, values_from = value) %>%
  arrange(variable)

print(table1, n=20)

cat("\n--- COMPARAISON MENA vs NON-MENA ---\n")
panel_final %>%
  group_by(mena) %>%
  summarise(
    groupe        = ifelse(first(mena)==1, "MENA", "Non-MENA"),
    n_pays        = n_distinct(iso3),
    dette_moy     = round(mean(dette_pib,      na.rm=TRUE), 1),
    solde_moy     = round(mean(solde_prim,     na.rm=TRUE), 1),
    gpr_moy       = round(mean(gpr_global,     na.rm=TRUE), 1),
    fr_pct        = round(mean(fr_any,         na.rm=TRUE)*100, 1),
    sanction_pct  = round(mean(sanction,       na.rm=TRUE)*100, 1),
    pib_moy       = round(mean(pib_croissance, na.rm=TRUE), 1),
    .groups = "drop"
  ) %>%
  select(groupe, everything(), -mena) %>%
  print()

cat("\nSauvegarde...\n")

saveRDS(panel_final, "data/processed/panel_analytique_FINAL.rds")

write_csv(panel_final, "data/processed/panel_analytique_FINAL.csv")

writexl::write_xlsx(
  list(
    PANEL_FINAL   = panel_final,
    TABLE1        = table1,
    PAYS          = pays_panel
  ),
  path = "output/PANEL_ANALYTIQUE_FINAL.xlsx"
)

write_csv(table1, "output/TABLE1_stats_descriptives.csv")

cat("\n")
cat("==============================================\n")
cat("BASE DE DONNÉES FINALISÉE\n")
cat("==============================================\n")
cat("FICHIERS PRINCIPAUX :\n")
cat("  data/processed/panel_analytique_FINAL.rds   ← R\n")
cat("  data/processed/panel_analytique_FINAL.csv   ← Stata/Python\n")
cat("  output/PANEL_ANALYTIQUE_FINAL.xlsx          ← Consultation\n")
cat("  output/TABLE1_stats_descriptives.csv        ← Table 1 papier\n")
cat("==============================================\n")

