suppressPackageStartupMessages({ library(data.table); library(ggplot2) })
g <- fread("data/processed/gpr_country_annual.csv")
p <- as.data.table(readRDS("data/processed/panel_analytique_FINAL_v3.rds"))[, .(iso3, annee, region)]
g <- merge(g, unique(p), by = c("iso3", "annee"))
g[, periode := cut(annee, c(1989, 2000, 2010, 2022), labels = c("1990-2000", "2001-2010", "2011-2022"))]
g[, region := factor(region)]
n_reg <- g[, .(n = uniqueN(iso3)), by = region]
g <- merge(g, n_reg, by = "region"); g[, region_lab := sprintf("%s (%d)", region, n)]
fig <- ggplot(g, aes(periode, 100 * gprc)) + geom_boxplot(outlier.size = .6, fill = "grey85") +
  facet_wrap(~region_lab, nrow = 1) + scale_y_log10() +
  labs(x = NULL, y = "Country GPR index (bp of articles, log scale)") +
  theme_bw(base_size = 10) + theme(axis.text.x = element_text(angle = 45, hjust = 1), panel.grid.minor = element_blank())
ggsave("../figures/figA2_gpr_distribution_by_region_period.pdf", fig, width = 9, height = 3.6)
print(g[, .(pays = paste(sort(unique(iso3)), collapse = " ")), by = region])
