suppressPackageStartupMessages({ library(data.table); library(readxl) })
RES <- "results"
ISO19 <- c("ARG", "BRA", "CHL", "COL", "EGY", "IDN", "IND", "MEX", "MYS", "PER",
           "PHL", "RUS", "SAU", "THA", "TUN", "TUR", "UKR", "VNM", "ZAF")

read_gpr <- function(f) {
  n <- length(read_excel(f, n_max = 1))
  x <- as.data.table(read_excel(f, sheet = 1, col_types = c("date", rep("numeric", n - 1))))
  x[, annee := as.integer(format(as.Date(month), "%Y"))]
  x[annee %between% c(1990, 2022)]
}
annualise <- function(x) {
  long <- melt(x, id.vars = c("month", "annee", "GPR"), measure.vars = paste0("GPRC_", ISO19),
               variable.name = "col", value.name = "gprc")
  long[, iso3 := sub("GPRC_", "", col)]
  long[, .(gprc = mean(gprc), gprc_x_gpr = mean(gprc * GPR), n_mois = .N), by = .(iso3, annee)]
}
ar1_resid <- function(x) {
  l <- shift(x); ok <- !is.na(x) & !is.na(l); r <- rep(NA_real_, length(x))
  r[ok] <- resid(lm(x[ok] ~ l[ok])); r
}

g_old <- annualise(read_gpr("data/raw/GPR_historical_data.xls"))
g_new <- annualise(read_gpr("data/raw/data_gpr_export_2026-11-04.xls"))
stopifnot(all(g_old$n_mois == 12))

p <- as.data.table(readRDS("data/processed/panel_analytique_FINAL_v3.rds"))[iso3 %in% ISO19, .(iso3, annee, gpr_pays)]
chk <- merge(p, g_old, by = c("iso3", "annee"))
chk[, `:=`(ecart_produit = gpr_pays - gprc_x_gpr, ecart_direct = gpr_pays - gprc)]
fwrite(chk, file.path(RES, "gpr_check_product.csv"))
cat(sprintf("Panel soumis = moyenne(GPRC x GPR) : écart max %.2e sur %d obs.\n", max(abs(chk$ecart_produit)), nrow(chk)))
cat(sprintf("Panel soumis = moyenne(GPRC)       : écart max %.2f\n", max(abs(chk$ecart_direct))))

vin <- merge(g_old[, .(iso3, annee, gprc_old = gprc)], g_new[, .(iso3, annee, gprc_new = gprc)], by = c("iso3", "annee"))
fwrite(vin, file.path(RES, "gpr_vintage_check.csv"))
cat(sprintf("Millésimes : corrélation %.5f ; écart absolu max %.4f ; écart relatif max %.2f %%\n",
            cor(vin$gprc_old, vin$gprc_new), max(abs(vin$gprc_old - vin$gprc_new)),
            100 * max(abs(vin$gprc_old - vin$gprc_new) / pmax(vin$gprc_old, 1e-9))))

setorder(g_old, iso3, annee)
g_old[, gpr_choc_c := ar1_resid(gprc), by = iso3]
setorder(g_new, iso3, annee)
g_new[, gpr_choc_c_vnew := ar1_resid(gprc), by = iso3]
out <- merge(g_old[, .(iso3, annee, gprc, gpr_choc_c)], g_new[, .(iso3, annee, gpr_choc_c_vnew)], by = c("iso3", "annee"))
fwrite(out, "data/processed/gpr_country_annual.csv")
cat(sprintf("Choc corrigé : %d obs., écart-type %.3f ; corrélation entre millésimes %.4f\n",
            sum(!is.na(out$gpr_choc_c)), sd(out$gpr_choc_c, na.rm = TRUE), cor(out$gpr_choc_c, out$gpr_choc_c_vnew, use = "complete.obs")))
print(out[iso3 %in% c("RUS", "UKR", "EGY", "TUN") & annee %in% c(2014, 2022)])
