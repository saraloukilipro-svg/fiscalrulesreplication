suppressPackageStartupMessages(library(data.table))

DK_LAG <- 2L

etoiles <- function(p) fifelse(is.na(p), "", fifelse(p < .01, "***", fifelse(p < .05, "**", fifelse(p < .10, "*", ""))))

fe_ols <- function(dat, dep, terms, fe = "twoway", extra_lin = NULL) {
  vars <- unique(c(dep, terms, extra_lin, "id", "t"))
  d <- dat[, ..vars]
  d <- d[complete.cases(d)]
  if (nrow(d) < 30) return(NULL)
  f_rhs <- c(terms, extra_lin, "factor(id)")
  if (fe %in% c("twoway", "trend")) f_rhs <- c(f_rhs, "factor(t)")
  if (fe == "trend") f_rhs <- c(f_rhs, "factor(id):t")
  X <- model.matrix(as.formula(paste("~", paste(f_rhs, collapse = " + "))), data = d)
  y <- d[[dep]]
  qx <- qr(X)
  keep <- qx$pivot[seq_len(qx$rank)]
  if (length(keep) < ncol(X)) { X <- X[, sort(keep), drop = FALSE]; qx <- qr(X) }
  b <- qr.coef(qx, y)
  u <- as.numeric(y - X %*% b)
  XtXinv <- chol2inv(qr.R(qx))
  colnames(XtXinv) <- rownames(XtXinv) <- colnames(X)[qx$pivot]
  XtXinv <- XtXinv[colnames(X), colnames(X)]
  G <- uniqueN(d$id)
  n_id_dummies <- sum(grepl("^factor\\(id\\)[^:]*$", colnames(X)))
  K <- ncol(X) - n_id_dummies
  list(d = d, X = X, y = y, qx = qx, b = b, u = u, XtXinv = XtXinv, n = nrow(d), G = G, K = K,
       Tn = uniqueN(d$t), terms = intersect(terms, colnames(X)))
}

a_rows <- function(m, T) m$XtXinv[T, , drop = FALSE] %*% t(m$X)

vcov_cluster <- function(m, T, u = m$u) {
  A <- a_rows(m, T)
  S <- rowsum(t(A * rep(u, each = length(T))), m$d$id)
  cadj <- m$G / (m$G - 1) * (m$n - 1) / (m$n - m$K)
  cadj * crossprod(S)
}

vcov_dk <- function(m, T, lag = DK_LAG) {
  A <- a_rows(m, T)
  S <- rowsum(t(A * rep(m$u, each = length(T))), m$d$t)
  S <- S[order(as.integer(rownames(S))), , drop = FALSE]
  meat <- crossprod(S)
  if (lag > 0) for (l in seq_len(lag)) {
    w <- 1 - l / (lag + 1)
    G1 <- crossprod(S[-(1:l), , drop = FALSE], S[1:(nrow(S) - l), , drop = FALSE])
    meat <- meat + w * (G1 + t(G1))
  }

  cadj <- (m$n - 1) / (m$n - ncol(m$X))
  cadj * meat
}

term_stats <- function(m, term, vc = "cluster", scale = 1, ident_ids = NULL) {
  na <- data.table(coef = NA_real_, se = NA_real_, p = NA_real_, lo90 = NA_real_, hi90 = NA_real_,
                   N = NA_integer_, n_ident = NA_integer_, par_ET = NA_real_)
  if (is.null(m) || !term %in% colnames(m$X)) return(na)
  V <- if (vc == "DK") vcov_dk(m, term) else vcov_cluster(m, term)
  b <- unname(m$b[term]); s <- sqrt(V[1, 1])
  df <- if (vc == "DK") m$Tn - 1 else m$G - 1
  data.table(coef = b, se = s, p = 2 * pt(-abs(b / s), df), lo90 = b - qt(.95, df) * s, hi90 = b + qt(.95, df) * s,
             N = m$n, n_ident = if (is.null(ident_ids)) NA_integer_ else uniqueN(m$d$id[m$d$id %in% ident_ids]),
             par_ET = b * scale)
}

lincom_stats <- function(m, a, b) {
  if (is.null(m) || !all(c(a, b) %in% colnames(m$X))) return(c(NA_real_, NA_real_, NA_real_))
  V <- vcov_cluster(m, c(a, b))
  est <- unname(m$b[a] + m$b[b]); se <- sqrt(V[1, 1] + V[2, 2] + 2 * V[1, 2])
  c(est, se, 2 * pt(-abs(est / se), m$G - 1))
}
diff_p <- function(m, a, b) {
  if (is.null(m) || !all(c(a, b) %in% colnames(m$X))) return(NA_real_)
  V <- vcov_cluster(m, c(a, b))
  est <- unname(m$b[a] - m$b[b])
  2 * pt(-abs(est / sqrt(V[1, 1] + V[2, 2] - 2 * V[1, 2])), m$G - 1)
}

wcb_p <- function(m, term, B = 999, seed = 20261027) {
  if (is.null(m) || !term %in% colnames(m$X)) return(NA_real_)
  yhat <- as.numeric(m$X %*% m$b); uhat <- m$u
  aj <- as.numeric(a_rows(m, term))
  se0 <- sqrt(vcov_cluster(m, term)[1, 1]); b0 <- unname(m$b[term]); t0 <- b0 / se0
  ids <- unique(m$d$id); idx <- match(m$d$id, ids)
  cadj <- m$G / (m$G - 1) * (m$n - 1) / (m$n - m$K)
  set.seed(seed); tb <- numeric(B)
  for (k in seq_len(B)) {
    w <- sample(c(-1, 1), length(ids), replace = TRUE)
    ys <- yhat + uhat * w[idx]
    bs <- sum(aj * ys)
    us <- qr.resid(m$qx, ys)
    ses <- sqrt(cadj * sum(rowsum(aj * us, m$d$id)^2))
    tb[k] <- (bs - b0) / ses
  }
  mean(abs(tb) >= abs(t0))
}

f_cs <- function(b, p) fifelse(is.na(b), "{}", sprintf("%.3f%s", b, etoiles(p)))
f_se <- function(se)   fifelse(is.na(se), "{}", sprintf("(%.3f)", se))
f_ci <- function(lo, hi) fifelse(is.na(lo), "{}", sprintf("{[%.3f, %.3f]}", lo, hi))
f_n  <- function(n)    fifelse(is.na(n), "{}", sprintf("{%s}", gsub(",", "\\,", formatC(n, format = "d", big.mark = ","), fixed = TRUE)))
f_p  <- function(p)    fifelse(is.na(p), "{--}", sprintf("%.3f", p))
f_2  <- function(x)    fifelse(is.na(x), "{}", sprintf("%.2f", x))

STARS_NOTE <- "\\textsuperscript{*}$p<0.10$, \\textsuperscript{**}$p<0.05$, \\textsuperscript{***}$p<0.01$."

write_tex <- function(path, caption, label, colspec, header, body, notes, size = "\\footnotesize") {

  lines <- c("\\begin{table}[!htbp]", "\\centering", sprintf("\\caption{%s}", caption),
             sprintf("\\label{%s}", label), size, "\\begin{adjustbox}{max width=\\textwidth}",
             sprintf("\\begin{tabular}{%s}", colspec), "\\toprule", header, "\\midrule", body,
             "\\bottomrule", "\\end{tabular}", "\\end{adjustbox}", "\\par\\vspace{0.4em}",
             "\\begin{minipage}{\\textwidth}\\footnotesize", sprintf("\\textit{Notes:} %s", notes),
             "\\end{minipage}", "\\end{table}")
  writeLines(lines, path)
}
