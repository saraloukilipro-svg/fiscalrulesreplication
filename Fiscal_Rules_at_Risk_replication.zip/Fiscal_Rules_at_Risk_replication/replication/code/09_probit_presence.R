suppressPackageStartupMessages({ library(data.table); library(ggplot2) })
TAB <- "../tables"; FIG <- "../figures"; RES <- "results"
p <- as.data.table(readRDS("data/processed/panel_analytique_FINAL_v3.rds"))
region_map <- c(DZA = "MENA", ARE = "MENA", BHR = "MENA", EGY = "MENA", IRN = "MENA", IRQ = "MENA", JOR = "MENA", KWT = "MENA",
  LBN = "MENA", LBY = "MENA", MAR = "MENA", OMN = "MENA", QAT = "MENA", SAU = "MENA", TUN = "MENA",
  BFA = "SSA", CIV = "SSA", CMR = "SSA", ETH = "SSA", GHA = "SSA", KEN = "SSA", MDG = "SSA", MOZ = "SSA", NGA = "SSA",
  RWA = "SSA", SEN = "SSA", TZA = "SSA", UGA = "SSA", ZAF = "SSA", ZMB = "SSA",
  ARG = "LAC", BOL = "LAC", BRA = "LAC", CHL = "LAC", COL = "LAC", ECU = "LAC", GTM = "LAC", HND = "LAC", JAM = "LAC",
  MEX = "LAC", PAN = "LAC", PER = "LAC", PRY = "LAC", TTO = "LAC", URY = "LAC",
  BGD = "ASIA", IDN = "ASIA", IND = "ASIA", KAZ = "ASIA", LKA = "ASIA", MYS = "ASIA", NPL = "ASIA", PAK = "ASIA",
  PHL = "ASIA", THA = "ASIA", VNM = "ASIA", GEO = "EEU", RUS = "EEU", TUR = "EEU", UKR = "EEU")
q <- quantile(p$inflation_lag1, c(.01, .99), na.rm = TRUE)
p[, `:=`(region = factor(region_map[iso3], levels = c("LAC", "MENA", "SSA", "ASIA", "EEU")),
         inflation_lag1 = pmin(pmax(inflation_lag1, q[1]), q[2]),
         fr_strong = as.integer(rowSums(cbind(bbr, dr, er, rr), na.rm = TRUE) >= 2))]
R <- c("dette_lag1", "pib_lag1", "inflation_lag1", "balance_cour", "solde_prim", "sanction", "war_any")
LAB <- c("Debt/GDP (lag)", "GDP growth (lag)", "Inflation (lag, wins.)", "Current account/GDP", "Primary balance/GDP",
         "Economic sanctions", "Armed conflict")
Y <- c("fr_any", "bbr", "dr", "er", "rr", "fr_strong")
d <- na.omit(p[, c("iso3", "annee", Y, R, "region"), with = FALSE])

ame <- function(fit, v) {
  X <- model.matrix(fit); b <- coef(fit)
  f <- function(bb) mean(dnorm(X %*% bb) * bb[v])
  J <- sapply(seq_along(b), function(k) { h <- 1e-6 * max(1, abs(b[k])); bp <- b; bm <- b
    bp[k] <- b[k] + h; bm[k] <- b[k] - h; (f(bp) - f(bm)) / (2 * h) })
  est <- f(b); se <- sqrt(drop(t(J) %*% vcov(fit) %*% J))
  c(ame = est, se = se, p = 2 * pnorm(-abs(est / se)))
}
res <- rbindlist(lapply(Y, function(y) {
  fit <- suppressWarnings(glm(as.formula(paste(y, "~", paste(R, collapse = " + "), "+ region")), data = d, family = binomial("probit")))
  out <- rbindlist(lapply(R, function(v) as.data.table(as.list(ame(fit, v)))[, `:=`(depvar = y, term = v)]))
  if (y == "fr_any") { r2 <<- 1 - fit$deviance / fit$null.deviance; cc <<- mean((fitted(fit) > .5) == d$fr_any) }
  out }))
fwrite(res, file.path(RES, "probit_presence_ame.csv"))

st <- function(p) ifelse(p < .01, "^{***}", ifelse(p < .05, "^{**}", ifelse(p < .1, "^{*}", "")))
cell <- function(x, p) { s <- sprintf("%.3f", x); if (s == "-0.000") s <- "-0.000"
  if (st(p) == "" && !startsWith(s, "-")) s else sprintf("$%s%s$", sub("^-", "-", s), st(p)) }
body <- unlist(lapply(seq_along(R), function(i) { r <- res[term == R[i]][match(Y, depvar)]
  c(paste(LAB[i], "&", paste(mapply(cell, r$ame, r$p), collapse = " & "), "\\\\"),
    paste(" &", paste(sprintf("(%.3f)", r$se), collapse = " & "), "\\\\")) }))
tex <- c("\\begin{table}[!htbp]", "\\centering",
  "\\caption{Determinants of the presence of a fiscal rule: average marginal effects}", "\\label{tab:adoption_ame}",
  "\\scriptsize", "\\begin{threeparttable}", "\\begin{adjustbox}{max width=\\textwidth}", "\\begin{tabular}{lrrrrrr}", "\\toprule",
  " & (1) Any rule & (2) BBR & (3) DR & (4) ER & (5) RR & (6) Strong ($\\geq 2$) \\\\", "\\midrule", body, "\\midrule",
  sprintf("Observations & \\multicolumn{6}{c}{%s (%d countries)} \\\\", format(nrow(d), big.mark = ","), uniqueN(d$iso3)),
  sprintf("Pseudo-$R^2$ & \\multicolumn{6}{c}{%.3f (P1 baseline)} \\\\", r2),
  sprintf("Correctly classified & \\multicolumn{6}{c}{%.1f\\%%} \\\\", 100 * cc),
  "Region FE & \\multicolumn{6}{c}{Yes (reference: LAC)} \\\\", "\\bottomrule", "\\end{tabular}", "\\end{adjustbox}",
  "\\begin{tablenotes}[flushleft]",
  paste0("\\footnotesize \\item Notes: AME from six probit models pooled with region fixed effects. Dependent variables equal one when a rule of the given type is in force. ",
         "Delta-method standard errors of the average marginal effects in parentheses; they are not clustered by country. ",
         "For binary regressors the reported effect is the derivative-based average marginal effect. The primary balance enters contemporaneously; ",
         "inflation is winsorized at the 1st and 99th percentiles. Quasi-complete separation for expenditure and revenue rules. ",
         "*** $p<0.01$, ** $p<0.05$, * $p<0.10$."),
  "\\end{tablenotes}", "\\end{threeparttable}", "\\end{table}")
writeLines(tex, file.path(TAB, "tab_adoption_ame.tex"))

f1 <- res[depvar == "fr_any"][, `:=`(lab = factor(LAB[match(term, R)], levels = rev(LAB)),
  sig = factor(ifelse(p < .01, "p < 0.01", ifelse(p < .05, "p < 0.05", ifelse(p < .1, "p < 0.10", "Not significant"))),
               levels = c("p < 0.01", "p < 0.05", "p < 0.10", "Not significant")))]
fig <- ggplot(f1, aes(ame, lab)) + geom_vline(xintercept = 0, linewidth = .4) +
  geom_errorbarh(aes(xmin = ame - qnorm(.95) * se, xmax = ame + qnorm(.95) * se), height = .2, colour = "grey45") +
  geom_point(aes(fill = sig), shape = 21, size = 3) +
  scale_fill_manual(values = c("p < 0.01" = "#1F3864", "p < 0.05" = "#4472C4", "p < 0.10" = "#9DB3D9", "Not significant" = "white"),
                    drop = FALSE, name = NULL) +
  labs(x = "Average marginal effect on the probability that a rule is in force", y = NULL) +
  theme_bw(base_size = 10) + theme(panel.grid.minor = element_blank(), legend.position = "bottom")
ggsave(file.path(FIG, "figA1_presence_probit.pdf"), fig, width = 6.5, height = 4)
print(res[depvar == "fr_any"])
