suppressPackageStartupMessages({ library(data.table); library(brglm2) })
TAB <- "../tables"; RES <- "results"
pe <- as.data.table(readRDS("data/processed/panel_frd_extended.rds"))
q <- quantile(pe$inflation_lag1, c(.01, .99), na.rm = TRUE)
MENA_ISO <- c("DZA", "ARE", "BHR", "EGY", "IRN", "IRQ", "JOR", "KWT", "LBN", "LBY", "MAR", "OMN", "QAT", "SAU", "TUN")
region_map <- setNames(c(rep("MENA", 15), rep("SSA", 15), rep("LAC", 15), rep("ASIA", 11), rep("EEU", 4)),
  c(MENA_ISO, "BFA", "CIV", "CMR", "ETH", "GHA", "KEN", "MDG", "MOZ", "NGA", "RWA", "SEN", "TZA", "UGA", "ZAF", "ZMB",
    "ARG", "BOL", "BRA", "CHL", "COL", "ECU", "GTM", "HND", "JAM", "MEX", "PAN", "PER", "PRY", "TTO", "URY",
    "BGD", "IDN", "IND", "KAZ", "LKA", "MYS", "NPL", "PAK", "PHL", "THA", "VNM", "GEO", "RUS", "TUR", "UKR"))
pe[, `:=`(inflation_lag1 = pmin(pmax(inflation_lag1, q[1]), q[2]),
          region = factor(region_map[iso3], levels = c("LAC", "MENA", "SSA", "ASIA", "EEU")),
          mena = as.integer(iso3 %in% MENA_ISO))]
R <- c("dette_lag1", "pib_lag1", "inflation_lag1", "balance_cour", "solde_prim", "sanction", "war_any")

est <- function(dat, y, regs, fe, method) {
  d <- na.omit(dat[, c("iso3", y, regs, fe), with = FALSE])
  f <- as.formula(paste(y, "~", paste(c(regs, fe), collapse = " + ")))
  if (method == "probit") {
    fit <- suppressWarnings(glm(f, data = d, family = binomial("probit"))); X <- model.matrix(fit); b <- coef(fit)
    out <- rbindlist(lapply(regs, function(v) {
      g <- function(bb) mean(dnorm(X %*% bb) * bb[v])
      J <- sapply(seq_along(b), function(k) { h <- 1e-6 * max(1, abs(b[k])); bp <- b; bm <- b
        bp[k] <- b[k] + h; bm[k] <- b[k] - h; (g(bp) - g(bm)) / (2 * h) })
      data.table(term = v, ame = g(b), se = sqrt(drop(t(J) %*% vcov(fit) %*% J))) }))
  } else {
    fit <- glm(f, data = d, family = binomial("logit"), method = "brglmFit", type = "AS_mean")
    k <- mean(dlogis(predict(fit, type = "link")))
    out <- data.table(term = regs, ame = k * coef(fit)[regs], se = k * sqrt(diag(vcov(fit))[regs]))
  }
  out[, `:=`(p = 2 * pnorm(-abs(ame / se)), N = nrow(d))]
}
cols <- list(
  c1 = est(pe, "fr_any", R, "region", "probit"),
  c2 = est(pe[!is.na(fiscal_council_monitoring)], "fr_any", c(R, "fiscal_council_monitoring"), "mena", "firth"),
  c3 = est(pe[!is.na(escape_any)], "fr_any", c(R, "escape_any"), "mena", "firth"),
  c4 = est(pe[!is.na(fiscal_council_monitoring) & !is.na(escape_any)], "fr_any", c(R, "fiscal_council_monitoring", "escape_any"), "mena", "firth"),
  c5 = est(pe[!is.na(fiscal_council_monitoring) & !is.na(escape_bbr_bin)], "bbr", c(R, "fiscal_council_monitoring", "escape_bbr_bin"), "mena", "firth"))
fc <- fread(file.path(RES, "fiscal_council_col2.csv"))
cols$c2[term == "fiscal_council_monitoring", `:=`(ame = fc$ame_discrete, se = fc$ame_boot_se, p = 2 * pnorm(-abs(fc$ame_discrete / fc$ame_boot_se)))]
fwrite(rbindlist(cols, idcol = "colonne"), file.path(RES, "fc_escape_ame.csv"))

st <- function(p) ifelse(p < .01, "^{***}", ifelse(p < .05, "^{**}", ifelse(p < .1, "^{*}", "")))
cell <- function(r) { if (!nrow(r) || is.na(r$ame)) return(c("--", "")); s <- sprintf("%.3f", r$ame)
  c(if (st(r$p) == "" && !startsWith(s, "-")) s else sprintf("$%s%s$", s, st(r$p)), sprintf("(%.3f)", r$se)) }
LAB <- c(dette_lag1 = "Debt/GDP (lag)", pib_lag1 = "GDP growth (lag)", inflation_lag1 = "Inflation (lag)",
         balance_cour = "Current account/GDP", solde_prim = "Primary balance/GDP", sanction = "Economic sanctions",
         war_any = "Armed conflict", fiscal_council_monitoring = "Fiscal council (monitoring)", escape_any = "Escape clause (any)")
body <- unlist(lapply(names(LAB), function(v) { cc <- lapply(cols, function(x) cell(x[term == v]))
  c(paste(LAB[v], "&", paste(sapply(cc, `[`, 1), collapse = " & "), "\\\\"), paste(" &", paste(sapply(cc, `[`, 2), collapse = " & "), "\\\\")) }))
tex <- c("\\begin{table}[!htbp]", "\\centering",
  "\\caption{Presence of a fiscal rule: role of fiscal council and escape clause}", "\\label{tab:fc_escape}",
  "\\scriptsize", "\\begin{threeparttable}", "\\begin{adjustbox}{max width=\\textwidth}", "\\begin{tabular}{lrrrrr}", "\\toprule",
  " & (1) Baseline & (2) +FC & (3) +Escape & (4) +FC+Esc. & (5) BBR+FC+Esc. \\\\",
  "Estimator & Probit & Firth & Firth & Firth & Firth \\\\", "\\midrule", body, "\\midrule",
  paste("Observations &", paste(trimws(format(sapply(cols, function(x) x$N[1]), big.mark = ",")), collapse = " & "), "\\\\"),
  "FE region & \\multicolumn{5}{c}{Dummy MENA in small subsamples; region FE in baseline} \\\\",
  "\\bottomrule", "\\end{tabular}", "\\end{adjustbox}", "\\begin{tablenotes}[flushleft]",
  paste0("\\footnotesize \\item Notes: Average marginal effects. Column (1): probit; columns (2)--(5): Firth logit, used because the probit produces fitted probabilities of zero or one (columns 2 and 5) or because escape clauses quasi-perfectly predict active fiscal rules (columns 3--4). ",
         "The fiscal-council entry in column (2) is the discrete average marginal effect, with a country-block bootstrap standard error (499 replications; \\texttt{replication/code/04\\_fiscal\\_council.R}); ",
         sprintf("a linear probability model gives %.3f (%.3f, clustered by country). ", fc$lpm, fc$lpm_se),
         "The value of 1.384 in the submitted version was a derivative-based effect, which is not bounded for a binary regressor. ",
         "Other entries are derivative-based average marginal effects with delta-method standard errors that are not clustered by country. ",
         "Fiscal council = independent body monitors implementation (IMF Fiscal Rules Dataset, column BT). Escape clause = any rule type has an escape clause (columns BD--BG). ",
         "*** $p<0.01$, ** $p<0.05$, * $p<0.10$."),
  "\\end{tablenotes}", "\\end{threeparttable}", "\\end{table}")
writeLines(tex, file.path(TAB, "tab_fc_escape.tex"))
print(rbindlist(cols, idcol = "colonne")[, .(colonne, term, ame = round(ame, 3), se = round(se, 3), N)])
