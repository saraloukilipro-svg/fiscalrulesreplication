source("code/00_utils.R"); source("code/01_data.R")
TAB <- "../tables"; RES <- "results"; B_BOOT <- 999
KEY <- file.path(RES, "measures_key.txt"); cat("", file = KEY)
kv <- function(...) { l <- paste0(...); cat(l, "\n", file = KEY, append = TRUE); cat(l, "\n") }
d0 <- prep_panel("data/processed/panel_analytique_FINAL_v3.rds")
MES <- c(level = "e", log = "e_log", std = "e_std")
LAB <- c(level = "Level (baseline)", log = "Log", std = "Standardized within country")
HS <- c(2, 4, 6, 8)

share_ru <- function(v) { x <- d0[pays_spec & !is.na(get(v)), .(s = sum(get(v)^2)), by = id]
  x[id %in% c("RUS", "UKR"), sum(s)] / sum(x$s) }
res <- list()
for (k in names(MES)) {
  d <- copy(d0); d[, e := get(MES[k])]; d[, `:=`(e_l1 = shift(e), e_l2 = shift(e, 2)), by = id]
  kv(sprintf("%s : part Russie+Ukraine de la variance des chocs %.2f ; écart-type (19 pays) %.3f",
             k, share_ru(MES[k]), sd(d[pays_spec == TRUE, e], na.rm = TRUE)))
  for (sp in c("base", "aug2")) for (h in HS) {
    b  <- term_stats(lp(d, yname("debt", h), "e", h, sp), "e")
    m  <- pooled(d, yname("debt", h), h, "Sfin_l1", sp)
    bn <- term_stats(m, "e"); p <- term_stats(m, "xS"); pdk <- term_stats(m, "xS", vc = "DK")
    s  <- lincom_stats(m, "e", "xS")
    res[[length(res) + 1]] <- data.table(mesure = k, spec = sp, h = h,
      beta = b$coef, p_beta = b$p, beta_ns = bn$coef, p_ns = bn$p, pi = p$coef, se_pi = p$se, p_pi = p$p,
      p_pi_dk = pdk$p, p_pi_wcb = wcb_p(m, "xS", B = B_BOOT), sanc = s[1], p_sanc = s[3], N = m$n)
  }

  dx <- d[!id %in% c("RUS", "UKR")]
  for (h in HS) { m <- pooled(dx, yname("debt", h), h, "Sfin_l1"); p <- term_stats(m, "xS")
    res[[length(res) + 1]] <- data.table(mesure = k, spec = "noRU", h = h, pi = p$coef, se_pi = p$se, p_pi = p$p,
      p_pi_wcb = wcb_p(m, "xS", B = B_BOOT), N = m$n) }
}
r <- rbindlist(res, fill = TRUE); fwrite(r, file.path(RES, "measures.csv"))
for (i in seq_len(nrow(r))) with(r[i], kv(sprintf("%s %s h%d : beta %s ; beta_ns %s ; pi %.3f (%.3f) p %.3f DK %s WCB %.3f ; sanc %s ; N %d",
  mesure, spec, h, ifelse(is.na(beta), "-", sprintf("%.3f (p %.3f)", beta, p_beta)), ifelse(is.na(beta_ns), "-", sprintf("%.3f (p %.3f)", beta_ns, p_ns)),
  pi, se_pi, p_pi, ifelse(is.na(p_pi_dk), "-", sprintf("%.3f", p_pi_dk)), p_pi_wcb, ifelse(is.na(sanc), "-", sprintf("%.3f (p %.3f)", sanc, p_sanc)), N)))

cell <- function(x, p) f_cs(x, p)
body <- c()
for (k in names(MES)) {
  rk <- r[mesure == k]
  g <- function(sp, col, pcol) sapply(HS, function(hh) cell(rk[spec == sp & h == hh, get(col)], rk[spec == sp & h == hh, get(pcol)]))
  body <- c(body, sprintf("\\multicolumn{9}{l}{\\textit{%s}} \\\\", LAB[k]),
    paste0("Full sample, $\\beta_h$ & ", paste(g("base", "beta", "p_beta"), collapse = " & "), " & ", paste(g("aug2", "beta", "p_beta"), collapse = " & "), " \\\\"),
    paste0("No sanctions, $\\beta_h$ & ", paste(g("base", "beta_ns", "p_ns"), collapse = " & "), " & ", paste(g("aug2", "beta_ns", "p_ns"), collapse = " & "), " \\\\"),
    paste0("Sanctions gap, $\\pi_h$ & ", paste(g("base", "pi", "p_pi"), collapse = " & "), " & ", paste(g("aug2", "pi", "p_pi"), collapse = " & "), " \\\\"),
    paste0("\\quad $p$, wild bootstrap & ", paste(sapply(HS, function(hh) f_p(rk[spec == "base" & h == hh, p_pi_wcb])), collapse = " & "), " & ",
           paste(sapply(HS, function(hh) f_p(rk[spec == "aug2" & h == hh, p_pi_wcb])), collapse = " & "), " \\\\"),
    paste0("\\quad $\\pi_h$ without Russia, Ukraine & ", paste(g("noRU", "pi", "p_pi"), collapse = " & "), " & \\multicolumn{4}{c}{} \\\\"),
    "\\addlinespace")
}
body <- head(body, -1)
hdr <- c(" & \\multicolumn{4}{c}{Baseline} & \\multicolumn{4}{c}{Two lags of $\\Delta d$ and of the shock} \\\\",
         "\\cmidrule(lr){2-5}\\cmidrule(lr){6-9}",
         paste0("Horizon & ", paste(rep(paste0("$h=", HS, "$"), 2), collapse = " & "), " \\\\"))
write_tex(file.path(TAB, "tab_measures.tex"),
  "Debt response to a geopolitical risk shock under three measures of the shock", "tab:measures", "l *{8}{c}",
  hdr, body,
  paste0("Local projections of the cumulative change in debt/GDP, with country and year fixed effects and the baseline controls. ",
         "The shock is the AR(1) innovation in the country-specific Caldara--Iacoviello index, in basis points of the share of articles (level), ",
         "in logs (log), or divided by its standard deviation in each country (standardized); it is zero for the 41 countries without an index. ",
         "Coefficients are per unit of each measure, so magnitudes are not comparable across panels. ",
         "Sanctions: financial sanctions at $t-1$; $\\beta_h$ and $\\pi_h$ are estimated in the pooled specification \\eqref{eq:lp_pooled}. ",
         "Significance stars use standard errors clustered by country; wild cluster bootstrap $p$-values (Rademacher, 999 replications) refer to $\\pi_h$. ",
         sprintf("Share of the squared shocks carried by Russia and Ukraine: %.0f\\%% (level), %.0f\\%% (log), %.0f\\%% (standardized). ",
                 100 * share_ru("e"), 100 * share_ru("e_log"), 100 * share_ru("e_std")), STARS_NOTE))

mech <- list()
for (k in names(MES)) {
  d <- copy(d0); d[, e := get(MES[k])]; d[, `:=`(e_l1 = shift(e), e_l2 = shift(e, 2)), by = id]
  for (h in c(4, 8)) {
    dd <- d[d[[paste0("ok_h", h)]] %in% TRUE]
    for (v in c("ddebt", "ero_prix", "ero_reel", "deficit", "sfa", "infl")) {
      t <- term_stats(lp(dd, paste0("c_", v, "_h", h), "e", h), "e")
      mech[[length(mech) + 1]] <- data.table(mesure = k, h = h, var = v, coef = t$coef, p = t$p, N = t$N) }
    for (v in c("d_reff", "d_pb")) { t <- term_stats(lp(d, paste0(v, "_h", h), "e", h), "e")
      mech[[length(mech) + 1]] <- data.table(mesure = k, h = h, var = v, coef = t$coef, p = t$p, N = t$N) }
  }
}
mech <- rbindlist(mech); fwrite(mech, file.path(RES, "mechanism_measures.csv"))
VL <- c(ddebt = "Change in debt/GDP", ero_prix = "\\quad Erosion through the price level", ero_reel = "\\quad Erosion through real growth",
        deficit = "\\quad Overall deficit", sfa = "\\quad Stock-flow adjustment", infl = "Memo: cumulative inflation",
        d_reff = "Memo: effective interest rate", d_pb = "Memo: primary balance/GDP")
body <- unlist(lapply(names(VL), function(v) paste0(VL[v], " & ", paste(unlist(lapply(names(MES), function(k)
  sapply(c(4, 8), function(hh) mech[mesure == k & h == hh & var == v, f_cs(coef, p)]))), collapse = " & "), " \\\\")))
for (k in names(MES)) kv(sprintf("Mécanisme %s h8 : dette %s ; prix %s ; inflation %s ; taux effectif %s ; solde primaire %s", k,
  mech[mesure == k & h == 8 & var == "ddebt", f_cs(coef, p)], mech[mesure == k & h == 8 & var == "ero_prix", f_cs(coef, p)],
  mech[mesure == k & h == 8 & var == "infl", f_cs(coef, p)], mech[mesure == k & h == 8 & var == "d_reff", f_cs(coef, p)],
  mech[mesure == k & h == 8 & var == "d_pb", f_cs(coef, p)]))
write_tex(file.path(TAB, "tab_mechanism_measures.tex"),
  "Accounting decomposition of the debt response under three measures of the shock", "tab:mechanism_measures", "l *{6}{c}",
  c(" & \\multicolumn{2}{c}{Level} & \\multicolumn{2}{c}{Log} & \\multicolumn{2}{c}{Standardized} \\\\",
    "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}",
    "Horizon & $h=4$ & $h=8$ & $h=4$ & $h=8$ & $h=4$ & $h=8$ \\\\"), body,
  paste0("Full-sample local projections with country and year fixed effects and the baseline controls. The change in debt/GDP and its four components ",
         "are estimated on a common sample, in which the components add up to the debt response; the memo rows use all available observations. ",
         "Coefficients are per unit of each measure of the shock (see Table~\\ref{tab:measures} of the paper). ", STARS_NOTE))
