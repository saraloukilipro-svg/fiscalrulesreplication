source("code/00_utils.R"); source("code/01_data.R")
TAB <- "../tables"; RES <- "results"; H <- 1:8
xl <- "data/raw/Global_Policy_Uncertainty_Data.xlsx"; raw <- "data/raw/GEPUPPP.csv"; ep <- NULL
if (file.exists(xl)) {
  x <- suppressWarnings(as.data.table(readxl::read_excel(xl)))
  ep <- x[!is.na(Month) & grepl("^[0-9]{4}$", Year), .(t = as.integer(Year), v = as.numeric(GEPU_ppp))]
  source_note <- "computed from data/raw/Global_Policy_Uncertainty_Data.xlsx (GEPU_ppp)"
} else {
  if (file.exists(raw) && file.info(raw)$size < 1000) file.remove(raw)
  if (!file.exists(raw)) try(download.file("https://fred.stlouisfed.org/graph/fredgraph.csv?id=GEPUPPP", raw, quiet = TRUE), silent = TRUE)
  if (file.exists(raw) && file.info(raw)$size > 1000) {
    ep <- fread(raw); setnames(ep, 1, "date"); vcol <- names(ep)[2]
    ep <- ep[, .(t = as.integer(substr(as.character(date), 1, 4)), v = as.numeric(get(vcol)))]
    source_note <- "computed from data/raw/GEPUPPP.csv (FRED)"
  }
}

if (!is.null(ep)) {
  ep <- ep[, .(epu = mean(v, na.rm = TRUE), n_mois = sum(!is.na(v))), by = t][t >= 1997 & t <= 2022 & n_mois == 12][order(t)]
  ep[, epu_l1 := shift(epu)]; ar <- lm(epu ~ epu_l1, data = ep)
  ep[!is.na(epu_l1), e_epu := resid(ar)]; ep[, e_epu_sd := e_epu / sd(e_epu, na.rm = TRUE)]
  cat("AR(1) rho =", round(coef(ar)[2], 3), "|", sum(!is.na(ep$e_epu)), "années\n")
  d <- prep_panel("data/processed/panel_analytique_FINAL_v3.rds")
  d <- merge(d, ep[, .(t, e_epu_sd)], by = "t", all.x = TRUE)
  res <- rbindlist(lapply(H, function(h) { m <- fe_ols(d, yname("debt", h), c("e_epu_sd", CTRL), fe = "country", extra_lin = "t")
    cbind(data.table(h = h), term_stats(m, "e_epu_sd", vc = "DK")[, .(coef, se, p, N)]) }))
} else {
  res <- fread(file.path(RES, "tabG_epu_run_2026-10-28.csv"))[, .(h, coef, se, p, N)]
  source_note <- "archived results of the run of 28 October 2026 (FRED not reachable)"
  message("FRED inaccessible et pas de copie locale : tableau construit à partir des résultats archivés.")
}
fwrite(res, file.path(RES, "epu.csv")); print(res)
r <- res[order(h)]
write_tex(file.path(TAB, "tab_epu.tex"), "EPU shock and debt/GDP", "tab:epu", "l *{8}{c}",
  paste("&", paste(sprintf("$h=%d$", H), collapse = " & "), "\\\\"),
  c(paste("Coefficient &", paste(f_cs(r$coef, r$p), collapse = " & "), "\\\\"), paste(" &", paste(f_se(r$se), collapse = " & "), "\\\\"),
    paste("Observations &", paste(f_n(r$N), collapse = " & "), "\\\\")),
  paste0("Response of the cumulative change in debt/GDP (percentage points) from $t-1$ to $t+h$ to a one-standard-deviation innovation in global ",
         "economic policy uncertainty (residual of an AR(1) model of the annual PPP-weighted global EPU index of \\citet{BakerBloomDavis2016}, 1997--2022). ",
         "Country fixed effects, a linear trend and the baseline lagged controls; no year effects, since the EPU series is common to all countries. ",
         "Driscoll--Kraay standard errors in parentheses. ", STARS_NOTE))
writeLines(source_note, file.path(RES, "epu_source.txt"))
