library(tidyverse)
library(ggplot2)

select <- dplyr::select
filter <- dplyr::filter
mutate <- dplyr::mutate

setwd(Sys.getenv("FRR_ROOT", "."))
base_dir <- file.path(Sys.getenv("FRR_ROOT", "."), "Paper finale")
dir.create("output/figures/final", showWarnings=FALSE, recursive=TRUE)

cat("=== Script 33 : Fig 2 Debt With vs Without FR ===\n\n")

cat("--- Chargement panel ---\n")

panel <- readRDS("data/processed/panel_analytique_FINAL_v3.rds") %>%
  arrange(iso3, annee)

cat(sprintf("  Panel : %d obs | %d pays | %d annees\n",
            nrow(panel), n_distinct(panel$iso3),
            n_distinct(panel$annee)))

stats <- panel %>%
  filter(!is.na(dette_pib), !is.na(fr_any)) %>%
  group_by(annee, fr_any) %>%
  summarise(
    med  = median(dette_pib, na.rm=TRUE),
    q25  = quantile(dette_pib, 0.25, na.rm=TRUE),
    q75  = quantile(dette_pib, 0.75, na.rm=TRUE),
    N    = n(),
    .groups = "drop"
  ) %>%
  mutate(
    groupe = factor(
      fr_any,
      levels = c(1, 0),
      labels = c("With fiscal rule", "Without fiscal rule")
    )
  )

cat("\n  Stats cles (median dette/PIB) :\n")
cat(sprintf("  %-6s  %-20s  %8s  %8s  %5s\n",
            "Annee","Groupe","Q25","Median","Q75"))
cat("  ", paste(rep("-",55), collapse=""), "\n", sep="")
for (y in c(1990,2000,2010,2015,2022)) {
  for (g in c(1,0)) {
    r <- stats %>% filter(annee==y, fr_any==g)
    if (nrow(r)==0) next
    lbl <- ifelse(g==1,"With FR","Without FR")
    cat(sprintf("  %-6d  %-20s  %8.1f  %8.1f  %5.1f  (N=%d)\n",
                y, lbl, r$q25, r$med, r$q75, r$N))
  }
}

col_with    <- "#1A3A6B"
col_without <- "#888780"

theme_imf <- function(base_size=11) {
  theme_bw(base_size=base_size) +
    theme(
      panel.background   = element_rect(fill="white", color=NA),
      plot.background    = element_rect(fill="white", color=NA),
      panel.grid.major.y = element_line(color="grey90",
                                         linewidth=0.35),
      panel.grid.major.x = element_blank(),
      panel.grid.minor   = element_blank(),
      panel.border       = element_blank(),
      axis.line.x        = element_line(color="black",
                                         linewidth=0.5),
      axis.line.y        = element_blank(),
      axis.ticks.x       = element_line(color="black",
                                         linewidth=0.4),
      axis.ticks.y       = element_blank(),
      axis.text          = element_text(size=9.5, color="grey30"),
      axis.title.y       = element_text(size=10, color="grey25",
                                         margin=margin(r=6)),
      axis.title.x       = element_blank(),
      legend.position    = "bottom",
      legend.direction   = "horizontal",
      legend.background  = element_blank(),
      legend.key.size    = unit(0.55, "cm"),
      legend.key         = element_rect(color=NA, fill="white"),
      legend.text        = element_text(size=9.5, color="grey20"),
      legend.title       = element_blank(),
      legend.spacing.x   = unit(0.3, "cm"),
      legend.margin      = margin(t=4),
      plot.title         = element_text(size=12, face="bold",
                                         color="black", hjust=0,
                                         margin=margin(b=3)),
      plot.subtitle      = element_text(size=9, color="grey40",
                                         hjust=0,
                                         margin=margin(b=10)),
      plot.caption       = element_text(size=8, color="grey50",
                                         hjust=0,
                                         margin=margin(t=8)),
      plot.margin        = margin(12, 20, 8, 12)
    )
}

cat("\n--- Construction graphique ---\n")

d_with    <- stats %>% filter(fr_any==1)
d_without <- stats %>% filter(fr_any==0)

p <- ggplot() +

  geom_ribbon(
    data  = d_with,
    aes(x=annee, ymin=q25, ymax=q75,
        fill="With fiscal rule"),
    alpha = 0.15, color=NA
  ) +
  geom_ribbon(
    data  = d_without,
    aes(x=annee, ymin=q25, ymax=q75,
        fill="Without fiscal rule"),
    alpha = 0.12, color=NA
  ) +

  geom_line(
    data      = d_with,
    aes(x=annee, y=med, color="With fiscal rule"),
    linewidth = 1.3, lineend="round"
  ) +
  geom_line(
    data      = d_without,
    aes(x=annee, y=med, color="Without fiscal rule"),
    linewidth = 1.3, lineend="round",
    linetype  = "dashed"
  ) +

  scale_color_manual(
    name   = NULL,
    values = c("With fiscal rule"    = col_with,
               "Without fiscal rule" = col_without),
    guide  = guide_legend(
      override.aes = list(
        linewidth = c(1.3, 1.3),
        linetype  = c("solid","dashed"),
        fill      = NA
      )
    )
  ) +
  scale_fill_manual(
    name   = NULL,
    values = c("With fiscal rule"    = col_with,
               "Without fiscal rule" = col_without),
    guide  = "none"
  ) +

  annotate(
    "text",
    x=1993, y=86,
    label="Shaded band = interquartile range (Q25\u2013Q75)",
    size=3, hjust=0, color="grey50", fontface="italic"
  ) +

  scale_x_continuous(
    breaks = seq(1990, 2020, by=5),
    limits = c(1989.5, 2022.5),
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    breaks = seq(20, 90, by=20),
    limits = c(10, 96),
    expand = c(0, 0),
    labels = function(x) paste0(x, "%")
  ) +

  labs(
    title    = "Median Debt-to-GDP: Countries With vs. Without Fiscal Rules",
    subtitle = paste0(
      "Median general government debt/GDP (%), 1990\u20132022. ",
      "Dashed = without rule. Shaded = interquartile range."
    ),
    y        = "Median debt/GDP (%)",
    caption  = paste0(
      "Notes: Each line reports the median general government",
      " debt-to-GDP ratio for countries with (solid) and without",
      " (dashed) at least one active fiscal rule in a given year.\n",
      "Shaded bands indicate the interquartile range (Q25\u2013Q75).",
      " The post-2005 convergence partly reflects a selection effect:",
      " high-debt countries\n",
      "adopt rules precisely when fiscal stress intensifies,",
      " generating a positive correlation between rule adoption",
      " and debt levels.\n",
      "Sources: IMF WEO (2023); Davoodi et al. (2022).",
      " Sample: 60 emerging and developing economies, 1990\u20132022."
    )
  ) +

  theme_imf()

cat("\n--- Sauvegarde ---\n")

ggsave("output/figures/final/fig2_debt_with_without_fr.pdf",
       p, width=8, height=5,
       device="pdf", useDingbats=FALSE)
cat("  [OK] output/figures/final/fig2_debt_with_without_fr.pdf\n")

ggsave("output/figures/final/fig2_debt_with_without_fr.png",
       p, width=8, height=5, dpi=300)
cat("  [OK] output/figures/final/fig2_debt_with_without_fr.png\n")

if (dir.exists(file.path(base_dir, "figures"))) {
  file.copy(
    "output/figures/final/fig2_debt_with_without_fr.pdf",
    file.path(base_dir, "figures",
              "fig2_debt_with_without_fr.pdf"),
    overwrite=TRUE
  )
  cat("  [OK] Paper finale/figures/fig2_debt_with_without_fr.pdf\n")
}

cat("\n=================================================================\n")
cat("RAPPORT FINAL\n")
cat("=================================================================\n\n")

cat(sprintf("  %-6s  %10s  %8s  %10s  %8s\n",
            "Annee","Med_with","N_with","Med_without","N_without"))
cat("  ", paste(rep("-",55), collapse=""), "\n", sep="")

for (y in c(1990,1995,2000,2005,2010,2015,2020,2022)) {
  rw <- stats %>% filter(annee==y, fr_any==1)
  ro <- stats %>% filter(annee==y, fr_any==0)
  if (nrow(rw)==0 || nrow(ro)==0) next
  cat(sprintf("  %-6d  %10.1f  %8d  %10.1f  %8d\n",
              y, rw$med, rw$N, ro$med, ro$N))
}

cat("\n  LECTURE :")
cat("\n  -> En 2000 les pays SANS regle ont une dette mediane")
cat(sprintf("\n     plus haute (%.1f%%) que ceux AVEC regle (%.1f%%)",
            stats$med[stats$annee==2000 & stats$fr_any==0],
            stats$med[stats$annee==2000 & stats$fr_any==1]))
cat("\n  -> La convergence post-2005 reflete l'adoption croissante")
cat("\n     de regles par des pays a forte dette (selection bias)\n")

cat("\n=== SCRIPT 33 TERMINE ===\n\n")
