library(tidyverse)
library(openxlsx)
library(patchwork)

select  <- dplyr::select
filter  <- dplyr::filter
mutate  <- dplyr::mutate
arrange <- dplyr::arrange

if ("package:plyr" %in% search()) {
  tryCatch(
    detach("package:plyr", unload = TRUE, force = TRUE),
    error = function(e) NULL
  )
}

setwd(Sys.getenv("FRR_ROOT", "."))
dir.create("output/figures", showWarnings = FALSE, recursive = TRUE)

cat("=== Chargement ===\n")
panel <- readRDS("data/processed/panel_analytique_FINAL_v3.rds") %>%
  arrange(iso3, annee)
cat("Panel:", nrow(panel), "x", ncol(panel),
    "| Pays:", n_distinct(panel$iso3), "\n\n")

region_map <- c(
  DZA="MENA", ARE="MENA", BHR="MENA", EGY="MENA", IRN="MENA",
  IRQ="MENA", JOR="MENA", KWT="MENA", LBN="MENA", LBY="MENA",
  MAR="MENA", OMN="MENA", QAT="MENA", SAU="MENA", TUN="MENA",
  BFA="SSA",  CIV="SSA",  CMR="SSA",  ETH="SSA",  GHA="SSA",
  KEN="SSA",  MDG="SSA",  MOZ="SSA",  NGA="SSA",  RWA="SSA",
  SEN="SSA",  TZA="SSA",  UGA="SSA",  ZAF="SSA",  ZMB="SSA",
  ARG="LAC",  BOL="LAC",  BRA="LAC",  CHL="LAC",  COL="LAC",
  ECU="LAC",  GTM="LAC",  HND="LAC",  JAM="LAC",  MEX="LAC",
  PAN="LAC",  PER="LAC",  PRY="LAC",  TTO="LAC",  URY="LAC",
  BGD="ASIA", IDN="ASIA", IND="ASIA", KAZ="ASIA", LKA="ASIA",
  MYS="ASIA", NPL="ASIA", PAK="ASIA", PHL="ASIA", THA="ASIA",
  VNM="ASIA", GEO="EEU",  RUS="EEU",  TUR="EEU",  UKR="EEU"
)

panel <- panel %>%
  mutate(
    region = factor(region_map[iso3],
                    levels = c("MENA","SSA","LAC","ASIA","EEU")),
    fr_intensity = rowSums(
      dplyr::select(., bbr, dr, er, rr), na.rm = TRUE),
    fr_none   = as.integer(fr_intensity == 0),
    fr_strong = as.integer(fr_intensity >= 2),
    fr_group  = factor(
      case_when(
        fr_intensity == 0 ~ "No rule",
        fr_intensity == 1 ~ "One rule",
        TRUE              ~ "Strong rule (2+)"),
      levels = c("No rule","One rule","Strong rule (2+)")),
    fr_label  = ifelse(fr_any == 1,
                       "Fiscal rule active",
                       "No fiscal rule"),
    sanc_label = ifelse(sanction == 1,
                        "Sanctioned",
                        "Non-sanctioned")
  )

run_ttest <- function(data, var, gvar, g0l, g1l,
                      vlab = NULL) {
  x0 <- data[[var]][data[[gvar]] == 0]
  x0 <- x0[!is.na(x0)]
  x1 <- data[[var]][data[[gvar]] == 1]
  x1 <- x1[!is.na(x1)]
  if (length(x0) < 3 || length(x1) < 3) return(NULL)

  tt <- t.test(x1, x0, var.equal = FALSE,
               alternative = "two.sided")
  sp <- sqrt(((length(x0)-1)*var(x0) +
              (length(x1)-1)*var(x1)) /
             (length(x0)+length(x1)-2))
  d  <- (mean(x1) - mean(x0)) / sp

  tibble(
    variable    = ifelse(is.null(vlab), var, vlab),
    group_0     = g0l,
    group_1     = g1l,
    n_0         = length(x0),
    n_1         = length(x1),
    mean_0      = round(mean(x0), 3),
    mean_1      = round(mean(x1), 3),
    diff        = round(mean(x1) - mean(x0), 3),
    sd_0        = round(sd(x0), 3),
    sd_1        = round(sd(x1), 3),
    se_diff     = round(tt$stderr, 3),
    t_stat      = round(tt$statistic, 3),
    df          = round(tt$parameter, 1),
    p_value     = round(tt$p.value, 4),
    ci_low      = round(tt$conf.int[1], 3),
    ci_high     = round(tt$conf.int[2], 3),
    sig         = case_when(
      tt$p.value < 0.01 ~ "***",
      tt$p.value < 0.05 ~ "**",
      tt$p.value < 0.10 ~ "*",
      TRUE              ~ ""
    ),
    cohens_d    = round(d, 3),
    effect_size = case_when(
      abs(d) < 0.2 ~ "negligible",
      abs(d) < 0.5 ~ "small",
      abs(d) < 0.8 ~ "medium",
      TRUE         ~ "large"
    )
  )
}

cat("=== T1-T2 : fr_any = 0 vs 1 (panel complet) ===\n")

t1 <- run_ttest(panel, "dette_pib", "fr_any",
                "No fiscal rule", "Fiscal rule active",
                "Debt/GDP (%)")
t2 <- run_ttest(panel, "solde_prim", "fr_any",
                "No fiscal rule", "Fiscal rule active",
                "Primary balance (%)")
results_t12 <- bind_rows(t1, t2)

cat(sprintf(
  "  Debt/GDP : %.2f vs %.2f | diff=%.2f %s | d=%.3f (%s)\n",
  t1$mean_0, t1$mean_1, t1$diff, t1$sig,
  t1$cohens_d, t1$effect_size))
cat(sprintf(
  "  Sol.prim : %.2f vs %.2f | diff=%.2f %s | d=%.3f (%s)\n\n",
  t2$mean_0, t2$mean_1, t2$diff, t2$sig,
  t2$cohens_d, t2$effect_size))

cat("=== T3-T4 : fr_none vs fr_strong ===\n")

pb2 <- panel %>%
  filter(fr_none == 1 | fr_strong == 1) %>%
  mutate(fr_bin = fr_strong)

t3 <- run_ttest(pb2, "dette_pib", "fr_bin",
                "No rule (fr_none)", "Strong rule (fr_strong)",
                "Debt/GDP (%)")
t4 <- run_ttest(pb2, "solde_prim", "fr_bin",
                "No rule (fr_none)", "Strong rule (fr_strong)",
                "Primary balance (%)")
results_t34 <- bind_rows(t3, t4)

cat(sprintf(
  "  Debt/GDP : %.2f vs %.2f | diff=%.2f %s | d=%.3f (%s)\n",
  t3$mean_0, t3$mean_1, t3$diff, t3$sig,
  t3$cohens_d, t3$effect_size))
cat(sprintf(
  "  Sol.prim : %.2f vs %.2f | diff=%.2f %s | d=%.3f (%s)\n\n",
  t4$mean_0, t4$mean_1, t4$diff, t4$sig,
  t4$cohens_d, t4$effect_size))

cat("=== T5-T6 : par type de regle ===\n")

rts <- list(
  list("bbr","BBR"), list("dr","DR"),
  list("er","ER"),   list("rr","RR")
)

results_t56 <- map_dfr(rts, function(r) {
  bind_rows(
    run_ttest(panel, "dette_pib",  r[[1]],
              paste0("No ", r[[2]]),
              paste0("Active ", r[[2]]),
              paste0("Debt/GDP | ", r[[2]])),
    run_ttest(panel, "solde_prim", r[[1]],
              paste0("No ", r[[2]]),
              paste0("Active ", r[[2]]),
              paste0("Primary balance | ", r[[2]]))
  )
})

results_t56 %>%
  dplyr::select(variable, mean_0, mean_1,
                diff, sig, cohens_d) %>%
  mutate(across(where(is.numeric), ~round(., 3))) %>%
  print()
cat("\n")

cat("=== T7-T8 : par region ===\n")

results_t78 <- map_dfr(levels(panel$region), function(reg) {
  dat <- panel %>% filter(region == reg)
  bind_rows(
    run_ttest(dat, "dette_pib",  "fr_any",
              "No rule", "Rule active",
              paste0("Debt/GDP | ", reg)),
    run_ttest(dat, "solde_prim", "fr_any",
              "No rule", "Rule active",
              paste0("Primary balance | ", reg))
  )
})

results_t78 %>%
  dplyr::select(variable, n_0, n_1, mean_0, mean_1,
                diff, sig, cohens_d) %>%
  mutate(across(where(is.numeric), ~round(., 2))) %>%
  print()
cat("\n")

cat("=== T9 : Avant vs apres adoption ===\n")

adoption_df <- aggregate(
  annee ~ iso3,
  data   = panel[panel$fr_any == 1, c("iso3","annee")],
  FUN    = min
)
names(adoption_df)[2] <- "annee_adoption"

cat("  N pays adoptants :", nrow(adoption_df), "\n")

panel_base <- as.data.frame(panel)
panel_adopters <- panel_base[
  panel_base$iso3 %in% adoption_df$iso3, ]

panel_adopters$annee_adoption <- NULL
panel_ad <- merge(
  x    = panel_adopters,
  y    = adoption_df,
  by   = "iso3",
  all.x = TRUE
)

cat("  Colonnes panel_ad :", "annee_adoption" %in% names(panel_ad), "\n")
cat("  N obs adoptants   :", nrow(panel_ad), "\n")

panel_ad[["post_adoption"]] <- as.integer(
  panel_ad[["annee"]] >= panel_ad[["annee_adoption"]]
)
panel_ad[["years_from"]] <- (
  panel_ad[["annee"]] - panel_ad[["annee_adoption"]]
)

cat("  post_adoption OK  :", "post_adoption" %in% names(panel_ad), "\n")
cat("  Distribution post :", table(panel_ad$post_adoption), "\n")

t9d <- run_ttest(panel_ad, "dette_pib", "post_adoption",
                 "Before adoption", "After adoption",
                 "Debt/GDP (%) -- adopters")
t9s <- run_ttest(panel_ad, "solde_prim", "post_adoption",
                 "Before adoption", "After adoption",
                 "Primary balance (%) -- adopters")
results_t9 <- bind_rows(t9d, t9s)

if (!is.null(t9d))
  cat(sprintf(
    "  Debt/GDP : %.2f vs %.2f | diff=%.2f %s | d=%.3f (%s)\n",
    t9d$mean_0, t9d$mean_1, t9d$diff, t9d$sig,
    t9d$cohens_d, t9d$effect_size))
if (!is.null(t9s))
  cat(sprintf(
    "  Sol.prim : %.2f vs %.2f | diff=%.2f %s | d=%.3f (%s)\n\n",
    t9s$mean_0, t9s$mean_1, t9s$diff, t9s$sig,
    t9s$cohens_d, t9s$effect_size))

cat("=== T10 : Par statut de sanctions ===\n")

results_t10 <- map_dfr(c(0, 1), function(s) {
  dat <- panel %>% filter(sanction == s)
  lb  <- ifelse(s == 0, "Non-sanctioned", "Sanctioned")
  bind_rows(
    run_ttest(dat, "dette_pib",  "fr_any",
              "No rule", "Rule active",
              paste0("Debt/GDP | ", lb)),
    run_ttest(dat, "solde_prim", "fr_any",
              "No rule", "Rule active",
              paste0("Primary balance | ", lb))
  )
})

results_t10 %>%
  dplyr::select(variable, n_0, n_1, mean_0, mean_1,
                diff, sig, cohens_d) %>%
  mutate(across(where(is.numeric), ~round(., 2))) %>%
  print()
cat("\n")

cat("=== Sauvegarde Excel ===\n")

wb <- createWorkbook()

sheets_list <- list(
  T1_T2_fr_any  = results_t12,
  T3_T4_bin     = results_t34,
  T5_T6_type    = results_t56,
  T7_T8_region  = results_t78,
  T9_adoption   = results_t9,
  T10_sanctions = results_t10,
  Tous_tests    = bind_rows(
    results_t12 %>% mutate(test_group = "T1-T2"),
    results_t34 %>% mutate(test_group = "T3-T4"),
    results_t56 %>% mutate(test_group = "T5-T6"),
    results_t78 %>% mutate(test_group = "T7-T8"),
    results_t9  %>% mutate(test_group = "T9"),
    results_t10 %>% mutate(test_group = "T10")
  )
)

for (nm in names(sheets_list)) {
  addWorksheet(wb, nm)
  writeData(wb, nm, sheets_list[[nm]])
}

saveWorkbook(wb, "output/TTEST_FISCAL_RULES.xlsx",
             overwrite = TRUE)
cat("OK : output/TTEST_FISCAL_RULES.xlsx\n\n")

cat("=== Generation figures ===\n\n")

theme_tt <- function(base = 11) {
  theme_bw(base_size = base) +
    theme(
      panel.grid.minor  = element_blank(),
      panel.grid.major  = element_line(color = "grey92",
                                       linewidth = 0.3),
      panel.border      = element_rect(color = "grey40",
                                       linewidth = 0.5),
      axis.title        = element_text(size = base - 1),
      plot.title        = element_text(size = base,
                                       face = "bold"),
      plot.subtitle     = element_text(size = base - 2,
                                       color = "grey40"),
      plot.caption      = element_text(size = base - 3,
                                       color = "grey50",
                                       hjust = 0),
      legend.position   = "bottom",
      legend.title      = element_blank(),
      legend.text       = element_text(size = base - 2),
      strip.background  = element_rect(fill = "grey95",
                                       color = "grey60"),
      strip.text        = element_text(face = "bold",
                                       size = base - 1)
    )
}

save_fig <- function(p, name, w = 9, h = 5) {
  ggsave(paste0("output/figures/", name, ".png"),
         p, width = w, height = h, dpi = 300, bg = "white")
  ggsave(paste0("output/figures/", name, ".pdf"),
         p, width = w, height = h)
  cat("  OK", name, "\n")
}

C_FR0 <- "#C0392B"
C_FR1 <- "#1F3864"

cat("--- Figure TT1 ---\n")

fig_tt1 <- panel %>%
  filter(!is.na(dette_pib)) %>%
  mutate(
    fr_lbl = factor(
      ifelse(fr_any == 1,
             "Fiscal rule (FR=1)",
             "No fiscal rule (FR=0)"),
      levels = c("No fiscal rule (FR=0)",
                 "Fiscal rule (FR=1)"))
  ) %>%
  ggplot(aes(x = fr_lbl, y = dette_pib,
             fill = fr_lbl, color = fr_lbl)) +
  geom_violin(alpha = 0.25, linewidth = 0.6, trim = TRUE) +
  geom_boxplot(width = 0.18, alpha = 0.85,
               outlier.size = 0.7, outlier.alpha = 0.4) +
  stat_summary(fun = mean, geom = "point", shape = 23,
               size = 3, fill = "white", color = "black") +
  scale_fill_manual(values  = c(C_FR0, C_FR1)) +
  scale_color_manual(values = c(C_FR0, C_FR1)) +
  annotate("text", x = 1.5,
           y = quantile(panel$dette_pib, 0.95, na.rm = TRUE),
           size = 3.5, fontface = "bold",
           label = sprintf(
             "t = %.2f%s\np = %.4f\ndiff = %.2f pp\nd = %.3f (%s)",
             t1$t_stat, t1$sig, t1$p_value,
             t1$diff, t1$cohens_d, t1$effect_size)) +
  labs(
    title    = paste0("Figure TT1: Debt-to-GDP Distribution",
                      " by Fiscal Rule Status"),
    subtitle = paste0("Violin + box plots. Diamond = group mean.",
                      " Welch t-test."),
    x        = NULL,
    y        = "Public debt / GDP (%)",
    caption  = paste0(
      "Notes: Welch t-test (unequal variances).",
      " Cohen d: small<0.5, medium<0.8, large>=0.8.\n",
      "Sample: 60 countries, 1990-2022.",
      " Source: IMF WEO 2023 and Davoodi et al. (2022).")
  ) +
  theme_tt() +
  theme(legend.position = "none")

save_fig(fig_tt1, "tt1_violin_dette_fr", w = 8, h = 6)

cat("--- Figure TT2 ---\n")

fig_tt2_data <- results_t78 %>%
  mutate(
    region   = str_extract(variable, "[A-Z]+$"),
    var_type = ifelse(str_detect(variable, "Debt"),
                      "Debt-to-GDP (%)",
                      "Primary balance (%)"),
    var_type = factor(var_type,
                      levels = c("Debt-to-GDP (%)",
                                 "Primary balance (%)"))
  )

fig_tt2 <- ggplot(fig_tt2_data,
                   aes(x = region, y = diff,
                       fill = var_type, color = var_type)) +
  geom_col(position = position_dodge(0.7),
           width = 0.65, alpha = 0.85) +
  geom_errorbar(aes(ymin = ci_low, ymax = ci_high),
                position = position_dodge(0.7),
                width = 0.25, linewidth = 0.7) +
  geom_hline(yintercept = 0, linetype = "dashed",
             color = "grey30", linewidth = 0.5) +
  geom_text(aes(label = sig,
                y = ifelse(diff > 0,
                           ci_high + 0.5,
                           ci_low  - 0.5)),
            position = position_dodge(0.7),
            size = 3.5, fontface = "bold") +
  scale_fill_manual(values  = c(C_FR0, C_FR1)) +
  scale_color_manual(values = c(C_FR0, C_FR1)) +
  facet_wrap(~ var_type, ncol = 2, scales = "free_y") +
  labs(
    title    = paste0("Figure TT2: Mean Difference",
                      " (FR minus No FR) by Regional Group"),
    subtitle = paste0("Negative = FR countries have lower debt",
                      " / higher primary balance.",
                      " Error bars: 95% CI."),
    x        = "Region",
    y        = "Difference in means",
    caption  = paste0(
      "Notes: Welch t-test.",
      " *** p<0.01, ** p<0.05, * p<0.10.\n",
      "Source: IMF WEO 2023 and Davoodi et al. (2022).")
  ) +
  theme_tt()

save_fig(fig_tt2, "tt2_differences_region", w = 12, h = 6)

cat("--- Figure TT3 ---\n")

fig_tt3_data <- panel_ad %>%
  filter(!is.na(dette_pib),
         years_from >= -10,
         years_from <=  10) %>%
  group_by(years_from) %>%
  summarise(
    mean_d  = mean(dette_pib, na.rm = TRUE),
    se_d    = sd(dette_pib,   na.rm = TRUE) / sqrt(n()),
    n       = n(),
    .groups = "drop"
  )

fig_tt3 <- ggplot(fig_tt3_data,
                   aes(x = years_from, y = mean_d)) +
  geom_vline(xintercept = 0, linetype = "dashed",
             color = C_FR0, linewidth = 0.9) +
  geom_ribbon(aes(ymin = mean_d - 1.96 * se_d,
                  ymax = mean_d + 1.96 * se_d),
              fill = C_FR1, alpha = 0.15) +
  geom_line(color  = C_FR1, linewidth = 1.1) +
  geom_point(color = C_FR1, size = 2.5) +
  annotate("text",
           x = 0.5,
           y = max(fig_tt3_data$mean_d) * 0.99,
           hjust = 0, size = 3.5, color = C_FR0,
           label = "Adoption year") +
  scale_x_continuous(breaks = seq(-10, 10, by = 2)) +
  labs(
    title    = paste0("Figure TT3: Mean Debt-to-GDP",
                      " Around Fiscal Rule Adoption Year"),
    subtitle = paste0(
      "t = 0 = adoption year. Shaded band: 95% CI.",
      " Adopting countries only (N = ",
      nrow(adoption_df), ")."),
    x        = "Years relative to adoption",
    y        = "Mean debt / GDP (%)",
    caption  = paste0(
      "Notes: Simple event study, no controls.",
      " Before/after diff = ",
      ifelse(!is.null(t9d),
             paste0(round(t9d$diff, 2), " pp ", t9d$sig),
             "n/a"),
      ".\nSource: IMF WEO 2023 and Davoodi et al. (2022).")
  ) +
  theme_tt()

save_fig(fig_tt3, "tt3_event_adoption", w = 9, h = 5.5)

cat("--- Figure TT4 ---\n")

fig_tt4_data <- results_t56 %>%
  filter(str_detect(variable, "Debt")) %>%
  mutate(
    rule_type = str_extract(variable, "[A-Z]+$"),
    color_bar = ifelse(diff < 0, "Lower debt", "Higher debt")
  )

fig_tt4 <- ggplot(fig_tt4_data,
                   aes(x    = reorder(rule_type, diff),
                       y    = diff,
                       fill = color_bar)) +
  geom_col(width = 0.6, alpha = 0.85) +
  geom_errorbar(aes(ymin = ci_low, ymax = ci_high),
                width = 0.2, linewidth = 0.7,
                color = "grey30") +
  geom_hline(yintercept = 0, linetype = "dashed",
             color = "grey40", linewidth = 0.5) +
  geom_text(aes(label = paste0(round(diff, 1), sig),
                y     = ifelse(diff < 0,
                               ci_low  - 0.5,
                               ci_high + 0.5)),
            size = 3.5, fontface = "bold",
            color = "grey20") +
  scale_fill_manual(values = c("Lower debt"  = C_FR1,
                               "Higher debt" = C_FR0)) +
  coord_flip() +
  labs(
    title    = paste0("Figure TT4: Difference in Mean Debt-to-GDP",
                      " by Type of Fiscal Rule"),
    subtitle = paste0(
      "Difference = mean(with rule) minus mean(no rule).",
      " Negative = rule lowers debt."),
    x        = NULL,
    y        = "Difference in mean debt / GDP (%)",
    caption  = paste0(
      "Notes: BBR = Balanced budget rule; DR = Debt rule;",
      " ER = Expenditure rule; RR = Revenue rule.\n",
      "Welch t-test. Error bars: 95% CI.",
      " Source: Davoodi et al. (2022).")
  ) +
  theme_tt() +
  theme(legend.position = "none")

save_fig(fig_tt4, "tt4_par_type_regle", w = 9, h = 5.5)

cat("\n=================================================================\n")
cat("RESUME : VALEURS A REPORTER DANS LE TEXTE LATEX\n")
cat("=================================================================\n\n")

cat("T1 : Dette/PIB, fr_any :\n")
cat(sprintf("  No FR  : mean=%.2f%%  SD=%.2f\n",
            t1$mean_0, t1$sd_0))
cat(sprintf("  FR = 1 : mean=%.2f%%  SD=%.2f\n",
            t1$mean_1, t1$sd_1))
cat(sprintf(
  "  Diff=%.2f pp | t=%.3f | p=%.4f %s | d=%.3f (%s)\n\n",
  t1$diff, t1$t_stat, t1$p_value,
  t1$sig, t1$cohens_d, t1$effect_size))

cat("T2 : Solde primaire, fr_any :\n")
cat(sprintf("  No FR  : mean=%.2f%%  SD=%.2f\n",
            t2$mean_0, t2$sd_0))
cat(sprintf("  FR = 1 : mean=%.2f%%  SD=%.2f\n",
            t2$mean_1, t2$sd_1))
cat(sprintf(
  "  Diff=%.2f pp | t=%.3f | p=%.4f %s | d=%.3f (%s)\n\n",
  t2$diff, t2$t_stat, t2$p_value,
  t2$sig, t2$cohens_d, t2$effect_size))

cat("T3 : Dette/PIB, fr_none vs fr_strong :\n")
cat(sprintf("  No rule    : mean=%.2f%%\n", t3$mean_0))
cat(sprintf("  Strong(2+) : mean=%.2f%%\n", t3$mean_1))
cat(sprintf(
  "  Diff=%.2f pp | t=%.3f | p=%.4f %s | d=%.3f (%s)\n\n",
  t3$diff, t3$t_stat, t3$p_value,
  t3$sig, t3$cohens_d, t3$effect_size))

cat("T9 : Dette/PIB avant/apres adoption :\n")
if (!is.null(t9d)) {
  cat(sprintf("  Before : mean=%.2f%%\n", t9d$mean_0))
  cat(sprintf("  After  : mean=%.2f%%\n", t9d$mean_1))
  cat(sprintf(
    "  Diff=%.2f pp | t=%.3f | p=%.4f %s | d=%.3f (%s)\n\n",
    t9d$diff, t9d$t_stat, t9d$p_value,
    t9d$sig, t9d$cohens_d, t9d$effect_size))
} else {
  cat("  Donnees insuffisantes\n\n")
}

cat("=== FIGURES PRODUITES ===\n")
for (f in list.files("output/figures/",
                     pattern = "^tt.*\\.png$"))
  cat(" •", f, "\n")

cat("\n=== NOTE METHODOLOGIQUE ===\n")
cat("Tests DESCRIPTIFS : pas de controles.\n")
cat("Estimations causales : Section 4 (Local Projections).\n")
cat("CAPB et dette dom./ext. : sources a integrer.\n\n")
cat("=== TERMINE ===\n\n")

