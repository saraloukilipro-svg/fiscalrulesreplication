root <- normalizePath(".")
dir.create(file.path(root, "output", "figures", "final"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(root, "output", "latex"), recursive = TRUE, showWarnings = FALSE)
loc <- Sys.getlocale("LC_CTYPE"); if (!grepl("UTF-?8", loc, ignore.case = TRUE)) loc <- "C.UTF-8"
for (s in c("fig1_debt_with_without_rules.R", "fig3_primary_balance_high_gpr.R", "fig5a_ttests.R", "fig5b_cohens_d.R")) {
  cat(format(Sys.time(), "%H:%M:%S"), "->", s, "\n")
  st <- system2("Rscript", file.path(root, "code", "unchanged_figures", s),
                stdout = file.path(root, "logs", sub("\\.R$", ".log", s)), stderr = file.path(root, "logs", sub("\\.R$", ".log", s)),
                env = c(paste0("FRR_ROOT=", root), paste0("LC_ALL=", loc), paste0("LANG=", loc)))
  if (st != 0) stop("Échec de ", s, " : voir logs/", sub("\\.R$", ".log", s))
}
