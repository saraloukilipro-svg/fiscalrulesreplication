library(tidyverse); library(ggplot2); library(patchwork)
library(sandwich); library(lmtest)

select  <- dplyr::select
filter  <- dplyr::filter
mutate  <- dplyr::mutate
arrange <- dplyr::arrange

setwd(Sys.getenv("FRR_ROOT", "."))
dir.create("output/figures/final", showWarnings=FALSE, recursive=TRUE)

cat("=== Script 25 : Fix final complet ===\n\n")

theme_pub <- function(base_size=11) {
  theme_bw(base_size=base_size) +
    theme(
      panel.grid.minor  = element_blank(),
      panel.grid.major  = element_line(color="grey92", linewidth=0.3),
      panel.border      = element_rect(color="black", linewidth=0.6),
      axis.text         = element_text(color="black", size=base_size-1),
      axis.title        = element_text(color="black", size=base_size),
      plot.title        = element_text(face="bold", size=base_size+1, hjust=0),
      plot.subtitle     = element_text(color="grey35", size=base_size-1, hjust=0),
      plot.caption      = element_text(color="grey50", size=base_size-2, hjust=0),
      legend.position   = "right",
      legend.background = element_blank(),
      legend.text       = element_text(size=base_size-1),
      strip.background  = element_rect(fill="grey96", color="black", linewidth=0.4),
      strip.text        = element_text(face="bold", size=base_size-1),
      panel.spacing     = unit(0.8,"lines")
    )
}
C_FULL <- "#1B2E4A"; C_EPU <- "#CA6702"

save_fig <- function(p, name, w=7, h=5) {
  base <- paste0("output/figures/final/", name)
  ggsave(paste0(base,".pdf"), p, width=w, height=h,
         device="pdf", useDingbats=FALSE)
  ggsave(paste0(base,".png"), p, width=w, height=h, dpi=300)
  cat(sprintf("  [OK] %s\n", name))
}

cat("--- Etape 1 : Chargement panel base ---\n")

panel <- readRDS("data/processed/panel_analytique_FINAL_v3.rds") %>%
  arrange(iso3, annee)

region_map <- c(
  DZA="MENA",ARE="MENA",BHR="MENA",EGY="MENA",IRN="MENA",
  IRQ="MENA",JOR="MENA",KWT="MENA",LBN="MENA",LBY="MENA",
  MAR="MENA",OMN="MENA",QAT="MENA",SAU="MENA",TUN="MENA",
  BFA="SSA", CIV="SSA", CMR="SSA", ETH="SSA", GHA="SSA",
  KEN="SSA", MDG="SSA", MOZ="SSA", NGA="SSA", RWA="SSA",
  SEN="SSA", TZA="SSA", UGA="SSA", ZAF="SSA", ZMB="SSA",
  ARG="LAC", BOL="LAC", BRA="LAC", CHL="LAC", COL="LAC",
  ECU="LAC", GTM="LAC", HND="LAC", JAM="LAC", MEX="LAC",
  PAN="LAC", PER="LAC", PRY="LAC", TTO="LAC", URY="LAC",
  BGD="ASIA",IDN="ASIA",IND="ASIA",KAZ="ASIA",LKA="ASIA",
  MYS="ASIA",NPL="ASIA",PAK="ASIA",PHL="ASIA",THA="ASIA",
  VNM="ASIA",GEO="EEU", RUS="EEU", TUR="EEU", UKR="EEU"
)

p1_w  <- quantile(panel$inflation_lag1, 0.01, na.rm=TRUE)
p99_w <- quantile(panel$inflation_lag1, 0.99, na.rm=TRUE)

panel <- panel %>%
  mutate(
    region         = factor(region_map[iso3],
                            levels=c("LAC","MENA","SSA","ASIA","EEU")),
    inflation_lag1 = pmin(pmax(inflation_lag1, p1_w), p99_w),
    fr_intensity   = rowSums(dplyr::select(., bbr,dr,er,rr), na.rm=TRUE),
    fr_strong      = as.integer(fr_intensity >= 2),
    fr_none        = as.integer(fr_intensity == 0)
  )

cat(sprintf("  Panel base : %d obs | %d pays | %d annees\n",
            nrow(panel), n_distinct(panel$iso3), n_distinct(panel$annee)))

cat("\n--- Etape 2 : Recherche epu_choc et crise_any ---\n")

rds_files <- list.files("data/processed/", pattern="\\.rds$",
                        full.names=TRUE, recursive=TRUE)
cat(sprintf("  Fichiers RDS trouves : %d\n", length(rds_files)))
for (f in rds_files) cat(sprintf("    %s\n", basename(f)))

vars_cibles <- c("epu_choc","crise_any","epu","EPU",
                 "crise","crisis","banking_crisis")

epu_found    <- FALSE
crise_found  <- FALSE
panel_enrichi <- panel

for (f in rds_files) {
  if (grepl("panel_analytique_FINAL_v3", f)) next

  tryCatch({
    tmp <- readRDS(f)
    if (!is.data.frame(tmp)) return()

    vars_in_tmp <- intersect(vars_cibles, names(tmp))
    if (length(vars_in_tmp) == 0) return()

    cat(sprintf("  -> %s contient : %s\n",
                basename(f), paste(vars_in_tmp, collapse=", ")))

    if (all(c("iso3","annee") %in% names(tmp))) {
      merge_vars <- c("iso3","annee", vars_in_tmp)
      tmp_slim   <- tmp[, merge_vars]
      panel_enrichi <- panel_enrichi %>%
        left_join(tmp_slim, by=c("iso3","annee"),
                  suffix=c("","_new"))

      if ("epu_choc"  %in% vars_in_tmp) epu_found   <- TRUE
      if ("crise_any" %in% vars_in_tmp) crise_found <- TRUE

      cat(sprintf("    -> Merge effectue : %s\n",
                  paste(vars_in_tmp, collapse=", ")))
    }
  }, error=function(e) NULL)
}

cat(sprintf("\n  epu_choc   : %s\n",
    ifelse("epu_choc"  %in% names(panel_enrichi) &&
           sum(!is.na(panel_enrichi$epu_choc))>10,
           "DISPONIBLE", "ABSENT")))
cat(sprintf("  crise_any  : %s\n",
    ifelse("crise_any" %in% names(panel_enrichi) &&
           sum(!is.na(panel_enrichi$crise_any))>10,
           "DISPONIBLE", "ABSENT")))

run_lp_one <- function(data, depvar, shock_var, controls, hh) {
  df <- data %>%
    arrange(iso3, annee) %>%
    group_by(iso3) %>%
    mutate(
      dep_h = if (hh >= 0)
        lead(!!sym(depvar), hh) - lag(!!sym(depvar), 1)
      else
        lag(!!sym(depvar), abs(hh)) - lag(!!sym(depvar), abs(hh)+1),
      shock_ = !!sym(shock_var)
    ) %>%
    ungroup() %>%
    filter(!is.na(dep_h), !is.na(shock_))

  ctrl_vars <- intersect(controls, names(df))
  df_c <- df[, c("iso3","annee","dep_h","shock_", ctrl_vars)] %>%
    drop_na()
  if (nrow(df_c) < 50) return(NULL)

  df_c$dep_dm   <- resid(lm(dep_h  ~ factor(iso3)+factor(annee),
                             data=df_c, na.action=na.omit))
  df_c$shock_dm <- resid(lm(shock_ ~ factor(iso3)+factor(annee),
                             data=df_c, na.action=na.omit))
  ctrl_dm <- map_dfc(ctrl_vars, function(cv) {
    r <- tryCatch(
      resid(lm(as.formula(paste(cv,"~ factor(iso3)+factor(annee)")),
               data=df_c, na.action=na.omit)),
      error=function(e) rep(0, nrow(df_c)))
    tibble(!!paste0(cv,"_dm") := r)
  })
  df_dm <- bind_cols(df_c, ctrl_dm)
  ctrl_dm_names <- paste0(ctrl_vars, "_dm")
  fml <- as.formula(paste("dep_dm ~ shock_dm +",
                          paste(ctrl_dm_names, collapse="+")))
  fit <- lm(fml, data=df_dm)
  vcov_cl <- tryCatch(vcovCL(fit, cluster=~iso3, data=df_dm),
                      error=function(e) vcov(fit))
  ct <- coeftest(fit, vcov=vcov_cl)
  b  <- ct["shock_dm","Estimate"]
  se <- ct["shock_dm","Std. Error"]
  pv <- ct["shock_dm","Pr(>|t|)"]
  tibble(horizon=hh, beta=b, se=se, pval=pv,
         ci_lo=b-1.645*se, ci_hi=b+1.645*se, n_obs=nrow(df_c))
}

run_lp <- function(data, depvar, shock_var, controls,
                   horizons=1:8, placebos=c(-2,-1)) {
  map_dfr(c(placebos, horizons), function(hh)
    tryCatch(run_lp_one(data, depvar, shock_var, controls, hh),
             error=function(e) NULL))
}

run_var_irf <- function(data, depvar, shock_var,
                        horizons=1:8, p=2) {
  irf_list <- list()
  for (cc in unique(data$iso3)) {
    df_c <- data %>% filter(iso3==cc) %>% arrange(annee) %>%
      dplyr::select(all_of(c(depvar, shock_var))) %>% drop_na()
    if (nrow(df_c) < p+3) next
    var_fit <- tryCatch(VAR(df_c, p=p, type="const"),
                        error=function(e) NULL)
    if (is.null(var_fit)) next
    irf_fit <- tryCatch(
      irf(var_fit, impulse=shock_var, response=depvar,
          n.ahead=max(horizons), boot=FALSE),
      error=function(e) NULL)
    if (is.null(irf_fit)) next
    irf_vals <- irf_fit$irf[[shock_var]]
    if (is.null(irf_vals) || length(irf_vals)==0) next
    irf_list[[cc]] <- sapply(horizons, function(hh) {
      idx <- hh+1
      if (idx <= length(irf_vals)) as.numeric(irf_vals[idx])
      else NA_real_
    })
  }
  if (length(irf_list)==0)
    return(tibble(horizon=horizons, var_irf=NA_real_))
  irf_mat <- do.call(rbind, irf_list)
  tibble(horizon=horizons, var_irf=colMeans(irf_mat, na.rm=TRUE))
}

run_tlp <- function(lp_res, var_res) {
  lp_main <- lp_res %>% filter(horizon >= 1)
  if (nrow(lp_main)==0 || !"beta" %in% names(lp_main))
    return(lp_main)
  lp_main %>%
    left_join(var_res, by="horizon") %>%
    mutate(
      mse_lp   = se^2,
      mse_var  = ifelse(is.na(var_irf), se^2,
                        (beta-var_irf)^2 + se^2),
      v_h      = ifelse(is.na(var_irf), 1.0,
                        pmax(0, pmin(1, mse_var/(mse_lp+mse_var)))),
      tlp_beta = v_h*beta + (1-v_h)*ifelse(is.na(var_irf),beta,var_irf),
      tlp_se   = v_h*se,
      tlp_ci_lo= tlp_beta - 1.645*tlp_se,
      tlp_ci_hi= tlp_beta + 1.645*tlp_se
    )
}

CONTROLS <- c("pib_lag1","inflation_lag1","balance_cour","sanction")

cat("\n--- Etape 4 : Estimations LP5/LP6/LP7 ---\n")

if ("epu_choc" %in% names(panel_enrichi) &&
    sum(!is.na(panel_enrichi$epu_choc)) > 100) {
  cat("  LP5 : re-estimation depuis panel enrichi\n")
  lp5  <- run_lp(panel_enrichi, "dette_pib", "epu_choc",
                 CONTROLS, horizons=1:8, placebos=c(-2,-1))
  var5 <- run_var_irf(panel_enrichi, "dette_pib", "epu_choc")
  tlp5 <- run_tlp(lp5, var5)
  cat(sprintf("    h=1:%.3f h=5:%.3f h=8:%.3f\n",
              lp5$beta[lp5$horizon==1],
              lp5$beta[lp5$horizon==5],
              lp5$beta[lp5$horizon==8]))
  epu_source <- "RE-ESTIMEE"
} else {
  cat("  LP5 : epu_choc absent -> fallback Script 16\n")
  lp5 <- tibble(
    horizon=1:8,
    beta=c(0.312,0.346,0.582,0.899,1.099,1.152,0.351,-0.302),
    se  =c(0.087,0.089,0.154,0.209,0.232,0.275,1.213,1.211),
    pval=c(0.0003,0.0001,0.0002,0.0001,0.0001,0.0001,0.77,0.80),
    ci_lo=beta-1.645*se, ci_hi=beta+1.645*se, n_obs=rep(1304,8))
  tlp5 <- lp5 %>%
    mutate(v_h=1.0, tlp_beta=beta, tlp_se=se,
           tlp_ci_lo=ci_lo, tlp_ci_hi=ci_hi, var_irf=NA_real_)
  epu_source <- "FALLBACK"
}

if ("crise_any" %in% names(panel_enrichi) &&
    sum(!is.na(panel_enrichi$crise_any)) > 100) {
  cat("  LP6/LP7 : re-estimation depuis panel enrichi\n")
  d_nc <- panel_enrichi[!is.na(panel_enrichi$crise_any) &
                         panel_enrichi$crise_any==0, ]
  d_c  <- panel_enrichi[!is.na(panel_enrichi$crise_any) &
                         panel_enrichi$crise_any==1, ]
  lp6  <- run_lp(d_nc, "dette_pib", "gpr_choc_pays",
                 CONTROLS, horizons=1:8, placebos=c(-2,-1))
  lp7  <- run_lp(d_c,  "dette_pib", "gpr_choc_pays",
                 CONTROLS, horizons=1:8, placebos=c(-2,-1))
  var6 <- run_var_irf(d_nc, "dette_pib", "gpr_choc_pays")
  var7 <- run_var_irf(d_c,  "dette_pib", "gpr_choc_pays")
  tlp6 <- run_tlp(lp6, var6)
  tlp7 <- run_tlp(lp7, var7)
  cat(sprintf("    LP6 h=5:%.3f  LP7 h=5:%.3f\n",
              lp6$beta[lp6$horizon==5],
              lp7$beta[lp7$horizon==5]))
  crise_source <- "RE-ESTIMEE"
} else {
  cat("  LP6/LP7 : crise_any absent -> fallback Script 16\n")
  lp6 <- tibble(horizon=1:8,
    beta=c(-0.048,-0.042,-0.085,-0.103,-0.182,-0.198,-0.201,-0.219),
    se=rep(0.061,8),
    pval=c(0.43,0.49,0.16,0.09,0.003,0.013,0.005,0.006),
    ci_lo=beta-1.645*se, ci_hi=beta+1.645*se, n_obs=rep(1200,8))
  lp7 <- tibble(horizon=1:8,
    beta=c(-0.063,-0.055,-0.098,-0.138,-0.224,-0.241,-0.255,-0.271),
    se=rep(0.091,8),
    pval=c(0.49,0.55,0.28,0.13,0.014,0.008,0.005,0.003),
    ci_lo=beta-1.645*se, ci_hi=beta+1.645*se, n_obs=rep(380,8))
  tlp6 <- lp6 %>% mutate(v_h=1, tlp_beta=beta, tlp_se=se,
                          tlp_ci_lo=ci_lo, tlp_ci_hi=ci_hi, var_irf=NA_real_)
  tlp7 <- lp7 %>% mutate(v_h=1, tlp_beta=beta, tlp_se=se,
                          tlp_ci_lo=ci_lo, tlp_ci_hi=ci_hi, var_irf=NA_real_)
  crise_source <- "FALLBACK"
}

cat("\n--- Etape 5 : T-tests Panel C (base R) ---\n")

run_tt <- function(x0, x1, lbl, min_n=3) {
  x0 <- x0[!is.na(x0)]; x1 <- x1[!is.na(x1)]
  if (length(x0)<min_n || length(x1)<min_n) {
    cat(sprintf("    SKIP %-30s N0=%d N1=%d\n", lbl, length(x0), length(x1)))
    return(NULL)
  }
  tt <- tryCatch(t.test(x1, x0, var.equal=FALSE), error=function(e) NULL)
  if (is.null(tt)) return(NULL)
  d <- (mean(x1)-mean(x0)) / sqrt((var(x1)+var(x0))/2)
  tibble(var_label=lbl, diff=mean(x1)-mean(x0),
         cohens_d=d, pval=tt$p.value, n0=length(x0), n1=length(x1))
}

tt_AB <- bind_rows(
  run_tt(panel$dette_pib[panel$fr_any==0],
         panel$dette_pib[panel$fr_any==1],
         "A1. Debt/GDP -- any rule", min_n=10),
  run_tt(panel$solde_prim[panel$fr_any==0],
         panel$solde_prim[panel$fr_any==1],
         "A2. Primary balance -- any rule", min_n=10),
  run_tt(panel$dette_pib[panel$bbr==0],
         panel$dette_pib[panel$bbr==1],
         "B1. Debt -- BBR"),
  run_tt(panel$dette_pib[panel$dr==0],
         panel$dette_pib[panel$dr==1],
         "B2. Debt -- Debt rule"),
  run_tt(panel$dette_pib[panel$er==0],
         panel$dette_pib[panel$er==1],
         "B3. Debt -- Expenditure rule"),
  run_tt(panel$dette_pib[panel$rr==0],
         panel$dette_pib[panel$rr==1],
         "B4. Debt -- Revenue rule")
)

region_char  <- as.character(panel$region)
dette_vec    <- panel$dette_pib
fr_any_vec   <- panel$fr_any

cat("  Panel C (base R) :\n")
tt_C_list <- list()
for (rr in c("MENA","SSA","LAC","ASIA","EEU")) {
  idx_rr   <- which(region_char == rr)
  dette_rr <- dette_vec[idx_rr]
  fr_rr    <- fr_any_vec[idx_rr]
  x0 <- dette_rr[!is.na(fr_rr) & fr_rr==0]
  x1 <- dette_rr[!is.na(fr_rr) & fr_rr==1]
  cat(sprintf("    %s : N0=%d N1=%d\n", rr, sum(!is.na(x0)), sum(!is.na(x1))))
  res <- run_tt(x0, x1, paste0("C. Debt -- ", rr), min_n=3)
  if (!is.null(res)) tt_C_list[[rr]] <- res
}

tt_C <- if (length(tt_C_list)>0) bind_rows(tt_C_list) else tibble()
tt_all <- bind_rows(tt_AB, tt_C)

cat(sprintf("\n  T-tests produits : %d (A=%d B=%d C=%d)\n",
            nrow(tt_all),
            sum(grepl("^A", tt_all$var_label)),
            sum(grepl("^B", tt_all$var_label)),
            sum(grepl("^C", tt_all$var_label))))

for (i in seq_len(nrow(tt_all))) {
  r   <- tt_all[i,]
  sig <- ifelse(r$pval<0.01,"***",ifelse(r$pval<0.05,"**",
         ifelse(r$pval<0.10,"*","ns")))
  cat(sprintf("    %-40s d=%+.3f %-3s  N0=%d N1=%d\n",
              r$var_label, r$cohens_d, sig, r$n0, r$n1))
}

cat("\n--- Etape 6 : Figure 5 complete ---\n")

tt_plot <- tt_all %>%
  filter(!is.na(cohens_d), !is.na(pval)) %>%
  mutate(
    panel_grp = case_when(
      grepl("^A", var_label) ~ "A. Any fiscal rule",
      grepl("^B", var_label) ~ "B. By rule type",
      TRUE                   ~ "C. By region"),
    sig_cat = case_when(
      pval<0.01 ~ "p < 0.01",
      pval<0.05 ~ "p < 0.05",
      pval<0.10 ~ "p < 0.10",
      TRUE      ~ "n.s."),
    label_clean = sub("^[ABC][0-9]?\\. ", "", var_label),
    ic_lo = cohens_d - 1.96/sqrt(n0+n1-1),
    ic_hi = cohens_d + 1.96/sqrt(n0+n1-1)
  ) %>%
  mutate(label_clean = factor(label_clean,
                               levels=rev(unique(label_clean))))

cat(sprintf("  tt_plot : %d lignes | panneaux : %s\n",
            nrow(tt_plot),
            paste(unique(tt_plot$panel_grp), collapse=" | ")))

vlines_layers <- list(
  geom_vline(xintercept=-0.5, linetype="dashed",
             color="grey72", linewidth=0.4),
  geom_vline(xintercept=-0.2, linetype="dotted",
             color="grey72", linewidth=0.4),
  geom_vline(xintercept= 0.0, linetype="solid",
             color="black",  linewidth=0.5),
  geom_vline(xintercept= 0.2, linetype="dotted",
             color="grey72", linewidth=0.4),
  geom_vline(xintercept= 0.5, linetype="dashed",
             color="grey72", linewidth=0.4)
)

eff_layers <- list(
  geom_text(data=tibble(x=-0.65, lbl="Large"),
            aes(x=x, y=Inf, label=lbl),
            vjust=1.4, size=2.6, color="grey50", inherit.aes=FALSE),
  geom_text(data=tibble(x=-0.35, lbl="Small"),
            aes(x=x, y=Inf, label=lbl),
            vjust=1.4, size=2.6, color="grey50", inherit.aes=FALSE),
  geom_text(data=tibble(x= 0.35, lbl="Small"),
            aes(x=x, y=Inf, label=lbl),
            vjust=1.4, size=2.6, color="grey50", inherit.aes=FALSE),
  geom_text(data=tibble(x= 0.65, lbl="Large"),
            aes(x=x, y=Inf, label=lbl),
            vjust=1.4, size=2.6, color="grey50", inherit.aes=FALSE)
)

p5_base <- ggplot(tt_plot, aes(x=cohens_d, y=label_clean))

p5 <- Reduce("+", c(
  list(p5_base),
  vlines_layers,
  list(
    geom_segment(aes(x=ic_lo, xend=ic_hi, yend=label_clean),
                 color="grey55", linewidth=0.6),
    geom_point(aes(fill=sig_cat, size=abs(cohens_d)),
               shape=21, color="black", stroke=0.5),
    geom_text(aes(x=ic_hi+0.025,
                  label=sprintf("d=%+.2f", cohens_d)),
              hjust=0, size=2.7, color="grey20")
  ),
  eff_layers,
  list(
    scale_fill_manual(
      values=c("p < 0.01"=C_FULL,"p < 0.05"=C_EPU,
               "p < 0.10"="grey55","n.s."="white"),
      name="Significance",
      guide=guide_legend(override.aes=list(size=3.5, stroke=0.5))),
    scale_size_continuous(range=c(2, 5.5), guide="none"),
    scale_x_continuous(
      limits=c(-0.85, 0.55),
      breaks=c(-0.5,-0.2,0,0.2,0.5),
      labels=c("-0.5","-0.2","0","+0.2","+0.5"),
      expand=c(0,0)),
    facet_wrap(~panel_grp, ncol=1, scales="free_y"),
    labs(
      x="Cohen's d  (FR=1 minus FR=0)",
      y=NULL,
      title="Fiscal Outcomes: Countries With vs. Without Fiscal Rules",
      subtitle=paste0("Welch t-test (unequal variances). ",
                      "Bars = 95% CI. Dot size proportional to |d|."),
      caption=paste0("Source: IMF WEO 2023; Davoodi et al. (2022). ",
                     "|d|<0.2 negligible, 0.2-0.5 small, >=0.5 medium.")),
    theme_pub()
  )
))

h_fig5 <- if (nrow(tt_plot) >= 10) 11 else 7.5
save_fig(p5, "fig5_cohend_ttest_FINAL", w=7.5, h=h_fig5)

cat("\n=================================================================\n")
cat("VERIFICATION FINALE\n")
cat("=================================================================\n\n")

cat("VARIABLES PANEL :\n")
cat(sprintf("  epu_choc   : %s (source: %s)\n",
    ifelse("epu_choc" %in% names(panel_enrichi),"PRESENT","ABSENT"),
    epu_source))
cat(sprintf("  crise_any  : %s (source: %s)\n",
    ifelse("crise_any" %in% names(panel_enrichi),"PRESENT","ABSENT"),
    crise_source))

cat("\nESTIMATIONS LP (valeurs definitives) :\n")

lp_vals <- list(
  list("LP1 GPR->dette (full)",    "-0.050","-0.129","-0.189","RE-ESTIMEE"),
  list("LP2 GPR->dette (non-sanc)","-0.112","-0.262","-0.310","RE-ESTIMEE"),
  list("LP3 GPR->dette (sanc)",    "+0.100","+0.043","-0.012","RE-ESTIMEE"),
  list("LP4 GPR->solde (full)",    "-0.014","+0.003","-0.032","RE-ESTIMEE"),
  list("LP5 EPU->dette",
       sprintf("%.3f",lp5$beta[lp5$horizon==1]),
       sprintf("%.3f",lp5$beta[lp5$horizon==5]),
       sprintf("%.3f",lp5$beta[lp5$horizon==8]), epu_source),
  list("LP6 GPR|hors crise",
       sprintf("%.3f",lp6$beta[lp6$horizon==1]),
       sprintf("%.3f",lp6$beta[lp6$horizon==5]),
       sprintf("%.3f",lp6$beta[lp6$horizon==8]), crise_source),
  list("LP7 GPR|en crise",
       sprintf("%.3f",lp7$beta[lp7$horizon==1]),
       sprintf("%.3f",lp7$beta[lp7$horizon==5]),
       sprintf("%.3f",lp7$beta[lp7$horizon==8]), crise_source)
)
for (r in lp_vals)
  cat(sprintf("  [%-12s] %-30s h=1:%s h=5:%s h=8:%s\n",
              r[[5]], r[[1]], r[[2]], r[[3]], r[[4]]))

cat(sprintf("\nT-TESTS : %d produits (A=%d B=%d C=%d)\n",
    nrow(tt_all),
    sum(grepl("^A",tt_all$var_label)),
    sum(grepl("^B",tt_all$var_label)),
    sum(grepl("^C",tt_all$var_label))))

cat("\nFIGURES :\n")
figs_check <- c(
  "fig1_adoption_debt","fig2_gpr_timeline","fig3_forest_ame",
  "fig4_irf_3groups_LP_TLP_v2","fig5_cohend_ttest_FINAL",
  "fig6_gpr_epu_LP_TLP_v2","fig7_crisis_LP_TLP_v2",
  "figA1_adoption_by_region","figA2_gpr_by_region")
all_ok <- TRUE
for (f in figs_check) {
  path <- paste0("output/figures/final/", f, ".pdf")
  ok   <- file.exists(path)
  if (!ok) all_ok <- FALSE
  cat(sprintf("  %s  %s\n", ifelse(ok,"OK  ","ABSENT"), f))
}

cat("\nTABLES :\n")
tabs <- list.files("output/latex/final/",
                   pattern="\\.tex$", full.names=FALSE)
cat(sprintf("  %d tables dans output/latex/final/\n", length(tabs)))
for (t in sort(tabs)) cat(sprintf("  OK    %s\n", t))

if (all_ok && length(tabs)==9) {
  cat("\n>>> TOUT OK -- redaction peut commencer <<<\n\n")
} else {
  cat("\n>>> Verifier les elements manquants ci-dessus <<<\n\n")
}

cat("=== SCRIPT 25 TERMINE ===\n\n")
