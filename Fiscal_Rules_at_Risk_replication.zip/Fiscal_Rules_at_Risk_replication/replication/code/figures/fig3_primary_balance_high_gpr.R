rm(list = ls())
setwd(Sys.getenv("FRR_ROOT", "."))

library(dplyr); library(tidyr); library(ggplot2); library(scales)
library(patchwork)

df <- readRDS("data/processed/panel_analytique_FINAL_v3.rds")

d <- df %>% transmute(iso = iso3, year = as.integer(annee),
                      pb = solde_prim, fr = fr_any, sanc = sanction, gpr = gpr_global)
ymin <- min(d$year); ymax <- max(d$year)

base_off <- -1
hmax     <- 8

gy <- d %>% group_by(year) %>% summarise(gpr = mean(gpr, na.rm = TRUE), .groups = "drop")
thr_g <- quantile(gy$gpr, .90, na.rm = TRUE)
geo_years <- sort(gy$year[gy$gpr >= thr_g & gy$year <= ymax - hmax])

build_es <- function(d, years, base_off = -1, hmax = 8) {
  bind_rows(lapply(years, function(t0) {
    base <- d %>% filter(year == t0 + base_off) %>% select(iso, pb0 = pb, rule0 = fr, sanc0 = sanc)
    expand_grid(iso = base$iso, h = base_off:hmax) %>%
      mutate(year = t0 + h) %>% filter(year >= ymin, year <= ymax) %>%
      left_join(base, by = "iso") %>%
      left_join(select(d, iso, year, pb), by = c("iso","year")) %>%
      mutate(chg = pb - pb0)
  })) %>% filter(!is.na(chg))
}
agg <- function(es, by = NULL) es %>% group_by(across(all_of(c(by, "h")))) %>%
  summarise(m = mean(chg), se = sd(chg)/sqrt(n()),
            p25 = quantile(chg,.25), p75 = quantile(chg,.75), n = n(), .groups = "drop") %>%
  mutate(lo = m - 1.645*se, hi = m + 1.645*se)

es <- build_es(d, geo_years, base_off, hmax)

e0 <- es %>% filter(h == base_off)
n_rule_c <- n_distinct(e0$iso[e0$rule0 == 1]); n_sanc_c <- n_distinct(e0$iso[e0$sanc0 == 1])
n_rule_w <- sum(e0$rule0 == 1, na.rm = TRUE);  n_rule_wo <- sum(e0$rule0 == 0, na.rm = TRUE)

navy <- "#1F3B6F"; red <- "#B5253A"
theme_es <- theme_minimal(base_size = 11) +
  theme(panel.grid.minor = element_blank(), panel.grid.major.x = element_blank(),
        plot.title = element_text(face = "bold", size = 11),
        legend.position = "bottom", legend.title = element_blank(),
        axis.title = element_text(size = 9.5),
        plot.caption = element_text(colour = "grey40", size = 7.2, hjust = 0),
        plot.caption.position = "plot")
hseq <- base_off:hmax
xlab_for <- function(h) ifelse(h == 0, "t(0)", ifelse(h < 0, paste0("t", h), paste0("t+", h)))
xb <- hseq; xl <- xlab_for(hseq)

A <- agg(es)
pA <- ggplot(A, aes(h, m)) +
  geom_hline(yintercept = 0, colour = "grey60", linewidth = .3) +
  geom_vline(xintercept = 0, linetype = "dashed", colour = "grey75", linewidth = .3) +
  geom_ribbon(aes(ymin = p25, ymax = p75), alpha = .12, fill = navy) +
  geom_ribbon(aes(ymin = lo, ymax = hi), alpha = .28, fill = navy) +
  geom_line(colour = navy, linewidth = 1) + geom_point(colour = navy, size = 1.7) +
  scale_x_continuous(breaks = xb, labels = xl) +
  scale_y_continuous(labels = label_number(suffix = " pp")) +
  labs(title = "A. Response around high-GPR years",
       x = "Years around high-GPR year", y = "Cumulative change in primary balance") + theme_es

B <- agg(es %>% filter(!is.na(rule0)) %>%
           mutate(grp = ifelse(rule0 == 1, "With fiscal rule", "Without fiscal rule")), "grp")
pB <- ggplot(B, aes(h, m, colour = grp, fill = grp)) +
  geom_hline(yintercept = 0, colour = "grey60", linewidth = .3) +
  geom_vline(xintercept = 0, linetype = "dashed", colour = "grey75", linewidth = .3) +
  geom_ribbon(aes(ymin = lo, ymax = hi), alpha = .16, colour = NA) +
  geom_line(linewidth = 1) + geom_point(size = 1.7) +
  scale_colour_manual(values = c("With fiscal rule" = navy, "Without fiscal rule" = red)) +
  scale_fill_manual(values  = c("With fiscal rule" = navy, "Without fiscal rule" = red)) +
  scale_x_continuous(breaks = xb, labels = xl) +
  scale_y_continuous(labels = label_number(suffix = " pp")) +
  labs(title = "B. By fiscal-rule status", x = "Years around high-GPR year", y = NULL) + theme_es

C <- agg(es %>% filter(!is.na(sanc0)) %>%
           mutate(grp = ifelse(sanc0 == 1, "Sanctioned", "Not sanctioned")), "grp")
pC <- ggplot(C, aes(h, m, colour = grp, fill = grp)) +
  geom_hline(yintercept = 0, colour = "grey60", linewidth = .3) +
  geom_vline(xintercept = 0, linetype = "dashed", colour = "grey75", linewidth = .3) +
  geom_ribbon(aes(ymin = lo, ymax = hi), alpha = .16, colour = NA) +
  geom_line(linewidth = 1) + geom_point(size = 1.7) +
  scale_colour_manual(values = c("Sanctioned" = red, "Not sanctioned" = navy)) +
  scale_fill_manual(values  = c("Sanctioned" = red, "Not sanctioned" = navy)) +
  scale_x_continuous(breaks = xb, labels = xl) +
  scale_y_continuous(labels = label_number(suffix = " pp")) +
  labs(title = "C. By sanctions status", x = "Years around high-GPR year", y = NULL) + theme_es

cap <- sprintf(paste0(
  "Cumulative change in the primary balance (pp of GDP) relative to the year before the shock (t-1 = 0). ",
  "High-GPR: GPR >= %.0f (90th pct); window %s; horizon matches the LP (h = 1..8). Panel A: dark band 90%% CI, light band IQR.\n",
  "Panels B/C: %d rule (resp. %d sanctioned) countries vs control (N=%d vs %d obs); overlapping bands match the non-significant moderating effect of Section 4.\n",
  "The post-shock window spans the 2004-08 commodity boom and the 2008-09 GFC; between-group gaps (B, C) net out this common cycle. ",
  "Descriptive association, not identification (Section 4: local projections, Rigobon (2003)). Sources: IMF WEO; Caldara & Iacoviello (2022); FRD (Davoodi et al. 2022)."),
  thr_g, paste(geo_years, collapse = ", "), n_rule_c, n_sanc_c, n_rule_w, n_rule_wo)

fig <- (pA | pB | pC) +
  plot_annotation(
    title = sprintf("Primary-balance response around high-GPR years (%d EMDEs)", n_distinct(d$iso)),
    caption = cap,
    theme = theme(plot.title = element_text(face = "bold", size = 13),
                  plot.caption = element_text(colour = "grey40", size = 7.2, hjust = 0)))

ggsave("output/ES_primary_balance_highGPR_FINAL.pdf", fig, width = 13.5, height = 5.2)
cat("Saved -> output/ES_primary_balance_highGPR_FINAL.pdf\n")
cat(sprintf("threshold=%.1f | geo years=%s | rule countries=%d | sanctioned countries=%d | N with/without=%d/%d\n",
            thr_g, paste(geo_years, collapse=", "), n_rule_c, n_sanc_c, n_rule_w, n_rule_wo))

