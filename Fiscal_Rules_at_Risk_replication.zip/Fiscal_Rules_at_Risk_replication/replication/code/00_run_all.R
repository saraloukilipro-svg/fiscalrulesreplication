steps <- c("code/00_gpr_country.R",
           "code/02_lp_results.R",
           "code/03_epu.R",
           "code/04_fiscal_council.R",
           "code/06_fig2_rules.R",
           "code/07_gpr_measures.R",
           "code/08_figA2_gpr_regions.R",
           "code/09_probit_presence.R",
           "code/10_fc_escape.R")
dir.create("logs", showWarnings = FALSE)
for (s in steps) {
  log <- file.path("logs", sub("\\.R$", ".log", basename(s)))
  cat(format(Sys.time(), "%H:%M:%S"), "->", s, "\n")
  st <- system2("Rscript", s, stdout = log, stderr = log)
  if (st != 0) stop("Échec de ", s, " : voir ", log)
}
writeLines(capture.output(sessionInfo()), "logs/sessionInfo.txt")
cat("Terminé. Compiler ensuite ../main.tex.\n")
