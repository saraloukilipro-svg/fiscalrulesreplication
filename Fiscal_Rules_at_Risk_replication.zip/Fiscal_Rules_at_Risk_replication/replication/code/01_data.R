prep_panel <- function(path) {
  d <- as.data.table(readRDS(path))
  d[, `:=`(id = iso3, t = as.integer(annee),
           debt = dette_pib, pb = solde_prim, S = sanction, Sfin = sanction_fin,
           e = gpr_choc_pays, eg = gpr_choc, FR = fr_any, nFR = fr_count,
           gro = pib_lag1, inf = inflation_lag1, ca = balance_cour,
           infl = inflation, growth = pib_croissance, rev = rev_pub, dep = dep_pub, reg = region)]
  setorder(d, id, t)

  gc <- fread("data/processed/gpr_country_annual.csv")
  setorder(gc, iso3, annee)
  ar1 <- function(x) { l <- shift(x); ok <- !is.na(x) & !is.na(l); r <- rep(NA_real_, length(x))
    r[ok] <- resid(lm(x[ok] ~ l[ok])); r }
  gc[, `:=`(e_log_c = ar1(log(gprc)), e_std_c = gpr_choc_c / sd(gpr_choc_c, na.rm = TRUE)), by = iso3]
  gc <- gc[, .(id = iso3, t = annee, gprc_bp = 100 * gprc, e_c = 100 * gpr_choc_c, e_log_c, e_std_c)]
  d <- merge(d, gc, by = c("id", "t"), all.x = TRUE); setorder(d, id, t)
  d[, pays_spec := id %in% gc$id]
  for (v in c("e_log", "e_std"))
    d[, (v) := fifelse(pays_spec, get(paste0(v, "_c")), fifelse(is.na(gpr_choc_pays), NA_real_, 0))]
  if (Sys.getenv("GPR_MEASURE") == "submitted") {
    d[, e := gpr_choc_pays]
  } else {
    d[, e := fifelse(pays_spec, e_c, fifelse(is.na(gpr_choc_pays), NA_real_, 0))]
  }

  d[, int_s := fifelse(is.na(sanction_intensite), 0, sanction_intensite)]
  thr <- quantile(d[int_s > 0, int_s], .5, na.rm = TRUE)
  d[, `:=`(Smulti     = as.integer(fifelse(is.na(n_sanctions), 0, n_sanctions) >= 2),
           Sint       = as.integer(int_s >= thr & int_s > 0),
           Sfin_restr = fifelse(id %in% c("COL", "PHL", "IDN"), 0L, as.integer(Sfin)))]
  for (s in c("S", "Sfin", "Sfin_restr", "Smulti", "Sint"))
    d[, (paste0(s, "_l1")) := shift(get(s)), by = id]

  d[, `:=`(ca_l1 = shift(ca), FR_l1 = shift(FR), strong_l1 = as.integer(shift(nFR) >= 2),
           debt_l1 = shift(debt), e_l1 = shift(e), e_l2 = shift(e, 2)), by = id]

  q <- quantile(d$e, c(.01, .99), na.rm = TRUE)
  d[, e_win := pmin(pmax(e, q[1]), q[2])]
  c90 <- quantile(abs(d[pays_spec == TRUE, e]), .9, na.rm = TRUE)
  d[, `:=`(e_big = e * (abs(e) > c90), e_small = e * (abs(e) <= c90))]

  for (y in c("debt", "pb")) {
    for (h in 0:8) d[, (paste0("d_", y, "_h", h)) := shift(get(y), h, type = "lead") - shift(get(y), 1), by = id]
    d[, (paste0("d_", y, "_hm1")) := shift(get(y), 1) - shift(get(y), 2), by = id]
    d[, (paste0("d_", y, "_hm2")) := shift(get(y), 2) - shift(get(y), 3), by = id]
    for (k in 1:4) d[, (paste0("L", k, "d_", y)) := shift(get(y), k) - shift(get(y), k + 1), by = id]
  }

  d[, `:=`(g_r = growth / 100, p_r = infl / 100)]
  d[, gn       := (1 + g_r) * (1 + p_r) - 1]
  d[, ero_reel := -debt_l1 * g_r / (1 + gn)]
  d[, ero_prix := -debt_l1 * p_r * (1 + g_r) / (1 + gn)]
  d[, deficit  := dep - rev]
  d[, ddebt    := debt - debt_l1]
  d[, sfa      := ddebt - ero_reel - ero_prix - deficit]
  d[, int_pib  := pb + rev - dep]
  d[, r_eff    := fifelse(!is.na(debt_l1) & debt_l1 > 1, 100 * int_pib / debt_l1, NA_real_)]
  comps <- c("ddebt", "ero_prix", "ero_reel", "deficit", "sfa")
  for (h in 0:8) {
    for (v in c(comps, "growth", "infl")) d[, (paste0("c_", v, "_h", h)) := {
      L <- shift(get(v), 0:h, type = "lead"); if (!is.list(L)) L <- list(L); Reduce(`+`, L)
    }, by = id]
    d[, (paste0("d_reff_h", h)) := shift(r_eff, h, type = "lead") - shift(r_eff, 1), by = id]
    ok <- Reduce(`&`, lapply(paste0("c_", comps, "_h", h), function(v) !is.na(d[[v]])))
    d[, (paste0("ok_h", h)) := ok]
    d[, (paste0("pimax_h", h)) := {
      L <- shift(infl, 0:h, type = "lead"); if (!is.list(L)) L <- list(L)
      do.call(pmax, c(L, list(shift(infl, 1))))
    }, by = id]
  }
  attr(d, "c90") <- c90
  d
}

CTRL <- c("gro", "inf", "ca_l1", "S_l1")
yname <- function(y, h) if (h >= 0) paste0("d_", y, "_h", h) else paste0("d_", y, "_hm", abs(h))
lag_terms <- function(y, h, spec) {
  if (!spec %in% c("aug2", "aug4", "trend")) return(NULL)
  nl <- if (spec == "aug4") 4 else 2
  k  <- if (h >= 0) seq_len(nl) else seq.int(-h + 1, length.out = max(0, nl + h))
  c(if (length(k)) paste0("L", k, "d_", y), if (spec == "aug4") c("e_l1", "e_l2") else "e_l1")
}

lp <- function(dat, dep, shock, h, spec = "base", extra = NULL, lagvar = "debt")
  fe_ols(dat, dep, c(shock, extra, CTRL, lag_terms(lagvar, h, spec)), fe = if (spec == "trend") "trend" else "twoway")

pooled <- function(dat, dep, h, Svar, spec = "base", lagvar = "debt") {
  dat <- copy(dat)
  dat[, `:=`(xS = e * get(Svar), groS = gro * get(Svar), infS = inf * get(Svar), caS = ca_l1 * get(Svar))]
  lp(dat, dep, "e", h, spec, extra = c("xS", Svar, "groS", "infS", "caS"), lagvar = lagvar)
}
