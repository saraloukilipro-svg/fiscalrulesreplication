source("code/00_utils.R"); source("code/01_data.R")
suppressPackageStartupMessages(library(ggplot2))

B_BOOT <- 999; SEED <- 20261027; H <- 1:8; SANC_MAIN <- "Sfin"; SEUIL_PI <- 40
TAB <- "../tables"; FIG <- "../figures"; RES <- "results"
for (x in c(TAB, FIG, RES)) dir.create(x, showWarnings = FALSE, recursive = TRUE)
KEY <- file.path(RES, "key_numbers.txt"); cat("", file = KEY)
kv <- function(...) { l <- paste0(...); cat(l, "\n", file = KEY, append = TRUE); cat(l, "\n") }

d <- prep_panel("data/processed/panel_analytique_FINAL_v3.rds")
pays19 <- sort(unique(d[pays_spec == TRUE, id])); c90 <- attr(d, "c90")
sd_e <- sd(d[pays_spec == TRUE, e], na.rm = TRUE)
NOTE_LP <- paste0("Local projections with country and year fixed effects. Controls: lagged real GDP growth, ",
  "lagged inflation, lagged current account and lagged sanctions indicator. Fiscal-rule and sanctions states ",
  "are measured at $t-1$. The dependent variable is the cumulative change from $t-1$ to $t+h$. Standard errors ",
  "clustered by country in parentheses. ", STARS_NOTE)
kv("Écart-type du choc GPR : ", sprintf("%.2f", sd_e), " ; seuil des grands chocs : ", sprintf("%.2f", c90))
kv("Pays identifiants (", length(pays19), ") : ", paste(pays19, collapse = ", "))
dd <- d[!is.na(e)]; dd[, e_tw := as.numeric(resid(lm(e ~ factor(id) + factor(t), data = dd)))]
lev <- dd[, .(part = sum(e_tw^2)), by = id][, part := part / sum(part)][order(-part)]
fwrite(lev, file.path(RES, "identifying_variance_share.csv"))

shH <- rbindlist(lapply(c(1, 4, 6, 8), function(h) { m <- lp(d, yname("debt", h), "e", h); x <- m$d
  x[, r := as.numeric(resid(lm(e ~ factor(id) + factor(t), data = x)))]
  x <- merge(x, d[, .(id, t, pays_spec, Sfin_l1)], by = c("id", "t"))
  data.table(h = h, derniere_annee_choc = max(x$t), part_RUS_UKR = x[id %in% c("RUS", "UKR"), sum(r^2)] / sum(x$r^2),
             pays_identifiants_sous_sanctions = paste(sort(unique(x[pays_spec == TRUE & Sfin_l1 == 1, id])), collapse = " ")) }))
fwrite(shH, file.path(RES, "identifying_variance_share_by_h.csv"))
for (i in seq_len(nrow(shH))) kv(sprintf("h=%d : dernière année de choc %d ; part RUS+UKR %.3f ; pays identifiants sous sanctions financières : %s",
  shH$h[i], shH$derniere_annee_choc[i], shH$part_RUS_UKR[i], shH$pays_identifiants_sous_sanctions[i]))
kv("Part de la variance identifiante : UKR ", sprintf("%.3f", lev[id == "UKR", part]), " ; RUS ",
   sprintf("%.3f", lev[id == "RUS", part]), " ; ensemble ", sprintf("%.3f", lev[id %in% c("UKR", "RUS"), sum(part)]))

p1 <- quantile(d$inflation_lag1, .01, na.rm = TRUE); p99 <- quantile(d$inflation_lag1, .99, na.rm = TRUE)
d[, infl_l1_w := pmin(pmax(inflation_lag1, p1), p99)]
rows <- list(
  c("Outcome", "Debt/GDP (\\%)", "dette_pib"), c("", "Primary balance/GDP (\\%)", "solde_prim"),
  c("Shock", "Country GPR index, 19 countries (bp of articles)", "gprc_bp"),
  c("", "GPR shock, 19 countries with own index", "e19"),
  c("Fiscal rule", "Any fiscal rule (0/1)", "fr_any"), c("", "Balanced budget rule", "bbr"),
  c("", "Debt rule", "dr"), c("", "Expenditure rule", "er"), c("", "Revenue rule", "rr"),
  c("", "Multiple rules ($\\geq 2$)", "multi"),
  c("Institutional", "Economic sanctions, all GSDB (0/1)", "sanction"), c("", "Financial sanctions (0/1)", "sanction_fin"),
  c("", "Armed conflict (0/1)", "war_any"),
  c("Control", "GDP growth, lag (\\%)", "pib_lag1"), c("", "Inflation, lag (\\%)", "inflation_lag1"),
  c("", "Inflation, lag, winsorized (\\%)", "infl_l1_w"), c("", "Current account/GDP (\\%)", "balance_cour"),
  c("", "Debt/GDP, lag (\\%)", "dette_lag1"))
d[, `:=`(e19 = fifelse(pays_spec, e, NA_real_), multi = as.integer(nFR >= 2))]
fmtn <- function(x) formatC(x, format = "d", big.mark = ",")
body <- sapply(rows, function(r) { x <- d[[r[3]]]; x <- x[!is.na(x)]
  sprintf("%s & %s & %s & %.2f & %.2f & %.2f & %.2f & %.2f & %.2f & %.2f \\\\", r[1], r[2], fmtn(length(x)), mean(x), sd(x),
          min(x), quantile(x, .25), median(x), quantile(x, .75), max(x)) })
write_tex(file.path(TAB, "tab_summary_stats.tex"), "Descriptive statistics", "tab:summary_stats", "llrrrrrrrr",
  "Category & Variable & $N$ & Mean & SD & Min & P25 & Median & P75 & Max \\\\", body,
  paste0("60 countries, 1990--2022 (1,980 observations). GPR shock: residual of a country-specific ",
         "AR(1) model of the country-specific Caldara--Iacoviello index, in basis points of the share of newspaper articles. ",
         "The 41 countries without a country-specific index have no country shock (set to zero); the row for the 19 countries with their own index describes the identifying variation. ",
         "Inflation enters the local projections in levels; the winsorized series (1st and 99th percentiles) is used in the probits of rule presence ",
         "probits. Sources: IMF WEO 2023; \\citet{Davoodi2022}; \\citet{Felbermayr2020}; UCDP/PRIO; authors' calculations."))

SM1 <- paste0(SANC_MAIN, "_l1")
series <- list(
  pb_full     = list(y = "pb",   dat = d,               lab = "Panel A. GPR shock $\\rightarrow$ primary balance/GDP, full panel"),
  debt_full   = list(y = "debt", dat = d,               lab = "Panel B. GPR shock $\\rightarrow$ debt/GDP, full panel"),
  debt_nons   = list(y = "debt", dat = d[get(SM1) == 0], lab = "Panel C. GPR shock $\\rightarrow$ debt/GDP, no financial sanctions at $t-1$"),
  debt_sanc   = list(y = "debt", dat = d[get(SM1) == 1], lab = "Panel D. GPR shock $\\rightarrow$ debt/GDP, financial sanctions at $t-1$"),
  debt_nonsS  = list(y = "debt", dat = d[S_l1 == 0],    lab = "Panel A. Debt/GDP, no GSDB sanctions of any type at $t-1$"),
  debt_sancS  = list(y = "debt", dat = d[S_l1 == 1],    lab = "Panel B. Debt/GDP, GSDB sanctions of any type at $t-1$"))
resB <- rbindlist(lapply(names(series), function(k) { s <- series[[k]]
  rbindlist(lapply(c(-2, -1, H), function(h) cbind(data.table(serie = k, h = h),
    term_stats(lp(s$dat, yname(s$y, h), "e", h), "e", scale = sd_e, ident_ids = pays19)))) }))
fwrite(resB, file.path(RES, "lp_baseline.csv"))

panel_rows <- function(sid, hs) { r <- resB[serie == sid & h %in% hs][order(h)]
  c(sprintf("\\multicolumn{%d}{l}{\\textit{%s}} \\\\", length(hs) + 1, series[[sid]]$lab),
    paste("Coefficient &", paste(f_cs(r$coef, r$p), collapse = " & "), "\\\\"),
    paste(" &", paste(f_se(r$se), collapse = " & "), "\\\\"),
    paste("90\\% CI &", paste(f_ci(r$lo90, r$hi90), collapse = " & "), "\\\\"),
    paste("Per s.d.\\ shock (pp) &", paste(f_2(r$par_ET), collapse = " & "), "\\\\"),
    paste("Observations &", paste(f_n(r$N), collapse = " & "), "\\\\"),
    paste("Identifying countries &", paste(f_n(r$n_ident), collapse = " & "), "\\\\"), "\\addlinespace") }
for (pt in list(list(hs = 1:4, f = "tab_lp_part1.tex", n = "I", lab = "tab:lp_part1"),
                list(hs = 5:8, f = "tab_lp_part2.tex", n = "II", lab = "tab:lp_part2"))) {
  body <- unlist(lapply(c("pb_full", "debt_full", "debt_nons", "debt_sanc"), panel_rows, hs = pt$hs))
  write_tex(file.path(TAB, pt$f), sprintf("Dynamic fiscal effects of GPR shocks (Part %s: $h=%d$--$%d$)", pt$n, min(pt$hs), max(pt$hs)),
    pt$lab, sprintf("l *{%d}{c}", length(pt$hs)), paste("&", paste(sprintf("$h=%d$", pt$hs), collapse = " & "), "\\\\"), body,
    paste0(NOTE_LP, sprintf(" 90\\%% confidence intervals in brackets. Per s.d.\\ shock: response to a one-standard-deviation innovation among the 19 identifying countries (%.1f basis points). ", sd_e),
           "Identifying countries: countries with a country-specific GPR index in the estimation sample; the shock is zero for the other countries, ",
           "so only these countries contribute variation to the shock coefficient. Panels C and D split the sample by financial sanctions at $t-1$."))
}
body <- unlist(lapply(c("debt_nonsS", "debt_sancS"), panel_rows, hs = H))
write_tex(file.path(TAB, "tab_lp_allsanc.tex"), "Debt response by sanctions status, all GSDB sanctions", "tab:lp_allsanc",
  "l *{8}{c}", paste("&", paste(sprintf("$h=%d$", H), collapse = " & "), "\\\\"), body,
  paste(NOTE_LP, "90\\% confidence intervals in brackets."), size = "\\scriptsize")
g <- function(sid, hh, col = "coef") resB[serie == sid & h == hh][[col]]
kv("Dette plein : h1 ", sprintf("%.3f", g("debt_full", 1)), " ; h5 ", sprintf("%.3f (%.3f) p=%.3f", g("debt_full", 5), g("debt_full", 5, "se"), g("debt_full", 5, "p")),
   " ; h8 ", sprintf("%.3f (%.3f) p=%.3f", g("debt_full", 8), g("debt_full", 8, "se"), g("debt_full", 8, "p")),
   " ; par é.-t. h5 ", sprintf("%.2f", g("debt_full", 5, "par_ET")), " h8 ", sprintf("%.2f", g("debt_full", 8, "par_ET")),
   " ; choc de ", sprintf("%.1f", c90), " points h8 : ", sprintf("%.2f", g("debt_full", 8) * c90))
kv("Solde primaire : h1 ", sprintf("%.3f p=%.3f", g("pb_full", 1), g("pb_full", 1, "p")), " ; h8 ", sprintf("%.3f p=%.3f", g("pb_full", 8), g("pb_full", 8, "p")))
for (k in c("debt_nons", "debt_sanc")) kv(k, " : ", paste(sprintf("h%d %.3f%s", H, resB[serie == k & h %in% H, coef], etoiles(resB[serie == k & h %in% H, p])), collapse = " "),
   " ; N h1 ", g(k, 1, "N"), " h8 ", g(k, 8, "N"))
kv("N dette plein par horizon : ", paste(resB[serie == "debt_full" & h %in% H, N], collapse = " "))

fg <- resB[serie %in% c("debt_full", "debt_nons", "debt_sanc")]
fg[, groupe := factor(serie, c("debt_full", "debt_nons", "debt_sanc"), c("Full panel", "No financial sanctions", "Financial sanctions"))]
p4 <- ggplot(fg, aes(h, coef)) + geom_hline(yintercept = 0, linewidth = .3) + geom_vline(xintercept = -0.5, linetype = "dashed", linewidth = .3) +
  geom_ribbon(data = fg[h >= 1], aes(ymin = lo90, ymax = hi90), alpha = .18) + geom_line(data = fg[h >= 1], linewidth = .8) +
  geom_pointrange(data = fg[h < 0], aes(ymin = lo90, ymax = hi90), size = .25, linetype = "dotted") + geom_point(data = fg[h >= 1], size = 1.4) +
  facet_wrap(~groupe, nrow = 1) + scale_x_continuous(breaks = c(-2, -1, H)) +
  labs(x = "Horizon (years); h = -2, -1 are placebo leads", y = "Debt/GDP response (pp per basis point)") +
  theme_bw(base_size = 10) + theme(panel.grid.minor = element_blank())
ggsave(file.path(FIG, "fig_lp_debt.pdf"), p4, width = 9, height = 3.4)

SDEFS <- c("Sfin", "Sfin_restr", "Smulti", "S", "Sint")
SLAB <- c(Sfin = "Financial sanctions", Sfin_restr = "Financial, excl.\\ COL, PHL, IDN", Smulti = "Multiple sanctions",
          S = "All GSDB sanctions", Sint = "High-intensity sanctions")
resC <- list()
for (Sv in SDEFS) for (sp in c("base", "aug2")) for (h in H) {
  m <- pooled(d, yname("debt", h), h, paste0(Sv, "_l1"), sp)
  boot <- (Sv == SANC_MAIN) || (sp == "aug2" && h >= 4) || (Sv == "S" && sp == "base" && h >= 4)
  b <- term_stats(m, "e"); p <- term_stats(m, "xS"); pdk <- term_stats(m, "xS", vc = "DK"); lc <- lincom_stats(m, "e", "xS")
  resC[[length(resC) + 1]] <- data.table(sanction = Sv, spec = sp, h = h, b = b$coef, p_b = b$p, pi = p$coef, se_pi = p$se,
    p_cluster = p$p, p_DK = pdk$p, p_WCB = if (boot) wcb_p(m, "xS", B_BOOT, SEED) else NA_real_,
    resp_s = lc[1], se_s = lc[2], p_s = lc[3], N = p$N)
}
resC <- rbindlist(resC); fwrite(resC, file.path(RES, "sanctions_gap.csv"))
for (sp in c("base", "aug2")) { r <- resC[sanction == SANC_MAIN & spec == sp][order(h)]
  body <- sprintf("$h=%d$ & %s & %s & %s & %s & %s & %s & %s & %s \\\\", r$h, f_cs(r$b, r$p_b), f_cs(r$pi, r$p_cluster), f_se(r$se_pi),
                  f_p(r$p_cluster), f_p(r$p_DK), f_p(r$p_WCB), f_cs(r$resp_s, r$p_s), f_n(r$N))
  write_tex(file.path(TAB, sprintf("tab_gap%s.tex", if (sp == "base") "" else "_aug2")),
    sprintf("Direct test of the sanctions gap: pooled local projection%s", if (sp == "base") "" else ", with two lags of the change in debt"),
    if (sp == "base") "tab:gap" else "tab:gap_aug2", "l *{8}{c}",
    "& $\\beta_h$ & $\\pi_h$ & s.e.($\\pi_h$) & $p$ cluster & $p$ DK & $p$ WCB & $\\beta_h+\\pi_h$ & $N$ \\\\", body,
    paste0("Pooled local projection of the cumulative change in debt/GDP on the GPR shock, its interaction with financial sanctions at $t-1$, ",
           "the sanctions state and the controls, all controls also interacted with the sanctions state; country and year fixed effects. ",
           "$\\beta_h$: response without sanctions; $\\pi_h$: difference between the responses with and without sanctions; $\\beta_h+\\pi_h$: ",
           "response under sanctions. $p$-values for $\\pi_h$ from standard errors clustered by country, Driscoll--Kraay standard errors ",
           sprintf("(Bartlett kernel, two lags) and a wild cluster bootstrap (Rademacher weights, %d draws, clustered by country). ", B_BOOT),
           "Stars on $\\beta_h$, $\\pi_h$ and $\\beta_h+\\pi_h$ use standard errors clustered by country. ", STARS_NOTE))
}
hs <- 4:8
for (sp in c("aug2", "base")) {
  body <- unlist(lapply(SDEFS, function(Sv) { r <- resC[sanction == Sv & spec == sp & h %in% hs][order(h)]
    c(paste(SLAB[Sv], "&", paste(sprintf("%.3f", r$pi), collapse = " & "), "\\\\"),
      paste(" &", paste(fifelse(is.na(r$p_WCB), sprintf("{[%.3f]}", r$p_cluster), sprintf("{[%.3f]}", r$p_WCB)), collapse = " & "), "\\\\")) }))
  write_tex(file.path(TAB, sprintf("tab_sanction_defs%s.tex", if (sp == "base") "_base" else "")),
    sprintf("Sanctions gap $\\pi_h$ under alternative definitions of sanctions%s", if (sp == "base") " (baseline)" else ""),
    if (sp == "base") "tab:sanction_defs_base" else "tab:sanction_defs", "l *{5}{c}",
    paste("&", paste(sprintf("$h=%d$", hs), collapse = " & "), "\\\\"), body,
    paste0("Coefficient $\\pi_h$ of the pooled local projection", if (sp == "aug2") " with two lags of the change in debt and the lagged shock" else "",
           ". Wild cluster bootstrap $p$-values in brackets", if (sp == "base") " (clustered $p$-values where no bootstrap was run)" else "",
           ". Financial: GSDB financial sanctions. Excl.\\ COL, PHL, IDN: financial sanctions with the three long-running targeted episodes recoded to zero. ",
           "Multiple: two or more sanctions in force. High intensity: GSDB intensity at or above the median among sanctioned country-years."))
}
gc_ <- function(Sv, sp, hh, col) resC[sanction == Sv & spec == sp & h == hh][[col]]
for (Sv in c("Sfin", "S")) for (hh in 4:8) kv("pi ", Sv, " base h", hh, " = ", sprintf("%.3f (%.3f)", gc_(Sv, "base", hh, "pi"), gc_(Sv, "base", hh, "se_pi")),
  " | p cl ", sprintf("%.3f", gc_(Sv, "base", hh, "p_cluster")), " | p DK ", sprintf("%.3f", gc_(Sv, "base", hh, "p_DK")),
  " | p WCB ", sprintf("%.3f", gc_(Sv, "base", hh, "p_WCB")), " | rép. sous sanctions ", sprintf("%.3f p=%.3f", gc_(Sv, "base", hh, "resp_s"), gc_(Sv, "base", hh, "p_s")))
kv("p min réponse sous sanctions (Sfin base, h1-8) : ", sprintf("%.3f", min(resC[sanction == "Sfin" & spec == "base", p_s])))
for (Sv in SDEFS) kv("aug2 ", Sv, " : pi h6 ", sprintf("%.3f WCB %.3f", gc_(Sv, "aug2", 6, "pi"), gc_(Sv, "aug2", 6, "p_WCB")),
  " ; pi h7 ", sprintf("%.3f WCB %.3f", gc_(Sv, "aug2", 7, "pi"), gc_(Sv, "aug2", 7, "p_WCB")))

resD <- list()
for (Fv in c("FR_l1", "strong_l1")) for (y in c("debt", "pb")) for (h in H) {
  dat <- copy(d); dat[, xF := e * get(Fv)]
  resD[[length(resD) + 1]] <- cbind(data.table(model = Fv, y = y, h = h, term = "theta"),
                                    term_stats(lp(dat, yname(y, h), "e", h, extra = c("xF", Fv), lagvar = y), "xF"))
}
for (Sv in c("S_l1", SM1)) for (y in c("debt", "pb")) for (h in H) {
  dat <- copy(d); dat[, `:=`(eF = e * FR_l1, eS = e * get(Sv), eFS = e * FR_l1 * get(Sv), FS = FR_l1 * get(Sv))]
  m <- lp(dat, yname(y, h), "e", h, extra = c("eF", "eS", "eFS", "FR_l1", Sv, "FS"), lagvar = y)
  for (tt in c("eF", "eS", "eFS")) resD[[length(resD) + 1]] <- cbind(
    data.table(model = paste0("triple_", Sv), y = y, h = h, term = c(eF = "theta", eS = "pi", eFS = "kappa")[tt]), term_stats(m, tt))
}
resD <- rbindlist(resD, fill = TRUE); fwrite(resD, file.path(RES, "interactions.csv"))
mk_rows <- function(sub, lab) { r <- sub[order(h)]
  c(paste(lab, "&", paste(f_cs(r$coef, r$p), collapse = " & "), "\\\\"), paste(" &", paste(f_se(r$se), collapse = " & "), "\\\\")) }
body <- c("\\multicolumn{9}{l}{\\textit{Panel A. Equation (\\ref{eq:lp_inter1}): GPR shock $\\times$ fiscal rule at $t-1$}} \\\\",
  mk_rows(resD[model == "FR_l1" & y == "debt"], "$\\theta_h$, any rule, debt"),
  mk_rows(resD[model == "strong_l1" & y == "debt"], "$\\theta_h$, multiple rules, debt"),
  mk_rows(resD[model == "FR_l1" & y == "pb"], "$\\theta_h$, any rule, primary balance"), "\\addlinespace")
for (Sv in c("S_l1", SM1)) {
  body <- c(body, sprintf("\\multicolumn{9}{l}{\\textit{Panel %s. Equation (\\ref{eq:lp_inter2}), %s}} \\\\",
                          if (Sv == "S_l1") "B" else "C", if (Sv == "S_l1") "all GSDB sanctions" else "financial sanctions"))
  for (yy in c("debt", "pb")) for (tt in c("theta", "pi", "kappa"))
    body <- c(body, mk_rows(resD[model == paste0("triple_", Sv) & y == yy & term == tt], sprintf("$\\%s_h$, %s", tt, if (yy == "debt") "debt" else "primary balance")))
  body <- c(body, "\\addlinespace")
}
write_tex(file.path(TAB, "tab_interactions.tex"), "Interaction estimates across horizons", "tab:interactions", "l *{8}{c}",
  paste("&", paste(sprintf("$h=%d$", H), collapse = " & "), "\\\\"), body, NOTE_LP, size = "\\scriptsize")
gt <- function(mod, y_, hh, tt, col) resD[model == mod & y == y_ & h == hh & term == tt][[col]]
kv("Triple (S_l1) h5 : theta dette ", sprintf("%.3f", gt("triple_S_l1", "debt", 5, "theta", "coef")), " ; kappa dette ",
   sprintf("%.3f (%.3f)", gt("triple_S_l1", "debt", 5, "kappa", "coef"), gt("triple_S_l1", "debt", 5, "kappa", "se")),
   " ; kappa solde ", sprintf("%.3f (%.3f)", gt("triple_S_l1", "pb", 5, "kappa", "coef"), gt("triple_S_l1", "pb", 5, "kappa", "se")))
kv("theta any rule dette : ", paste(sprintf("%.3f%s", resD[model == "FR_l1" & y == "debt", coef], etoiles(resD[model == "FR_l1" & y == "debt", p])), collapse = " "))

tab6 <- rbindlist(lapply(c("strong", "norule"), function(gp) { dat <- if (gp == "strong") d[strong_l1 == 1] else d[FR_l1 == 0]
  rbindlist(lapply(H, function(h) cbind(data.table(groupe = gp, h = h), term_stats(lp(dat, yname("debt", h), "e", h), "e", ident_ids = pays19)))) }))
fwrite(tab6, file.path(RES, "rule_intensity.csv"))
body <- unlist(lapply(c("strong", "norule"), function(gp) { r <- tab6[groupe == gp][order(h)]
  c(paste(if (gp == "strong") "Multiple rules ($\\geq 2$ types, $FR=1$)" else "No rule ($FR=0$)", "&", paste(f_cs(r$coef, r$p), collapse = " & "), "\\\\"),
    paste(" &", paste(f_se(r$se), collapse = " & "), "\\\\"), paste("Observations &", paste(f_n(r$N), collapse = " & "), "\\\\"),
    paste("Identifying countries &", paste(f_n(r$n_ident), collapse = " & "), "\\\\"), "\\addlinespace") }))
write_tex(file.path(TAB, "tab_rule_intensity.tex"), "GPR shock and debt/GDP by fiscal-rule intensity", "tab:rule_intensity", "l *{8}{c}",
  paste("&", paste(sprintf("$h=%d$", H), collapse = " & "), "\\\\"), body, paste(NOTE_LP, "Rule intensity is measured at $t-1$."))
kv("Tableau 6 : multiple ", paste(sprintf("%.3f%s", tab6[groupe == "strong", coef], etoiles(tab6[groupe == "strong", p])), collapse = " "),
   " | sans règle ", paste(sprintf("%.3f%s", tab6[groupe == "norule", coef], etoiles(tab6[groupe == "norule", p])), collapse = " "),
   " | pays identifiants multiple h1 ", tab6[groupe == "strong" & h == 1, n_ident], " h8 ", tab6[groupe == "strong" & h == 8, n_ident])

COMPS <- c("ddebt", "ero_prix", "ero_reel", "deficit", "sfa"); CUMV <- c(COMPS, "growth", "infl")
resF <- list()
for (sp in c("base", "aug2")) for (h in H) {
  dd <- d[d[[paste0("ok_h", h)]] %in% TRUE]
  for (v in CUMV) {
    resF[[length(resF) + 1]] <- cbind(data.table(spec = sp, h = h, variable = v, term = "full"), term_stats(lp(dd, paste0("c_", v, "_h", h), "e", h, sp), "e"))
    m <- pooled(dd, paste0("c_", v, "_h", h), h, SM1, sp)
    resF[[length(resF) + 1]] <- cbind(data.table(spec = sp, h = h, variable = v, term = "pi"), term_stats(m, "xS"))
  }
  for (v in c("d_reff", "d_pb")) resF[[length(resF) + 1]] <- cbind(data.table(spec = sp, h = h, variable = v, term = "full"),
    term_stats(lp(d, paste0(v, "_h", h), "e", h, sp), "e"))
}
resF <- rbindlist(resF, fill = TRUE); fwrite(resF, file.path(RES, "mechanism.csv"))
FLAB <- c(ddebt = "Change in debt/GDP", ero_prix = "\\quad Erosion through the price level", ero_reel = "\\quad Erosion through real growth",
          deficit = "\\quad Overall deficit", sfa = "\\quad Stock-flow adjustment", infl = "Memo: cumulative inflation (pp)",
          growth = "Memo: cumulative real growth (pp)", d_reff = "Memo: effective interest rate (pp)", d_pb = "Memo: primary balance/GDP (pp)")
for (sp in c("base", "aug2")) {
  body <- unlist(lapply(names(FLAB), function(v) { r <- resF[spec == sp & term == "full" & variable == v][order(h)]; if (!nrow(r)) return(NULL); mk_rows(r, FLAB[v]) }))
  body <- c(body, "\\addlinespace", "\\multicolumn{9}{l}{\\textit{Difference under financial sanctions, $\\pi_h$}} \\\\",
            unlist(lapply(COMPS, function(v) mk_rows(resF[spec == sp & term == "pi" & variable == v], FLAB[v]))))
  write_tex(file.path(TAB, sprintf("tab_mechanism%s.tex", if (sp == "base") "" else "_aug2")),
    sprintf("Accounting decomposition of the debt response%s", if (sp == "base") "" else ", with two lags of the change in debt"),
    if (sp == "base") "tab:mechanism" else "tab:mechanism_aug2", "l *{8}{c}",
    paste("&", paste(sprintf("$h=%d$", H), collapse = " & "), "\\\\"), body,
    paste0(NOTE_LP, " The change in debt/GDP from $t-1$ to $t+h$ is the exact sum of its four components, each cumulated from $t$ to $t+h$: ",
           "erosion through the price level $-d_{t-1}\\pi_t(1+g_t)/(1+g^n_t)$, erosion through real growth $-d_{t-1}g_t/(1+g^n_t)$, ",
           "the overall deficit (expenditure minus revenue), and the stock-flow residual, with $1+g^n_t=(1+g_t)(1+\\pi_t)$. ",
           "The change in debt/GDP and its four components share one estimation sample, in which they add up exactly; the memo rows use all available observations. Inflation is CPI inflation, used as a proxy for the GDP deflator. ",
           "The effective interest rate is implicit interest payments over lagged debt. The lower panel reports $\\pi_h$ from the pooled ",
           "specification with financial sanctions."), size = "\\scriptsize")
}
gf <- function(sp, v, hh, tm = "full", col = "coef") resF[spec == sp & variable == v & h == hh & term == tm][[col]]
for (sp in c("base", "aug2")) kv("Décomposition ", sp, " h8 : dette ", sprintf("%.3f", gf(sp, "ddebt", 8)), " = prix ", sprintf("%.3f (p %.3f)", gf(sp, "ero_prix", 8), gf(sp, "ero_prix", 8, col = "p")),
  " + réel ", sprintf("%.3f", gf(sp, "ero_reel", 8)), " + déficit ", sprintf("%.3f (p %.3f)", gf(sp, "deficit", 8), gf(sp, "deficit", 8, col = "p")),
  " + stock-flux ", sprintf("%.3f", gf(sp, "sfa", 8)), " ; inflation cumulée ", sprintf("%.3f (p %.3f)", gf(sp, "infl", 8), gf(sp, "infl", 8, col = "p")),
  " ; taux effectif ", sprintf("%.3f (p %.3f)", gf(sp, "d_reff", 8), gf(sp, "d_reff", 8, col = "p")),
  " ; pi croissance h8 ", sprintf("%.3f (p %.3f)", gf(sp, "growth", 8, "pi"), gf(sp, "growth", 8, "pi", "p")),
  " ; pi déficit h8 ", sprintf("%.3f (p %.3f)", gf(sp, "deficit", 8, "pi"), gf(sp, "deficit", 8, "pi", "p")))
fm <- resF[spec == "base" & term == "full" & variable %in% COMPS]
fm[, comp := factor(variable, COMPS, c("Change in debt/GDP", "Price-level erosion", "Real-growth erosion", "Overall deficit", "Stock-flow adjustment"))]
p66 <- ggplot(fm, aes(h, coef, linetype = comp, shape = comp)) + geom_hline(yintercept = 0, linewidth = .3) +
  geom_line(linewidth = .7) + geom_point(size = 1.8) + scale_x_continuous(breaks = H) +
  labs(x = "Horizon (years)", y = "Cumulative contribution (pp per basis point)", linetype = NULL, shape = NULL) +
  theme_bw(base_size = 10) + theme(panel.grid.minor = element_blank(), legend.position = "bottom") + guides(linetype = guide_legend(nrow = 2))
ggsave(file.path(FIG, "fig_mechanism.pdf"), p66, width = 6.5, height = 4.2)

d[, inf_raw := inf]

sens <- list()
add <- function(lab, dat, spec = "base", shock = "e", pi = TRUE, ctrl = NULL) {
  if (length(ctrl)) { ctrl0 <- CTRL; assign("CTRL", c(ctrl0, ctrl), envir = globalenv()); on.exit(assign("CTRL", ctrl0, envir = globalenv())) }
  dat <- copy(dat); if (shock != "e") { dat[, e := get(shock)]; dat[, `:=`(e_l1 = shift(e), e_l2 = shift(e, 2)), by = id] }
  one <- function(col, y, h, m, term) cbind(data.table(test = lab, col = col, y = y, h = h), term_stats(m, term))
  sens[[length(sens) + 1]] <<- rbindlist(list(
    one("debt8", "debt", 8, lp(dat, yname("debt", 8), "e", 8, spec), "e"),
    if (pi) one("pi6", "debt", 6, pooled(dat, yname("debt", 6), 6, SM1, spec), "xS"),
    if (pi) one("pi8", "debt", 8, pooled(dat, yname("debt", 8), 8, SM1, spec), "xS"),
    one("pb1", "pb", 1, lp(dat, yname("pb", 1), "e", 1, spec, lagvar = "pb"), "e")), fill = TRUE)
}
add_bigsmall <- function(lab, term) {
  one <- function(col, y, h) cbind(data.table(test = lab, col = col, y = y, h = h),
    term_stats(lp(d, yname(y, h), c("e_big", "e_small"), h, lagvar = y), term))
  sens[[length(sens) + 1]] <<- rbindlist(list(one("debt8", "debt", 8), one("pb1", "pb", 1)))
}
covid <- function(dat, h) dat[!(t <= 2021 & t + h >= 2020)]
add("Baseline", d)
add("A1. Countries with own GPR index only (19)", d[pays_spec == TRUE])
add("A2. Shock winsorized at 1st/99th percentiles", d, shock = "e_win")
add("A3. Log of the country index", d, shock = "e_log")
add("A4. Standardized within country", d, shock = "e_std")
add_bigsmall("A5. Large shocks (above 90th percentile of $|\\varepsilon|$)", "e_big")
add_bigsmall("A6. Small shocks", "e_small")
add("B1. Two lags of the change in debt and of the shock", d, "aug2")
add("B2. Four lags of the change in debt and two of the shock", d, "aug4")
add("B3. Country-specific linear trends", d, "trend")
d[, war_l1 := shift(war_any), by = id]
add("B4. Armed-conflict indicators at $t$ and $t-1$", d, ctrl = c("war_any", "war_l1"))
add("C1. Excluding Russia and Ukraine", d[!id %in% c("RUS", "UKR")])
add(sprintf("C2. Excluding windows with inflation above %d\\%%", SEUIL_PI), d[d[["pimax_h8"]] <= SEUIL_PI])
add("C3. Excluding windows that overlap 2020--2021", d[!(t <= 2021 & t + 8 >= 2020)])
add("C4. Inflation control winsorized", { dw <- copy(d); dw[, inf := infl_l1_w]; dw })
add("C5. MENA countries only", d[reg == "MENA"], pi = FALSE)
sens <- rbindlist(sens, fill = TRUE); fwrite(sens, file.path(RES, "sensitivity.csv"))
jk <- rbindlist(lapply(c("base", "aug2"), function(sp) rbindlist(lapply(pays19, function(cty) { dat <- d[id != cty]
  b8 <- term_stats(lp(dat, yname("debt", 8), "e", 8, sp), "e"); p6 <- term_stats(pooled(dat, yname("debt", 6), 6, SM1, sp), "xS")
  p8 <- term_stats(pooled(dat, yname("debt", 8), 8, SM1, sp), "xS")
  data.table(spec = sp, dropped = cty, beta_h8 = b8$coef, p_beta_h8 = b8$p, pi_h6 = p6$coef, p_pi_h6 = p6$p, pi_h8 = p8$coef, p_pi_h8 = p8$p) }))))
fwrite(jk, file.path(RES, "leave_one_out.csv"))
plac <- rbindlist(lapply(c("base", "aug4"), function(sp) rbindlist(lapply(c("debt", "pb"), function(y)
  rbindlist(lapply(c(-2, -1), function(h) cbind(data.table(spec = sp, y = y, h = h), term_stats(lp(d, yname(y, h), "e", h, sp, lagvar = y), "e"))))))))
fwrite(plac, file.path(RES, "placebos.csv"))
cell <- function(lab, cc) { r <- sens[test == lab & col == cc]; if (!nrow(r) || is.na(r$coef)) return(c("{}", "{}")); c(f_cs(r$coef, r$p), f_se(r$se)) }
body <- c("\\multicolumn{5}{l}{\\textit{Panel A. Responses to the GPR shock}} \\\\")
for (lb in unique(sens$test)) { cc <- lapply(c("debt8", "pi6", "pi8", "pb1"), function(k) cell(lb, k))
  body <- c(body, paste(lb, "&", paste(sapply(cc, `[`, 1), collapse = " & "), "\\\\"), paste(" &", paste(sapply(cc, `[`, 2), collapse = " & "), "\\\\")) }
for (sp in c("base", "aug2")) { j <- jk[spec == sp]
  body <- c(body, sprintf("C6. Leave one identifying country out%s: range & [%.3f, %.3f] & [%.3f, %.3f] & [%.3f, %.3f] & {} \\\\",
                          if (sp == "base") "" else " (two lags)", min(j$beta_h8), max(j$beta_h8), min(j$pi_h6), max(j$pi_h6), min(j$pi_h8), max(j$pi_h8))) }
body <- c(body, "\\addlinespace", "\\multicolumn{5}{l}{\\textit{Panel B. Placebo leads: change in the outcome before the shock}} \\\\",
          "& Debt, $h=-2$ & Debt, $h=-1$ & PB, $h=-2$ & PB, $h=-1$ \\\\")
for (sp in c("base", "aug4")) { r <- plac[spec == sp]; gp <- function(yy, hh) r[y == yy & h == hh]
  cc <- list(gp("debt", -2), gp("debt", -1), gp("pb", -2), gp("pb", -1))
  body <- c(body, paste(if (sp == "base") "Baseline" else "Four lags of the change in the outcome", "&", paste(sapply(cc, function(x) f_cs(x$coef, x$p)), collapse = " & "), "\\\\"),
            paste(" &", paste(sapply(cc, function(x) f_se(x$se)), collapse = " & "), "\\\\")) }
write_tex(file.path(TAB, "tab_sensitivity.tex"), "Sensitivity and falsification exercises", "tab:sensitivity",
  "p{6.6cm} *{4}{c}", "& Debt, $h=8$ & Gap $\\pi_h$, $h=6$ & Gap $\\pi_h$, $h=8$ & PB, $h=1$ \\\\", body,
  paste0(NOTE_LP, " Debt and PB: full-sample response to the GPR shock. Gap $\\pi_h$: difference between the debt responses with and without ",
         "financial sanctions at $t-1$ in the pooled specification \\eqref{eq:lp_pooled}. Rows are grouped by threat: shock measurement (A), ",
         "omitted dynamics and confounders (B) and sample composition (C). B4 adds UCDP/PRIO indicators of armed conflict at $t$ and $t-1$ to the controls. Rows A3 and A4 use other units of the shock, so their coefficients are not comparable in size with the baseline. ",
         "Large and small shocks enter the same regression; the threshold is the 90th percentile of the absolute shock among the 19 identifying ",
         sprintf("countries (%.1f basis points). ", c90), "C3 drops every observation whose window from $t-1$ to $t+8$ includes 2020 or 2021. ",
         "Placebo leads regress $y_{i,t-1}-y_{i,t-2}$ ($h=-1$) and $y_{i,t-2}-y_{i,t-3}$ ($h=-2$) ",
         "on the shock at $t$ with the same controls and fixed effects. PB: primary balance/GDP."), size = "\\scriptsize")
for (lb in unique(sens$test)) { g <- function(k) { r <- sens[test == lb & col == k]; if (!nrow(r) || is.na(r$coef)) "-" else sprintf("%.3f p=%.3f", r$coef, r$p) }
  kv("Sensibilité | ", lb, " | dette h8 ", g("debt8"), " | pi h6 ", g("pi6"), " | pi h8 ", g("pi8"), " | solde h1 ", g("pb1")) }
for (sp in c("base", "aug2")) kv("Leave-one-out ", sp, " : beta h8 [", sprintf("%.3f, %.3f", min(jk[spec == sp, beta_h8]), max(jk[spec == sp, beta_h8])),
  "] p max ", sprintf("%.3f", max(jk[spec == sp, p_beta_h8])), " ; pi h6 [", sprintf("%.3f, %.3f", min(jk[spec == sp, pi_h6]), max(jk[spec == sp, pi_h6])),
  "] p max ", sprintf("%.3f", max(jk[spec == sp, p_pi_h6])), " ; pi h8 [", sprintf("%.3f, %.3f", min(jk[spec == sp, pi_h8]), max(jk[spec == sp, pi_h8])),
  "] p max ", sprintf("%.3f", max(jk[spec == sp, p_pi_h8])), " ; pays où p pi h6 > 0.05 : ", paste(jk[spec == sp & p_pi_h6 > .05, dropped], collapse = " "))
for (i in seq_len(nrow(plac))) kv("Placebo ", plac$spec[i], " ", plac$y[i], " h", plac$h[i], " = ", sprintf("%.3f (%.3f) p=%.3f", plac$coef[i], plac$se[i], plac$p[i]))
for (hh in c(5, 8)) { m <- lp(d, yname("debt", hh), c("e_big", "e_small"), hh); kv("Grands=petits h", hh, " p = ", sprintf("%.3f", diff_p(m, "e_big", "e_small"))) }

regs <- sort(unique(d$reg))
reg <- rbindlist(lapply(regs, function(rg) rbindlist(lapply(c(5, 8), function(h)
  cbind(data.table(region = rg, h = h), term_stats(lp(d[reg == rg], yname("debt", h), "e", h), "e", ident_ids = pays19))))))
fwrite(reg, file.path(RES, "regions.csv"))
idn <- d[pays_spec == TRUE, .(ids = paste(sort(unique(id)), collapse = ", ")), by = reg]
body <- unlist(lapply(regs, function(rg) { r <- reg[region == rg][order(h)]
  c(sprintf("%s & %s & %s & %s & %s \\\\", rg, f_cs(r$coef[1], r$p[1]), f_cs(r$coef[2], r$p[2]), uniqueN(d[reg == rg, id]), idn[reg == rg, ids]),
    sprintf(" & %s & %s & & \\\\", f_se(r$se[1]), f_se(r$se[2]))) }))
write_tex(file.path(TAB, "tab_regions.tex"), "GPR shock and debt/GDP by region", "tab:regions", "l c c c p{4.5cm}",
  "Region & $h=5$ & $h=8$ & Countries & Countries with own GPR index \\\\", body,
  paste(NOTE_LP, "Only countries with a country-specific GPR index contribute variation to the shock coefficient (the shock is zero for the others); they are listed in the last column."))
plages <- function(y) { y <- sort(unique(y)); if (!length(y)) return("--"); br <- c(0, which(diff(y) != 1), length(y))
  paste(sapply(seq_len(length(br) - 1), function(i) { a <- y[br[i] + 1]; b <- y[br[i + 1]]; if (a == b) a else paste0(a, "--", b) }), collapse = ", ") }
NOMS <- c(ARE = "United Arab Emirates", ARG = "Argentina", BFA = "Burkina Faso", BGD = "Bangladesh", BHR = "Bahrain", BOL = "Bolivia", BRA = "Brazil",
  CHL = "Chile", CIV = "C\\^ote d'Ivoire", CMR = "Cameroon", COL = "Colombia", DZA = "Algeria", ECU = "Ecuador", EGY = "Egypt", ETH = "Ethiopia",
  GEO = "Georgia", GHA = "Ghana", GTM = "Guatemala", HND = "Honduras", IDN = "Indonesia", IND = "India", IRN = "Iran", IRQ = "Iraq", JAM = "Jamaica",
  JOR = "Jordan", KAZ = "Kazakhstan", KEN = "Kenya", KWT = "Kuwait", LBN = "Lebanon", LBY = "Libya", LKA = "Sri Lanka", MAR = "Morocco",
  MDG = "Madagascar", MEX = "Mexico", MOZ = "Mozambique", MYS = "Malaysia", NGA = "Nigeria", NPL = "Nepal", OMN = "Oman", PAK = "Pakistan",
  PAN = "Panama", PER = "Peru", PHL = "Philippines", PRY = "Paraguay", QAT = "Qatar", RUS = "Russia", RWA = "Rwanda", SAU = "Saudi Arabia",
  SEN = "Senegal", THA = "Thailand", TTO = "Trinidad and Tobago", TUN = "Tunisia", TUR = "T\\\"urkiye", TZA = "Tanzania", UGA = "Uganda",
  UKR = "Ukraine", URY = "Uruguay", VNM = "Vietnam", ZAF = "South Africa", ZMB = "Zambia")
sl <- d[S == 1 | Sfin == 1, .(fin = plages(t[Sfin == 1]), trade = plages(t[sanction_comm == 1]), arms = plages(t[sanction_arms == 1]),
                               mil = plages(t[sanction_mil == 1]), any = plages(t[S == 1]), own = fifelse(pays_spec[1], "Yes", "No")), by = id][order(id)]
sl[, nom := NOMS[id]]; sl <- sl[order(nom)]; fwrite(sl, file.path(RES, "sanctions_list.csv"))
writeLines(c("\\begin{scriptsize}", "\\setlength{\\tabcolsep}{3pt}", "\\begin{longtable}{p{2.2cm} p{2.4cm} p{2.4cm} p{2.0cm} p{1.8cm} p{2.4cm} c}",
  "\\caption{Sanctioned country-years by type of sanction (GSDB)}\\label{tab:sanctions_list}\\\\",
  "\\toprule", "Country & Financial & Trade & Arms & Military & Any type & Own GPR \\\\", "\\midrule", "\\endfirsthead",
  "\\toprule", "Country & Financial & Trade & Arms & Military & Any type & Own GPR \\\\", "\\midrule", "\\endhead",
  "\\bottomrule", "\\multicolumn{7}{p{15.4cm}}{\\textit{Notes:} Years in which each type of sanction is recorded in the Global Sanctions Database \\citep{Felbermayr2020}. Own GPR: country with a country-specific Caldara--Iacoviello index (identifying country). Countries without any recorded sanction are omitted.}\\\\",
  "\\endlastfoot",
  sprintf("%s & %s & %s & %s & %s & %s & %s \\\\", sl$nom, sl$fin, sl$trade, sl$arms, sl$mil, sl$any, sl$own), "\\end{longtable}", "\\end{scriptsize}"),
  file.path(TAB, "tab_sanctions_list.tex"))
kv("Pays-années sous sanctions financières : ", sprintf("%.3f", mean(d$Sfin, na.rm = TRUE)), " ; toutes sanctions : ", sprintf("%.3f", mean(d$S, na.rm = TRUE)))

cat("\nTerminé : tableaux dans", TAB, "; figures dans", FIG, "; résultats dans", RES, "\n")
