suppressPackageStartupMessages({ library(data.table); library(ggplot2) })

RACINE <- "."; SORTIE <- "../figures"
dir.create(SORTIE, showWarnings = FALSE, recursive = TRUE)

pe <- as.data.table(readRDS(file.path(RACINE, "data/processed/panel_frd_extended.rds")))
fy <- pe[, .(any_rule = sum(fr_any == 1, na.rm = TRUE),
             bbr = sum(bbr == 1, na.rm = TRUE), dr = sum(dr == 1, na.rm = TRUE),
             er  = sum(er  == 1, na.rm = TRUE), rr = sum(rr == 1, na.rm = TRUE),
             escape = sum(escape_any == 1, na.rm = TRUE)), by = .(annee = as.integer(annee))][order(annee)]
print(fy[annee %in% c(1990, 2000, 2005, 2010, 2015, 2016, 2020, 2022)])

lignes <- melt(fy[, .(annee, `Balanced-budget rule` = bbr, `Debt rule` = dr, `Expenditure rule` = er,
                      `Revenue rule` = rr, `Escape clause` = escape)],
               id.vars = "annee", variable.name = "serie", value.name = "n")
types <- c("Balanced-budget rule", "Debt rule", "Expenditure rule", "Revenue rule", "Escape clause")
lignes[, serie := factor(serie, levels = types)]

p <- ggplot() +
  geom_col(data = fy, aes(annee, any_rule, fill = "At least one rule"), width = 0.75) +
  geom_line(data = lignes, aes(annee, n, linetype = serie, colour = serie), linewidth = 0.7) +
  geom_point(data = lignes[serie != "Escape clause"], aes(annee, n, shape = serie, colour = serie), size = 1.3) +
  scale_fill_manual(values = c("At least one rule" = "grey85"), name = NULL) +
  scale_colour_manual(values = c("Balanced-budget rule" = "#1A3A6B", "Debt rule" = "#2E6BB0",
                                 "Expenditure rule" = "#6B6B6B", "Revenue rule" = "#9E9E9E",
                                 "Escape clause" = "#C0392B"), name = NULL) +
  scale_linetype_manual(values = c("Balanced-budget rule" = "solid", "Debt rule" = "solid",
                                   "Expenditure rule" = "solid", "Revenue rule" = "solid",
                                   "Escape clause" = "dashed"), name = NULL) +
  scale_shape_manual(values = c("Balanced-budget rule" = 16, "Debt rule" = 17,
                                "Expenditure rule" = 15, "Revenue rule" = 4), name = NULL, guide = "none") +
  scale_x_continuous(breaks = seq(1990, 2020, 5), expand = c(0.01, 0)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  labs(x = NULL, y = "Number of countries") +
  theme_bw(base_size = 11) +
  theme(panel.grid.minor = element_blank(), panel.grid.major.x = element_blank(),
        legend.position = "bottom", legend.box = "vertical", legend.margin = margin(0, 0, 0, 0)) +
  guides(fill = guide_legend(order = 1), colour = guide_legend(order = 2, nrow = 2),
         linetype = guide_legend(order = 2, nrow = 2))

ggsave(file.path(SORTIE, "fig2_rules_escape.pdf"), p, width = 7.5, height = 4.8)
cat("Écrit :", file.path(SORTIE, "fig2_rules_escape.pdf"), "\n")
